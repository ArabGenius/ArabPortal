<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 01/01/2007 Time: 00:00 AM  |
+===========================================+
*/

require_once('global.php');
checkgroup('view_site');

$menu = new menu;
$menu->menuid       =  $apt->getsettings("index_menuid");
$right_menu         = $menu->_menu(1);

$middle_menu_count  =  $apt->getsettings("count_middle_menu");
$middle_menu = "<table border=0 cellpadding=0 cellspacing=0 width=100%><tr valign=top>";
$middle_menus = $menu->_menu(3);
$ex = @explode('<!-- BLOCK END -->',$middle_menus);
$m=0;
foreach($ex as $amenu){
$middle_menu .= '<td valign=top>'.$amenu.'</td>';
$m++;
if($m==$middle_menu_count)$middle_menu .= "</tr>";
}
$middle_menu .= "</tr></table><br>";

$action = $apt->get[action];
//---------------------------------------------------
$ads_head = $apt->ads_view_in('h');
$ads_foot = $apt->ads_view_in('f');

if (($action=="") || ($action=="idx"))
{
    $left_menu          = $menu->_menu(2);
    
    $perpage_comment   = $apt->getsettings("newsperpagecomment");
    $showmax           = $apt->getsettings("showmax");
    $indexColcount     = intval($apt->getsettings("indexColcount"));
    if($indexColcount < 1 ) $indexColcount = 1;

    if( $indexColcount == 1)
    {
        $wordwrap = 600;
    }
    elseif( $indexColcount == 2)
    {
        $wordwrap = 400;
    }
    elseif( $indexColcount == 3)
    {
        $wordwrap = 300;
    }
    
    $apt->head($head_home);
  
    eval("\$index_middle = \" " . $apt->gettemplate ( 'announcement' ) . "\";");
    $getImageCat = array();
    $getImageCat = $apt->getImageCat();

    if($apt->dbnumquery("rafia_news","main='1' and allow='yes'")){
    $results = $apt->query ("SELECT rafia_news.*,COUNT(rafia_comment.news_id) as numrows
                           FROM rafia_news LEFT JOIN rafia_comment
                           ON  rafia_news.id = rafia_comment.news_id
                           WHERE rafia_news.allow = 'yes'
                           AND rafia_news.main = '1'
                           GROUP BY rafia_news.id ORDER BY `rafia_news`.`id` DESC
                           LIMIT 1");
    $rows = $apt->dbarray($results);
    @extract($rows);
        $postid = $id;
        $newsimage  = '';  
        if($catmig == 0)
        {
            if($uploadfile >0)
            {
                if($apt->getsettings("use_gd_thumb") == 'yes'){$usegd=true;}else{$usegd=false;}
                $newsimage = $apt->getnewsimage($postid,$uploadfile,$usegd);
            }
            elseif($apt->conf['isupgrade'] == 1)
            {
                $newsimage = getimagefile($postid);
            }
        }
        else
        {
           $newsimage  = $getImageCat[$cat_id];
        }
        $news_head    =  $apt->rafia_code($news_head,$wordwrap);
        $date         =  $apt->Hijri($date_time)." ".$apt->gettime($date_time);
        $title        =  $apt->format_data_out($title);
        $name         =  $apt->format_data_out($name);

		if($apt->getsettings('html_links')=='yes'){
		$news_link = "news_view_".$id.".html";
    		}else{
    		$news_link = "news.php?action=view&id=".$id;
    		}

        eval("\$index_middle .= \" " . $apt->gettemplate ( 'index_main_table' ) . "\";");
        
        }

$form = $apt->getsettings('main_form');
if($form == 'formB'){
    $result = $apt->query ("SELECT rafia_news.*,COUNT(rafia_comment.news_id) as numrows
                           FROM rafia_news LEFT JOIN rafia_comment
                           ON  rafia_news.id = rafia_comment.news_id
                           WHERE rafia_news.allow = 'yes'
                           AND rafia_news.inindex = '1'
                           AND rafia_news.main = '0'
                           GROUP BY rafia_news.id
                           ORDER BY rafia_news.id DESC
                           LIMIT $start,$showmax");
                           
    $getImageCat = $apt->getImageCat();

    $index_middle .= "<br><center><table border='0' width='100%' align='center' cellpadding='".$indexColcount."'><tr>";

    while ( $row = $apt->dbarray($result) )
    {
        @extract($row);

        $postid = $id;
        $newsimage  = '';  
        if($catmig == 0)
        {
            if($uploadfile >0)
            {
                $newsimage = $apt->getnewsimage($postid,$uploadfile);
            }
            elseif($apt->conf['isupgrade'] == 1)
            {
                $newsimage = getimagefile($postid);
            }
        }
        else
        {
           $newsimage  = $getImageCat[$cat_id];
        }

        $apt->numrows =  $numrows;
        $pagenum      =  $apt->pagenumlist($perpage_comment,$postid,"news.php");

        $news_head    =  $apt->rafia_code($news_head,$wordwrap);

        $date         =  $apt->Hijri($date_time)." ".$apt->gettime($date_time);
        $title        =  $apt->format_data_out($title);
        $name         =  $apt->format_data_out($name);

        if ($news_head <>"")
        {
            $tdwidth =  100/$indexColcount;
            $index_middle .= "<td align=\"center\" width=\"".$tdwidth."%\"  valign=\"top\">";
		if($apt->getsettings('html_links')=='yes'){
		$news_link = "news_view_".$id.".html";
    		}else{
    		$news_link = "news.php?action=view&id=".$id;
    		}

            eval("\$index_middle .= \" " . $apt->gettemplate ( 'index_table' ) . "\";");
		
            $index_middle .= "</td>";
            $count++;
            if ($count ==  $indexColcount)
            {
                $index_middle .= "</tr>";
                $count = 0;
            }
        }
    }
    $index_middle .= "</tr></table>";
    $apt->numrows = $apt->dbnumquery("rafia_news","allow='yes' AND inindex ='1'");
    $index_middle .= $apt->pagenum($showmax,"idx");

}else{
////----------
    $showcat = trim($apt->getsettings('showcat'));
    $showcat = explode(",",$apt->getsettings('showcat'));
    foreach($showcat as $showc){$shc = intval($showc); if(!$shc == 0)$sc[] = $shc;}
    $showcat = $apt->myimplode($sc);
    if(!$showcat)$showcat = 0;
    $result = $apt->query("SELECT title,id FROM rafia_cat WHERE catType='1' and id in($showcat) ORDER BY ordercat ASC");
    while($row = $apt->dbarray($result)){
    @extract($row);
    $count = 0;
    $cid         =  intval($id);
    $ctitle      =  $apt->format_data_out($title);
    eval("\$index_middle .= \" " . $apt->gettemplate ( 'index_table_cat_title' ) . "\";");

    $results = $apt->query ("SELECT rafia_news.*,COUNT(rafia_comment.news_id) as numrows
                           FROM rafia_news LEFT JOIN rafia_comment
                           ON  rafia_news.id = rafia_comment.news_id
                           WHERE rafia_news.allow = 'yes'
                           AND rafia_news.cat_id = '$cid'
                           AND rafia_news.inindex = '1'
                           AND rafia_news.main = '0'
                           GROUP BY rafia_news.id ORDER BY `rafia_news`.`id` DESC
                           LIMIT $showmax");
    $index_middle .= "<center><table border='0' width='100%' align='center' cellpadding='".$indexColcount."'><tr>";
    while ( $rows = $apt->dbarray($results) )
    {
        @extract($rows);
        $postid = $id;
        $newsimage  = '';  
        if($catmig == 0)
        {
            if($uploadfile >0)
            {
                if($apt->getsettings("use_gd_thumb") == 'yes'){$usegd=true;}else{$usegd=false;}
                $newsimage = $apt->getnewsimage($postid,$uploadfile,$usegd);
            }
            elseif($apt->conf['isupgrade'] == 1)
            {
                $newsimage = getimagefile($postid);
            }
        }
        else
        {
           $newsimage  = $getImageCat[$cat_id];
        }

        $apt->numrows =  $numrows;
        $pagenum      =  $apt->pagenumlist($perpage_comment,$postid,"news.php");
        $news_head    =  $apt->rafia_code($news_head,$wordwrap);
        $date         =  $apt->Hijri($date_time)." ".$apt->gettime($date_time);
        $title        =  $apt->format_data_out($title);
        $name         =  $apt->format_data_out($name);
        $tdwidth =  100/$indexColcount;
        $index_middle .= "<td align=\"center\" width=\"".$tdwidth."%\"  valign=\"top\">";
         if($apt->getsettings('html_links')=='yes'){
         $news_link = "news_view_".$id.".html";
         }else{
         $news_link = "news.php?action=view&id=".$id;
         }
         eval("\$index_middle .= \" " . $apt->gettemplate ( 'index_table' ) . "\";");
         

         $index_middle .= "</td>";
         $count++;
         if ($count ==  $indexColcount)
         {
             $index_middle .= "</tr>";
             $count = 0;
         }
    }
     $index_middle .= "</tr></table>";
   }
}
////----------

    eval("\$index_middle .= \" " . $apt->gettemplate ( 'index_block' ) . "\";");

    $apt->html_Output($left_menu);
}
else  if ($apt->get['action']=="pages")
{
    unset($left_menu);
    $id  = $apt->setid('id');
    $row = $apt->dbfetch("SELECT * FROM rafia_pages
                                     WHERE  active='1' and id='$id' ");
                                     @extract($row);
    if ($checkuser == 1)
    {
         checkcookie();
    }
    $apt->head($name);
    $pagetext =  @explode('[--NEW_PAGE--]',$pagetext);
    $pcount = count($pagetext);
    $part = intval($_GET[part]);
    if($part == 0)$part = 1;
    $pagetext =  $pagetext[$part-1];
    $pagetext =  $apt->replace_callback($pagetext);
    $member_un = $apt->format_data($apt->cookie['cname']);
    $pagetext =  str_replace('[--USER_NAME--]',$member_un,$pagetext);
    $date = $apt->Hijri(time());
    $pagetext =  str_replace('[--TIME_NOW--]',$date,$pagetext);
    if($ishtml==0)$pagetext =  nl2br($pagetext);
    $index_middle = '<br>'.$pagetext;
    $count=$count+1;



$end= 1;
$show=3; 
$start=$page*$end-$end; 
$links=$pcount/$end; 
$lastlink=ceil($links); 

if ($lastlink!=1 ) { 
if (($lastlink<=$part+$show and $part-$show>1) or ($part-$show>1) ) { $part_code =  "<a title='��� ����' href=index.php?action=pages&id=$id&part=1>�</a> ..";} 
if ($part-$show<1) { for ($i=1 ;$i<=$part-1 ;$i++) $part_code .=  "<a href=index.php?action=pages&id=$id&part=$i>[$i]</a>"; } 
if ($part-$show>=1) { for ($i=$part-$show ;$i<=$part-1 ;$i++) $part_code .=  "<a href=index.php?action=pages&id=$id&part=$i>[$i]</a>"; } 
if ($lastlink>$part+$show) { $part_code .=  "[$part]"; for ($i=$part+1 ;$i<=$part+$show ;$i++) { $part_code .=  "<a href=index.php?action=pages&id=$id&part=$i>[$i]</a>";} $part_code .=  " .. <a title='��� ����' href=index.php?action=pages&id=$id&part=$lastlink>�</a>"; } 
if ($lastlink<=$part+$show) { $part_code .=  "[$part]"; for ($i=$part+1 ;$i<=$lastlink ;$i++) $part_code .=  "<a href=index.php?action=pages&id=$id&part=$i>[$i]</a>"; } 
}
if ($lastlink>2 ) 
$part_code .=  "<br>��� ������ : $part �� $lastlink" ;
$part_code = '<br>'.$part_code;


	  $index_middle .= $part_code;

    if ($showcount == 1){
	  $index_middle .= '<br><center><b>�� ��� ��� ������ '.$count . ' ���/ ���� </b></center>';
    }
    $apt->query("update rafia_pages set count=count+1 where id='$id'");
   $apt->html_Output($left_menu);
}
else if ($apt->get['action']=="ads")
{
    $adsid  = $apt->setid('adsid');
    $result= $apt->query("SELECT * FROM rafia_ads WHERE adsid='$adsid'");
    if($apt->dbnumrows($result)==0){$apt->errmsg ('���� ... ���� ��� ����� �� �������');}
    $row= $apt->dbarray($result);

        @extract($row);
        if($clicks==""){$clicks=0;}
        $clicks=$clicks + 1;
        $result=$apt->query("update rafia_ads set clicks='$clicks' where adsid='$adsid'");
        if($result){
		$adsurl=$apt->addToURL($adsurl);
            $redirect="Location:$adsurl";
            header($redirect);
        }
}else  if ($apt->get['action']=="rss"){

$url = $apt->getsettings("siteURL");
$site= $apt->getsettings("sitetitle");

if(substr($url,-1) != '/'){
$url = $url . '/';
}

function xmlentities($string){
  return str_replace ( array ( '&', '"', "'", '<', '>', '\x92' ), array ( '&amp;' , '&quot;', '&apos;' , '&lt;' , '&gt;', '&apos;' ), $string );
}


header('Content-Type: text/xml');
echo '<?xml version="1.0" encoding="windows-1256"?>'. "\r\n";
echo '<rss version="0.91">'."\r\n";
echo "<channel>\r\n";

echo "\t<item>\r\n";
echo "\t\t<title>".xmlentities($site)."</title>\r\n";
echo "\t\t<link>$url</link>\r\n";
echo "\t\t<description>".xmlentities("������� ���� ������� �������")."</description>\r\n";
echo "\t</item>\r\n";

$result = mysql_query ("SELECT * FROM rafia_news
                                 WHERE allow='yes'
                                 ORDER BY id DESC limit 10");

while ($row = mysql_fetch_array($result))
{
$id 		= $row['id']; 
$title 	= xmlentities($row['title']); 
$news_head 	= xmlentities($row['news_head']); 
$thelink 	= xmlentities($url."news.php?action=view&id=$id");

echo "\t<item>\r\n";
echo "\t\t<title>$title</title>\r\n";
echo "\t\t<link>$thelink</link>\r\n";
echo "\t\t<description>$news_head</description>\r\n";
echo "\t</item>\r\n";
}
echo "</channel>\r\n";
echo "</rss>";
exit();
}
else  if ($apt->get['action']=="Login")
{
    Login();
}

$apt->foot($pageft);
?>