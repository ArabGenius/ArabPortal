<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 03/11/2006 Time: 02:40 PM  |
+===========================================+
*/

include('global.php');
checkgroup('view_site');

$cat_img = "newnews.gif";

$order_dir = $apt->format_data($apt->get[order_dir]);
$order_by = $apt->format_data($apt->get[order_by]);

if (empty($order_by)){
        $order_by = "date_time";
}
if (empty($order_dir)){
    $order_dir = DESC;
}

$order_by_array = array('id','date_time','userid','reader','c_comment','timestamp');
$order_dir_array = array('DESC','ASC');

$allow_dir = in_array($order_dir,$order_dir_array);
if(!$allow_dir){
$apt->errmsg("���� ... ��� ������� ��� ������");
}
$allow_by = in_array($order_by,$order_by_array);
if(!$allow_by){
$apt->errmsg("���� ... ��� ������� ��� ������");
}

function  getImageCat ()
{
    global $apt;
   $result = $apt->query("SELECT upid,uppostid,imagealign FROM rafia_upload WHERE upcat='catid'");

   if($apt->dbnumrows($result)>0)
   {
       $rowfile = $apt->dbarray($result);

       @extract($rowfile);

       $file_name = $apt->upload_path."/$uppostid.catid";

       if (file_exists($file_name))
       {
           if($imagealign =="")
           $imagealign = $apt->getsettings("CatMagealign");
           $image[$uppostid] = "<img src=\"news.php?action=image&id=".$upid."\"  align=\"".$imagealign."\">";
           return $image;
       }
   }
   //unset($image);
   //return $image;
}
//---------------------------------------------------

// menu

//---------------------------------------------------
$archiveBy = 'month';
$archiveCount = 1;

class Monthly {

	var $MonthShift;
	//var $TimeStamp;
	var $arMonth=array("Jan"=>"�����",
		               "Feb"=>"������",
		               "Mar"=>"����",
		               "Apr"=>"�����",
		               "May"=>"����",
		               "Jun"=>"�����",
		               "Jul"=>"�����",
		               "Aug"=>"�����",
		               "Sep"=>"������",
		               "Oct"=>"������",
		               "Nov"=>"������",
		               "Dec"=>"������");
                 
	function Set_Shift($monthshift=0) {
		$this->MonthShift = $monthshift;
		//$this->TimeStamp = mktime(0,0,0,date('n')+$this->MonthShift,1,date('Y'));
	}

	function Show_Month()
    {

		$this->first_month_day = mktime(0,0,0,date("n")+$this->MonthShift,1,date('Y'));
		$this->last_month_day = mktime(0,0,0,date("n")+$this->MonthShift+1,0,date('Y'));
     }
     
	function Month_Name($shift=0)
    {
		$format = date("M - Y",  mktime(0,0,0,date('n')+$shift+$this->MonthShift,date('d'),date('Y')));
        foreach($this->arMonth as $key => $value )
		$format=str_replace($key, $value, $format);
        return $format;
       // return $this->arMonth[$format];
    }
}

$Monthly = new Monthly;
if($apt->get[archiveCount])
$Monthly->Set_Shift(intval($apt->get[archiveCount]));
else
$Monthly->Set_Shift();

$Monthly->Show_Month();
$lastarchive = $Monthly->first_month_day;
$nextarchive = $Monthly->last_month_day;
//echo  date("d -m -Y",$lastarchive). "<br>";
//echo  date("d-m -Y",$nextarchive). "<br>";
$menu = new menu;

if($apt->getsettings('use_adsin_news') == 'yes')
{
    $ads_head = $apt->ads_view_in('h');
    $ads_foot = $apt->ads_view_in('f');
}

if ($apt->get['action']=="" || $apt->get['action']=="list" )
{

     $apt->head(LANG_TITLE_NEWS."->".'����� ��������');

    $perpagelist       = $apt->getsettings("newsperpagelist");

    $perpage_comment   = $apt->getsettings("newsperpagecomment");
    
    $prev_archiveCount = intval($apt->get[archiveCount])-1;
    $index_middle .= "<br><br><img border=\"0\" dir=ltr src=\"images/next.gif\">  <a href=\"archive.php?archiveCount=$prev_archiveCount\">������</a>   ";

    $index_middle .= '( '.$Monthly->Month_Name() .' )';
    $next_archiveCount = 1+intval($apt->get[archiveCount]);
    if($apt->get[archiveCount] <0)
    
    $index_middle .= "    <a href=\"archive.php?archiveCount=$next_archiveCount\">������</a>  <img border=\"0\" dir=ltr src=\"images/prev.gif\"><br>";
    $index_middle .= "<br>";
    
    $getImageCat = getImageCat();


    $result = $apt->query ("SELECT rafia_news.*,COUNT(rafia_comment.news_id) as numrows
                                FROM rafia_news LEFT JOIN rafia_comment
                                ON  rafia_news.id = rafia_comment.news_id
                                WHERE rafia_news.allow = 'yes'
                                AND rafia_news.date_time > '".$lastarchive ."' and rafia_news.date_time < '".$nextarchive ."'
                                GROUP BY rafia_news.id
                                ORDER BY $order_by $order_dir
                                LIMIT $start,$perpagelist");




    while($row = $apt->dbarray($result))

    {

        @extract($row);

        $title         =  $apt->format_data_out($title);

        $name          =  $apt->format_data_out($name);

        $apt->numrows  =  $numrows ;

        $pagenum       =  $apt->pagenumlist ($perpage_comment,$id,"news.php");

        $title         =  $apt->title_cut($title,$apt->getsettings("max_title_cut"));

        $date          =  $timestamp;//date("d - m - Y",$timestamp); //
        $date          =  $apt->Hijri($date_time)." ".$apt->gettime($date_time);

        if($catmig == 0)

        {

            $newsimage = $apt->getnewsimage($id,$uploadfile);

        }

        else

        {

           $newsimage  = $getImageCat[$cat_id];

        }

		if($apt->getsettings('html_links')=='yes'){
		$news_link = "news_view_".$id.".html";
    		}else{
    		$news_link = "news.php?action=view&id=".$id;
    		}

        eval("\$index_middle .= \" " . $apt->gettemplate ( 'news_topic_list' ) . "\";");

    }

    $apt->numrows = $apt->dbnumquery("rafia_news","allow='yes'  AND date_time > '".$lastarchive ."' and date_time < '".$nextarchive ."'");
    $archiveCount = intval($apt->get[archiveCount]);
    $pagenum        = $apt->pagenum($perpagelist,"list&archiveCount=$archiveCount");

    if($pagenum)
    {
        eval("\$index_middle .= \" " . $apt->gettemplate ( 'news_list_pagenum' ) . "\";");
    }

    $menu->menuid =  $apt->getsettings("news_menuid");

    $right_menu   =  $menu->_menu(1);

    if($apt->getsettings("news_left_menu"))

    $left_menu    =  $menu->_menu(2);

    $apt->html_Output($left_menu);

}
$apt->foot($pageft);
?>