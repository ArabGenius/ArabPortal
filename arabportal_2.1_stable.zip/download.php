<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 01/01/2007 Time: 00:00 AM  |
+===========================================+
*/


require_once('global.php');
checkgroup('view_site');
checkgroup('view_download');

$menu = new menu;
$middle_menu_count  =  $apt->getsettings("count_middle_menu");
$middle_menu = "<table border=0 cellpadding=0 cellspacing=0 width=100%><tr valign=top>";
$middle_menus = $menu->_menu(3);
$ex = @explode('<!-- BLOCK END -->',$middle_menus);
$m=0;
foreach($ex as $amenu){
$middle_menu .= '<td valign=top>'.$amenu.'</td>';
$m++;
if($m==$middle_menu_count)$middle_menu .= "</tr>";
}
$middle_menu .= "</tr></table><br>";

if($apt->getsettings('use_adsin_download') == 'yes')
{
    $ads_head = $apt->ads_view_in('h');
    $ads_foot = $apt->ads_view_in('f');
}
//---------------------------------------------------

$cat_img = "prog.gif";

if ($apt->get['action']=="")
{

    $apt->head(LANG_TITLE_DOWNLOADING_SECTION);

    $downColcount = intval($apt->getsettings("downColcount"));

    $index_middle =  $apt->table_cat_module(LANG_TITLE_DOWNLOADING_SECTION);

    if($downColcount < 1 ) $downColcount = 1;
    $index_middle .= "<center><table border='0' width='100%' align='center' cellpadding='".$downColcount."'><tr>";

    $result = $apt->query("SELECT * FROM rafia_cat WHERE catType='3' and subcat='0' ORDER BY ordercat ASC");

     while($row = $apt->dbarray($result))
    {

        @extract($row);

         $numrows = $countopic + $apt->countcat($id,'countopic');

        $tdwidth =  100/$downColcount;
        $index_middle .= "<td align=\"center\" width=\"".$tdwidth."%\"  valign=\"top\">";

         eval("\$index_middle .= \" " . $apt->gettemplate ( 'download_cat' ) . "\";");

         $index_middle .= "</td>";
         $count++;
         if ($count ==  $downColcount)
         {
             $index_middle .= "</tr>";
             $count = 0;
         }
    }
     $index_middle .= "</tr></table><br>";


    $menu->menuid        = $apt->getsettings("down_menuid");

    $right_menu          = $menu->_menu(1);

    if($apt->getsettings("down_left_menu"))

    $left_menu           = $menu->_menu(2);

    $apt->html_Output($left_menu);

}

else if ($apt->get['action']=="byuser")

{

    checkcookie();

    

    $userid = $apt->setid('userid');

    $perpage           = $apt->getsettings("downperpagelist");

    $perpage_comment   = $apt->getsettings("downperpagecomment");

    

    $apt->head(LANG_TITLE_DOWNLOADING_SECTION." -> $title");

    

    $result = $apt->query("SELECT * FROM rafia_download

                                      WHERE allow ='yes'

                                      and userid=$userid

                                      ORDER BY id DESC

                                      LIMIT  $start,$perpage");



     while($row = $apt->dbarray($result))

     {

         @extract($row);



         $rating = @ceil($rating_total/$ratings);



         $rating_avg     = $apt->rating_avg($rating);

         $apt->numrows   =  $apt->dbnumquery("rafia_comment","down_id = $id");

         $pagenum        =  $apt->pagenumlist ($perpage_comment,$cat_id);

         $post_head      =  $apt->rafia_code($post_head);

         if($url== 'file')

            {

                $action = "<a href=\"$PHP_SELF?action=download&fileid=$id\">";

            }

            else

            {

                $action = "<a href=\"$PHP_SELF?action=download&fileid=$id\" target=_blank>";

            }

            if($downFrom =='1')

            {

                $download_images = "<a href=\"$PHP_SELF?action=view&id=$id\"><img border=0 src=\"themes/$themepath/dos.jpg\"></a>";



            }

            else

            {

                 $download_images = "$action<img border=0 src=\"themes/$themepath/download.jpg\"></a>";

                 $download_images .= "  <a href=\"$PHP_SELF?action=view&id=$id\"><img border=0 src=\"themes/$themepath/dos.jpg\"></a>";



            }



            if($exp_show != NULL)

            {

                  $exp_show = "<br><a href=\"$exp_show\" target=\"_blank\"><img border=\"0\" src=\"themes/$themepath/exp_show.gif\"></a>";



            }

            else

            {

                 unset($exp_show);

            }



         eval("\$index_middle .= \"" . $apt->gettemplate ( 'download_list' ) . "\";");



    }



    $apt->numrows   =  $apt->dbnumquery("rafia_download","allow='yes' and userid=$userid");

    $pagenum         = $apt->pagenum($perpage,"byuser&userid=$userid");

    ///////////// Myrosy Start (Add Page No.)///////////

    if($pagenum)

    {

        eval("\$list_pagenum = \" " . $apt->gettemplate ( 'download_list_pagenum' ) . "\";");

        $replace       = "<img border=\"0\" src=\"themes/$themepath/$cat_img\" align=\"left\">";

        $list_pagenum  = eregi_replace($replace,"",$list_pagenum);

        $index_middle  .= $list_pagenum;

    }

    ////////////// Myrosy End ///////////

    $menu->menuid        = $apt->getsettings("down_menuid");

    $right_menu          = $menu->_menu(1);

    if($apt->getsettings("down_left_menu"))

    $left_menu           = $menu->_menu(2);



    $apt->html_Output($left_menu);

}

else  if ($apt->get['action']=="view")

{

    $id = $apt->setid('id');

   

    if (( $apt->cookie['cgroup'] == $apt->a_g) || ( $apt->cookie['cgroup'] == $apt->m_g))

    {

        $row = $apt->dbfetch("SELECT * FROM rafia_download WHERE id = '$id'");

    }

    else

    {

        $row = $apt->dbfetch("SELECT * FROM rafia_download WHERE allow='yes' AND id='$id'");

    }



    @extract($row);



    $apt->head(LANG_TITLE_DOWNLOADING_SECTION." -> $title");



    $index_middle = $apt->table_cat_link(LANG_TITLE_DOWNLOADING_SECTION,$cat_id,$title);

    

    $topic_nav = $apt->next_old_post("SELECT id FROM rafia_download WHERE allow='yes' and cat_id='$cat_id' and date_time < '$date_time'  ORDER BY date_time DESC LIMIT 1");

    $topic_nav .= $apt->next_new_post("SELECT id FROM rafia_download WHERE allow='yes' and cat_id='$cat_id' and date_time > '$date_time'  ORDER BY date_time LIMIT 1");

    

    $postid = $id;



    if ($start==0)

    {

        $rating        =  @ceil($rating_total/$ratings);

        $rating_avg    =  $apt->rating_avg($rating);

        $title         =  $apt->format_data_out($title);

        $name          =  $apt->format_data_out($name);
        $post_head     = $apt->rep_words($post_head);
        $post_head     =  $apt->rafia_code($post_head);

        $date          =  $apt->Hijri($date_time)." ".$apt->gettime($date_time);
        $post       = $apt->rep_words($post);

        $post          =  $apt->rafia_code($post);

        

        if($formmember == 'yes')

        {

            $formmember = LANG_MSG_FOR_MEMBERS_ONLY;

        }

        else

        {

            $formmember = LANG_MSG_FOR_VISITORS_AND_MEMBERS;

        }

        if($url== 'file')

        {

            $action = "<a href=\"$PHP_SELF?action=download&fileid=$id\">";

        }

        else

        {

            $action = "<a href=\"$PHP_SELF?action=download&fileid=$id\" target=_blank>";

        }



     eval("\$index_middle .= \" " . $apt->gettemplate ( 'download_table' ) . "\";");

    }





      if($close == '0')
      {

            //$isclose     = "close&downid";
            $isclose    = "close&cat_id=$cat_id&downid";
            $replay_img  = "replay.gif";

        }
        else
        {

            //$isclose     = "open&downid";
            $isclose     = "open&cat_id=$cat_id&downid";
            $replay_img  = "close.gif";
        }

    if ( $apt->checkcadmincat($cat_id))
    {

        if($sticky == '0')
        {

            //$issticky = "sticky&downid";
            $issticky = "sticky&cat_id=$cat_id&downid";

        }
        else
        {

            //$issticky = "unsticky&downid";
            $issticky = "unsticky&cat_id=$cat_id&downid";

        }
      $index_middle .=  $apt->adminJump("edit&id","comment&cat_id=$cat_id&down_id",$issticky,$isclose);
    }



    $add_cat_id = $cat_id;

      

    if($c_comment > 0)

    {

        $perpage_comment   = $apt->getsettings("downperpagecomment");

        

        $result = $apt->query ("SELECT rafia_comment.* ,rafia_users.userid,rafia_users.username,

                                   rafia_users.datetime,rafia_users.allposts,rafia_users.signature,

                                   rafia_users.usergroup,rafia_users.homepage

                                   FROM rafia_comment,rafia_users

                                   WHERE down_id='$id'

                                   AND rafia_comment.userid = rafia_users.userid
                                   and allow='yes'
                                   ORDER BY id ASC

                                   LIMIT $start,$perpage_comment");

                                   

     $apt->numrows = $apt->dbnumquery("rafia_comment","down_id='$id' and allow='yes'");



     $pagenum = $apt->pagenum($perpage_comment,"view&id=$id");

   $able_addnew = $apt->retCheckGroup('add_download');
   $able_addreply = $apt->retCheckGroup('add_download_c');

   if($able_addnew==1)  $add_new_post = "<a href=\"$PHP_SELF?action=add&cat_id=$cat_id\"><img border='0' src='themes/$themepath/$cat_img' width='98' height='24'></a>";
   if($able_addreply==1) $add_new_reply = "<a href=\"$PHP_SELF?action=addcomment&id=$postid\"><img border='0' src='themes/$themepath/$replay_img'  width='88' height='24'></a>";

     eval("\$index_middle .= \" " . $apt->gettemplate ( 'post_tools' ) . "\";");



    while($row = $apt->dbarray($result))

    {

        @extract($row);

        if($userid == 0 )

         {

             $usertitle    =  $username;

             $username     =  $apt->format_data_out($name);

             $datetime     =  $apt->Hijri($date_time);

             $allposts     =  1;

         }

         else

         {

             $usertitles    =  explode("-", $apt->userRating($allposts));

		if( ($usergroup == $apt->a_g) || ($usergroup == $apt->m_g)){
            $usertitle     =  $apt->usergroup($usergroup);
		}else{
            $usertitle     =  $usertitles[1];
		}

             $userimgtitle  =  $usertitles[0];

             $username      =  $apt->format_data_out($username);

             $homepage      =  $apt->addToURL ($homepage);

             $datetime      =  $apt->Hijri($datetime);

             if($usesig == 1)

             {

                 $signature =  $apt->format_data_out ($signature);

             }else{

                 unset($signature);

             }

         }

         

         if ($apt->retcheckgroup('download_news_file'))

         {

             $upload_file    =  $apt->getuploadfile($uploadfile);

         }

        // $upload_file    =  $apt->getuploadfile($uploadfile);

         $title          =  $apt->format_data_out($title);

         $date           =  $apt->Hijri($timestamp)." ".$apt->gettime($timestamp);

         $comment        =  $apt->rafia_code($comment);
         $comment        =  $apt->rep_words($comment);

         $apt->color($color);

         eval("\$index_middle .= \" " . $apt->gettemplate ( 'download_comment_table' ) . "\";");

     }

   $able_addnew = $apt->retCheckGroup('add_download');
   $able_addreply = $apt->retCheckGroup('add_download_c');

   if($able_addnew==1)  $add_new_post = "<a href=\"$PHP_SELF?action=add&cat_id=$cat_id\"><img border='0' src='themes/$themepath/$cat_img' width='98' height='24'></a>";
   if($able_addreply==1) $add_new_reply = "<a href=\"$PHP_SELF?action=addcomment&id=$postid\"><img border='0' src='themes/$themepath/$replay_img'  width='88' height='24'></a>";
       eval("\$index_middle .= \" " . $apt->gettemplate ( 'post_tools' ) . "\";");

    }
    else
    {
   $able_addnew = $apt->retCheckGroup('add_download');
   $able_addreply = $apt->retCheckGroup('add_download_c');

   if($able_addnew==1)  $add_new_post = "<a href=\"$PHP_SELF?action=add&cat_id=$cat_id\"><img border='0' src='themes/$themepath/$cat_img' width='98' height='24'></a>";
   if($able_addreply==1) $add_new_reply = "<a href=\"$PHP_SELF?action=addcomment&id=$postid\"><img border='0' src='themes/$themepath/$replay_img'  width='88' height='24'></a>";

       eval("\$index_middle .= \" " . $apt->gettemplate ( 'post_tools' ) . "\";");

    }

    $menu->menuid        = $apt->getsettings("down_menuid");

    $right_menu          = $menu->_menu(1);

    if($apt->getsettings("down_left_menu"))

    $left_menu           = $menu->_menu(2);

    $apt->html_Output($left_menu);

}

else  if ($apt->get['action']=="list")

{

    $cat_id = $apt->setid('cat_id');

    

    $perpage           = $apt->getsettings("downperpagelist");

    $perpage_comment   = $apt->getsettings("downperpagecomment");



    $result = $apt->query("SELECT * FROM rafia_cat WHERE id=$cat_id ORDER BY id DESC");



    $row = $apt->dbarray($result);



    @extract($row);



    $apt->head(LANG_TITLE_DOWNLOADING_SECTION." -> $title");

    

    if(( $groupview !=0 ) && (!in_array ( $apt->cookie['cgroup'], explode(",", $groupview) )))

    {

        eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");

        $apt->foot($pageft);

        exit;

    }



    

    $title         =  $apt->format_data_out($title);

    $dscin         =  $apt->format_data_out($dscin);

    

    $index_middle  = $apt->table_cat_link(LANG_TITLE_DOWNLOADING_SECTION) ;



    $result = $apt->query("SELECT * FROM rafia_cat WHERE catType='3' and subcat ='$cat_id' ORDER BY ordercat ASC");



    if($apt->dbnumrows($result)>0)

    {

        while($row = $apt->dbarray($result))

        {

            @extract($row);

            $title         =  $apt->format_data_out($title);

            $dsc           =  $apt->format_data_out($dsc);

            $numrows       =  $countopic + $apt->countcat($id,'countopic');

            eval("\$index_middle .= \" " . $apt->gettemplate ( 'download_cat' ) . "\";");



        }

    }





    $Jump = $apt->listJumpf("$PHP_SELF?action=list&cat_id=","3");



     eval("\$index_middle .= \" " . $apt->gettemplate ('download_cat_tools') . "\";");



    $result = $apt->query("SELECT * FROM rafia_download

                                      WHERE allow='yes'

                                      and cat_id=$cat_id

                                      and sticky='1'

                                      ORDER BY id DESC");

     while($row = $apt->dbarray($result))

     {
         @extract($row);
         $rating         = @ceil($rating_total/$ratings);
         $rating_avg     = $apt->rating_avg($rating);
         $apt->numrows   = $apt->dbnumquery("rafia_comment","down_id = $id");
         $pagenum        = $apt->pagenumlist ($perpage_comment,$cat_id);
         $post_head     = $apt->rep_words($post_head);
         $post_head     =  $apt->rafia_code($post_head);

         if($url== 'file')
         {
             $action = "<a href=\"$PHP_SELF?action=download&fileid=$id\">";
         }
         else
         {
             $action = "<a href=\"$PHP_SELF?action=download&fileid=$id\" target=_blank>";
         }
            if($downFrom =='1')
            {
                 $download_images = "<a href=\"$PHP_SELF?action=view&id=$id\"><img border=0 src=\"themes/$themepath/dos.jpg\"></a>";

                $download_images .= "$action<img border=0 src=\"themes/$themepath/download.jpg\"></a>";
            }
            else
            {
                 $download_images = "$action<img border=0 src=\"themes/$themepath/download.jpg\"></a>";
            }

          eval("\$index_middle .= \"" . $apt->gettemplate ( 'download_list' ) . "\";");

    }

    $result = $apt->query("SELECT * FROM rafia_download
                                      WHERE allow ='yes'
                                      and cat_id =$cat_id
                                      and sticky != '1'
                                      ORDER BY id DESC
                                      LIMIT  $start,$perpage");

     while($row = $apt->dbarray($result))
     {
         @extract($row);
         $rating = @ceil($rating_total/$ratings);

         $rating_avg     = $apt->rating_avg($rating);
         $apt->numrows   =  $apt->dbnumquery("rafia_comment","down_id = $id");
         $pagenum        =  $apt->pagenumlist ($perpage_comment,$cat_id);
         $post_head     = $apt->rep_words($post_head);
         $post_head      =  $apt->rafia_code($post_head);

         if($url== 'file')
            {
                $action = "<a href=\"$PHP_SELF?action=download&fileid=$id\">";
            }
            else
            {
                $action = "<a href=\"$PHP_SELF?action=download&fileid=$id\" target=_blank>";
            }

            if($downFrom =='1')
            {
                $download_images = "<a href=\"$PHP_SELF?action=view&id=$id\"><img border=0 src=\"themes/$themepath/dos.jpg\"></a>";
            }
            else
            {
                 $download_images = "$action<img border=0 src=\"themes/$themepath/download.jpg\"></a>";
                 $download_images .= "  <a href=\"$PHP_SELF?action=view&id=$id\"><img border=0 src=\"themes/$themepath/dos.jpg\"></a>";
            }

            if($exp_show != NULL)
            {
                  $exp_show = "<br><a href=\"$exp_show\" target=\"_blank\"><img border=\"0\" src=\"themes/$themepath/exp_show.gif\"></a>";
            }
            else
            {
                 unset($exp_show);
            }

         eval("\$index_middle .= \"" . $apt->gettemplate ( 'download_list' ) . "\";");
    }

    $apt->numrows   =  $apt->dbnumquery("rafia_download","allow='yes' and cat_id=$cat_id");

    $pagenum         = $apt->pagenum($perpage,"list&cat_id=$cat_id");

    if($pagenum)

    {

        eval("\$index_middle .= \" " . $apt->gettemplate ( 'download_list_pagenum' ) . "\";");

    }



    $menu->menuid        = $apt->getsettings("down_menuid");

    $right_menu          = $menu->_menu(1);

    if($apt->getsettings("down_left_menu"))

    $left_menu           = $menu->_menu(2);

    

    $apt->html_Output($left_menu);



}

else  if ($apt->get['action']=="add")

{

    $cat_id = $apt->setid('cat_id');

    checkgroup('add_download');

    $apt->head(LANG_TITLE_ADD_PROGRAM);

    $fo = new form;

    $index_middle =  $fo->download_form('add');

    $right_menu   =  $menu->_menu(1);

    $apt->html_Output("");

}

else if($apt->get['action']=="insert")

{



    checkgroup('add_download');



    extract($HTTP_POST_VARS);

    

    $apt->upload     = $apt->files["uploadfile"];

    

   $arr_post_vars = array($title,

                          $post_head,

                          $apt->cookie['cname']);

                          

    $userid     = $apt->format_data($apt->cookie['cid']);



    if(isset($apt->post['name']) && $apt->cookie['cid']== $apt->Guestid)

    {

         $name  = $apt->format_data($apt->post['name']);

         if (!$apt->checkifues("username",$name))

         {

             $apt->errmsg (LANG_ERROR_USERNAME_EXISTED);

         }

    }

    else

    {

        $name  = $apt->format_data($apt->cookie['cname']);

    }

    

    if (!$apt->full($arr_post_vars))

    {

        $apt->errmsg(LANG_ERROR_VALIDATE);

    }



    if (!$apt->txtcounmxs($post_head,$apt->getsettings("txtcount9")))

    {

        $apt->errmsg(LANG_ERROR_LETTER_MAX);

    }



    if (!$apt->txtcounmxs($post,$apt->getsettings("txtcount4")))

    {

        $apt->errmsg(LANG_ERROR_LETTER_MAX);

    }

    

 /////////////

    if ($apt->retcheckgroup('upload_download_file'))

    {

        if (is_uploaded_file($apt->files["phpfile"]['tmp_name']))

        {

            $up  = new RaFiaUpload;

            $up->cat ="down";

            $up->uploads = $apt->files["phpfile"];



         if ($up->uploads["size"] > ($apt->getsettings("downfilemxsize")*1024))

         {

             $apt->errmsg(LANG_ERROR_SIZE_MUST_LESS.$apt->getsettings("downfilemxsize")." kb");

         }



         if ($up->checkend($apt->getsettings("downfileupload")) == false)

         {

             $apt->errmsg("��� ����� �� ������� �� ����  ����� ������� <br>".$apt->getsettings("downfileupload"));

         }



         $is_uploaded_file =1;

         $url ="file";



      }

 }



    if(!isset($url))

    {

          $apt->errmsg(LANG_ERROR_FILE_URL);

    }

    

    $title     = $apt->format_data($title);

    $size      = $apt->format_data($size);

    $url       = $apt->format_data($url);

    $post_head = $apt->format_post($post_head);

    $post      = $apt->format_post($post);

    $downFrom  = $apt->format_data($downFrom);

    $exp_show  = $apt->format_data($exp_show);

    $userid     = intval($apt->format_data($apt->cookie['cid']));
    $cat_id     = intval($apt->format_post($cat_id));

    if (!$apt->full($post))

    {

         $downFrom  ='0';

    }

    $downallow = $apt->retcheckgroup('stat_download',1);

    

    $timestamp = time();

    
    $Spams  = new Spams();

    if( $Spams->checkSpams() == false )
    {
        $apt->bodymsg(LANG_ERROR_WAIT_SECONDS,"$PHP_SELF?action=list&cat_id=$cat_id");
    }

   $result = $apt->query("insert into rafia_download (cat_id,

                                                        title,

                                                        date_time,

                                                        userid,

                                                        name,

                                                        size,

                                                        post_head,

                                                        post,

                                                        url,

                                                        exp_show,

                                                        formmember,

                                                        downFrom,

                                                        allow)

                                                  values

                                                        ('$cat_id',

                                                        '$title',

                                                        '$timestamp',

                                                        '$userid',

                                                        '$name',

                                                        '$size',

                                                        '$post_head',

                                                        '$post',

                                                        '$url',

                                                        '$exp_show',

                                                        '$formmember',

                                                        '$downFrom',

                                                        '$downallow')");



   if ($result)

   {

       $id = $apt->insertid();

       if ($is_uploaded_file ==1)

        {

            $up->uploadfile();

            $upid = $apt->insertid();

            $apt->query("update rafia_download set uploadfile  = '$upid' where id = '$id'");

        }
        $Counter->increment('downCount');

       $apt->query("UPDATE rafia_cat SET countopic  = countopic+1, lastpostid ='$id' WHERE id = '$cat_id'");

       if($userid > 0 )

       $apt->query ("UPDATE rafia_users SET allposts = allposts+1, lastadd='$timestamp' WHERE userid = '$userid' ");

         $mail = new email;

         $mail->send_to_moderate($cat_id);

         if(($H == 1) && ($userid > 0 ))

        {

            $apt->query("insert into rafia_alert (down_id,

                                                    userid)

                                              values

                                                    ('$id',

                                                    '$userid')");

        }

          $apt->query("UPDATE rafia_users SET allposts = allposts+1

                                          WHERE userid = '$userid'");

                                          

       if ($downallow!="yes")

       {

           $url = "$PHP_SELF?action=list&cat_id=$cat_id";



             $apt->bodymsg(LANG_MSG_THREAD_HAS_ADDED,$url);

        }

        else

        {

            $url = "$PHP_SELF?action=view&id=$id";

            

            $apt->bodymsg(LANG_MSG_POST_HAS_BEEN_ADDED,$url);

        }



    }

    else

    {

        $apt->errmsg(LANG_ERROR_ADD_DB);

    }

}

else if ($apt->get['action']=="edit")

{

    $id = $apt->setid('id');



    if(!$apt->retcheckgroup('edit_download_own')&&!$apt->retcheckgroup('edit_download') )

    {

        $apt->errmsg(LANG_ERROR_CAN_NOT_EDIT);

    }

      

    $result = $apt->query("select * from rafia_download where id='$id'");



    $apt->row = $apt->dbarray($result);



        if ($apt->cookie['cid'] == $apt->row['userid'] || $apt->checkcadmincat($apt->row['cat_id']))

  {

            $apt->head(LANG_TITLE_ADD_PROGRAM);



            $fo = new form;

            $index_middle =  $fo->download_form('edit');

            $right_menu   =  $menu->_menu(1);

            $apt->html_Output("");

       }

       else

       {

            $apt->errmsg(LANG_ERROR_CAN_NOT_EDIT);

      }



}

else if($apt->get['action']=="UD")

{

    $id = $apt->setid('id');

    if(!$apt->retcheckgroup('edit_download_own')&&!$apt->retcheckgroup('edit_download') )

    {

        $apt->head($head_err);

        $apt->errmsg(LANG_ERROR_CAN_NOT_EDIT);

    }



    if ($apt->post['del'] =='1')

    {

        $apt->delmsg($cat_id,$id);

    }

    

    @extract($HTTP_POST_VARS);

   $arr_post_vars = array($title,

                          $post_head,

                          $apt->cookie['cname']);

    if (!$apt->full($arr_post_vars))

    {

        $apt->errmsg(LANG_ERROR_VALIDATE);

    }



    if (!$apt->txtcounmxs($post_head,$apt->getsettings("txtcount9")))

    {

        $apt->errmsg(LANG_ERROR_LETTER_MAX);

    }



    if (!$apt->txtcounmxs($post,$apt->getsettings("txtcount4")))

    {

        $apt->errmsg(LANG_ERROR_LETTER_MAX);

    }

    

    $allow = $apt->adminunset($allow);



    $formmember  =  $apt->adminunset($formmember);

    $title       =  $apt->format_data($title);

    $post_head   =  $apt->format_post($post_head);

    $post        =  $apt->format_post($post);

    $exp_show    = $apt->format_data($exp_show);

     if ($editupload =="delete")

    {

        $row = $apt->dbfetch("SELECT * FROM rafia_upload WHERE upid='$uploadfile'");

        @extract($row);

        $filename = $apt->upload_path."/".$uppostid.".".$upcat;

        if(@unlink($filename))

        {

           $apt->query("DELETE FROM rafia_upload WHERE upid='$uploadfile'");

           $apt->query("update rafia_forum set uploadfile = '0' where id = '$id'");

        }



    }

    if($editupload =="new")

    {

        if ($apt->retcheckgroup('upload_download_file'))

        {

            if (is_uploaded_file($apt->files["phpfile"]['tmp_name']))

            {

                $up  = new RaFiaUpload;

                $up->cat ="down";

                $up->uploads = $apt->files["phpfile"];

                if ($up->uploads["size"] > ($apt->getsettings("downfilemxsize")*1024))

                {

                    $apt->errmsg(LANG_ERROR_SIZE_MUST_LESS.$apt->getsettings("downfilemxsize")." kb");

                }



                if ($up->checkend($apt->getsettings("downfileupload")) == false)

                {

                    $apt->errmsg("��� ����� �� ������� �� ����  ����� ������� <br>");

                }

                $up->uploadfile(1);

            }

        }

    }

    $downFrom  = $apt->format_data($downFrom);

    if (!$apt->full($post))

    {

         $downFrom  ='0';

    }

    if ($apt->checkcadmincat($cat_id))

    {

             $result= $apt->query("update rafia_download set cat_id='$cat_id',

                                                               title='$title',

                                                               size='$size',

                                                               post_head='$post_head',

                                                               post='$post',

                                                               url='$url',

                                                               exp_show='$exp_show',

                                                               formmember='$formmember',

                                                               allow='$allow'

                                                               where id='$id'");

    }

    else

    {

            $result= $apt->query("update rafia_download set title='$title',

                                                              size='$size',

                                                              post_head='$post_head',

                                                              post='$post',

                                                              url='$url',

                                                              formmember='$formmember'

                                                              where id='$id'");

    }

    

    $url = "$PHP_SELF?action=view&id=$id";



    if ($result)

    {



        $apt->bodymsg(LANG_MSG_YOUR_POST_HAS_EDITED,$url);

    }

    else

    {



        

        $apt->bodymsg(LANG_ERROR_ADD_DB,$url);

    }

}

else if ($apt->get['action']=="addcomment")

{

    checkgroup('add_download_c');

    

     $id = $apt->setid('id');



     $result = $apt->query("SELECT * FROM rafia_download WHERE id='$id'");



     $apt->row = $apt->dbarray($result);



     @extract($apt->row);

     

     if ($apt->close == 1)

     {

         $apt->errmsg(LANG_ERROR_POST_CLOSED);

     }



     if(isset($apt->get[qc]))

     {

         $qc = $apt->setid('qc');

         $result = $apt->query("select name,comment from rafia_comment where id='$qc' and allow='yes'");

         $row = $apt->dbarray($result);

         $apt->row['quote'] = "\n\n\n[QUOTE]������ :".$row['name']."\n".$row['comment']."[/QUOTE]";

     }



        $apt->head(LANG_TITLE_ADD_COMMENT);

        $fo = new form;
         $captcha = rand(1000,9999);
         $fo->cap = $captcha;
         $_SESSION['memccode']= $captcha;

        $index_middle  = $fo->comment_form('add',0);

        $right_menu    =  $menu->_menu(1);

        $apt->html_Output("");

}

else if ($apt->get['action']=="insertcomment" )

{

      checkgroup('add_download_c');

    @extract($HTTP_POST_VARS);

    $pre_ses = $_SESSION['memccode'];
    $newcode = intval($newcode);

    $this_url = explode('/',$_SERVER['HTTP_HOST']);
    $reff_url = explode('/',$_SERVER['HTTP_REFERER']);

    if($this_url[0] !== $reff_url[2]){
    $apt->bodymsg('���� ... �� ����� ����� ����� �� ���� ������',"index.php");
    }

    if($spam !== 'commenttnotspam'){
    $apt->bodymsg('���� ... ��� ������� ��� ������',"news.php?action=addcomment&id=$id");
    exit;
    }

    $userid     = $apt->format_data($apt->cookie['cid']);

    $name       = $apt->format_data($apt->cookie['cname']);

    if (!$apt->full($post))

    {

        $apt->errmsg(LANG_ERROR_VALIDATE);

    }



    if (!$apt->txtcounmxs($post,$apt->getsettings("txtcount6")))

    {

        $apt->errmsg(LANG_ERROR_LETTER_MAX);

    }



    $title   = $apt->format_data($title);



    $comment = $apt->format_post($post);



    $timestamp = time();
    $Spams  = new Spams();

    if( $Spams->checkSpams() == false )
    {
        $apt->bodymsg(LANG_ERROR_WAIT_SECONDS,"$PHP_SELF?action=list&cat_id=$cat_id");
    }
    

    if ($apt->retcheckgroup('upload_comment_file'))
    {

        if (is_uploaded_file($apt->files["phpfile"]['tmp_name']))

        {

            $up  = new RaFiaUpload;

            $up->cat ="comment";

            $up->uploads = $apt->files["phpfile"];

            if ($up->uploads["size"] > ($apt->getsettings("commentfilemxsize")*1024))

            {

                $apt->errmsg(LANG_ERROR_SIZE_MUST_LESS.$apt->getsettings("commentfilemxsize")." kb");

            }

            if ($up->checkend($apt->getsettings("commentfileupload")) == false)

            {

                $apt->errmsg("��� ����� �� ������� �� ����  ����� ������� <br>");

            }

        }

    }

    $commallow     = $apt->retcheckgroup('allow_comment',1);
    $result = $apt->query ("insert into rafia_comment (down_id,

                                                         title,

                                                         userid,

                                                         name,

                                                         comment,

                                                         cat_id,

                                                         timestamp,allow)

                                                   values

                                                         ('$post_id',

                                                         '$title',

                                                         '$userid',

                                                         '$name',

                                                         '$comment',

                                                         '$cat_id',

                                                         '$timestamp','$commallow')");

    if ($result)

    {

        $commentid = $apt->insertid();

       $Counter->increment('commentCount');

        if (is_uploaded_file($apt->files["phpfile"]['tmp_name']))

         {



              $up->uploadfile();

              $upid = $apt->insertid();

              $apt->query("update rafia_comment set

                             uploadfile  = '$upid'

                             where id = '$commentid'");



        }

        

        $apt->query("UPDATE rafia_cat SET countcomm = countcomm+1, lastpostid='$post_id' WHERE id = '$cat_id'");

        $apt->query ("UPDATE rafia_download SET c_comment = c_comment+1 WHERE id = '$post_id' ");

        $apt->query ("UPDATE rafia_users SET allposts = allposts+1, lastadd='$timestamp' WHERE userid = '$userid' ");



        $perpage_comment   = $apt->getsettings("downperpagecomment");

        $url  =  $apt->getcommenturl($commentid,down_id);



        $mail = new email;



        $mail->send_to_users('down_id',

                              $userid,

                              $post_id,

                              $url,

                              $H);



        $apt->bodymsg(LANG_MSG_POST_HAS_BEEN_ADDED,$url);

    }

    else

    {

        $url = "download.php?action=view&id=$post_id";



        $apt->bodymsg(LANG_ERROR_ADD_DB,$url);

    }

}

else if($apt->get['action']=="editcomment")

{

    checkgroup('add_download_c');



    $id = $apt->setid('id');

    

      if(!$apt->retcheckgroup('edit_comment_own') &&  !$apt->retcheckgroup('edit_comment ') )

      {

          $apt->head(LANG_ERROR);

          $apt->errmsg(LANG_ERROR_CAN_NOT_EDIT);

      }

      

      $result = $apt->query("select * from rafia_comment where id='$id' and allow='yes'");



      $apt->row = $apt->dbarray($result);



      $post_id = $apt->row['down_id'];



      if ($apt->cookie['id'] == $apt->row['userid'] || $apt->checkcadmincat($apt->row['cat_id']))

        {

            $apt->head(LANG_TITLE_EDIT_POST);

             $fo = new form;

             $index_middle .= $fo->comment_form('edit');

             $right_menu    =  $menu->_menu(1);

             $apt->html_Output("");



       }

       else

       {

           $apt->errmsg(LANG_ERROR_CAN_NOT_EDIT);

      }

}

else if($apt->get['action']=="UC")

{

     $id = $apt->setid('id');

     

    if(!$apt->retcheckgroup('edit_comment_own') &&  !$apt->retcheckgroup('edit_comment') )

    {

        $apt->head(LANG_ERROR);

        $apt->errmsg(LANG_ERROR_CAN_NOT_EDIT);

    }

    

    extract($HTTP_POST_VARS);



    if ($apt->post['del'] =='1')

    {

        $cat_id = $apt->post['cat_id'] ;

        $apt->delmsg($cat_id,'',$id);

    }



    if (!$apt->full($post))

    {

        $apt->errmsg(LANG_ERROR_VALIDATE);

    }



    if (!$apt->txtcounmxs($post,$apt->getsettings("txtcount6")))

    {

        $apt->errmsg(LANG_ERROR_LETTER_MAX);

    }



    //////////////////////////////////////////////



      $apt->delete_from_upload($id);

      

     //////////////////////////////////////////////

     

      $title   = $apt->format_data($title);

      $comment = $apt->format_post($post);



    if ($apt->checkcadmincat($apt->post['cat_id']) )

    {

           $result= $apt->query("update rafia_comment set

                                          title = '$title',
                                        allow = '$allow',

                                          comment = '$comment'

                                          where id = '$id'");

    }

    else

    {

        $result = $apt->query("update rafia_comment set
                                        allow = '$allow',

                                        comment = '$comment'

                                        where id = '$id'");

    }



    $url = "$commentpage#comment$id";

    if ($result)

    {

        

        $apt->bodymsg(LANG_MSG_YOUR_POST_HAS_EDITED,$url);

    }

    else

    {

        $apt->bodymsg(LANG_ERROR_ADD_DB,$url);

    }



}
else if ($apt->get['action']=="download")
{

    $fileid = $apt->setid('fileid');
    $result = $apt->query("SELECT * FROM rafia_download WHERE id=$fileid");

    $row = $apt->dbarray($result);

    @extract($row);

    if(($formmember == "yes") &&($apt->cookie['clogin'] != "rafiaphp"))

    {

        $apt->errmsg(LANG_ERROR_MUST_LOGIN);

    }

        

        if( $clicks == "" )

        {

            $clicks = 0;

        }

        

        $clicks = $clicks + 1;



        if($url== 'file')

        {

             $result = $apt->query("SELECT * FROM rafia_upload WHERE upid='$uploadfile'");



             if($apt->dbnumrows($result)>0)

             {

                 $rowfile = $apt->dbarray($result);

                 @extract($rowfile);

                 $pathfile = $apt->upload_path."/".$uppostid.".".$upcat;

                 $download = new downloadfile($pathfile,$upname,$upsize);



                 if(!$download->download())

                 {

                     $apt->errmsg(_FILE_NOT_FOUND);

                 }

                 else

                 {

                     $apt->query("UPDATE rafia_upload SET upclicks = upclicks+1 WHERE upid = '$id'");

                     $apt->query("update rafia_download set clicks='$clicks' where id=$fileid");

                 }

             }

             else

             {

                 $apt->errmsg (LANG_MSG_NOT_VIEW_ATTACHMENTS);

             }



        }

        else

        {

        

        $result = $apt->query("update rafia_download set clicks='$clicks' where id=$fileid");



        if($result)

        {

            $redirect="Location:$url";

            header($redirect);

        }

    }

}

//---------------------------------------------------

//

//---------------------------------------------------

else if($apt->get['action']=="admin")

{

    $apt->head(LANG_TITLE_MODERATE_POSTS);



    if (( $apt->cookie['cgroup'] ==  $apt->a_g) || ( $apt->cookie['cgroup'] ==  $apt->m_g))

    {

        if ( $apt->cookie['cgroup'] == $apt->a_g)

        {

            $result = $apt->query("SELECT * FROM rafia_cat WHERE catType='3' ORDER BY id DESC");

        }

        else

        {

            $result = $apt->query("SELECT rafia_cat.*

                                 FROM rafia_cat,rafia_moderate

                                 WHERE rafia_cat.catType='3' AND rafia_cat.id=rafia_moderate.moderatecatid

                                 AND rafia_moderate.moderateid =".$apt->cookie['cid']."

                                 ORDER BY id DESC");

        }

                             

        $countwit = $apt->dbnumquery("rafia_download","allow='wit'");



        if ($countwit == "")

        {

            $countwit=" �� ����";

        }



        $index_middle .=  $apt->admintablehead("$PHP_SELF?action=wait","����� ���� �������");

        while($row = $apt->dbarray($result))

        {

            @extract($row);



                $numrows = $apt->dbnumquery("rafia_download","cat_id='$id'");

                $index_middle .= $apt->admintablecell("$PHP_SELF?action=down&cat_id=$id");



        }

        $index_middle .= $apt->admintableclose();

        $apt->html_Output($left_menu);

    }

    else

    {

        $apt->head(LANG_TITLE_LOG_IN);

        eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");

        $apt->foot($pageft);

        exit;

    }

}

//---------------------------------------------------

//

//---------------------------------------------------



else if($apt->get['action']=="down")

{

    $perpage = 50;



    $cat_id = $apt->setid('cat_id');



    if( $apt->checkcadmincat($cat_id) )

    {

       $apt->head(LANG_TITLE_MODERATE_POSTS);



       $result = $apt->query ("SELECT * FROM rafia_download WHERE

                                cat_id=$cat_id ORDER BY id DESC

                                LIMIT  $start,$perpage");



       $apt->numrows = $apt->dbnumquery("rafia_download","allow='yes' and cat_id=$cat_id");



       $index_middle .= $apt->pagenum($perpage,"forum&cat_id=$cat_id");







        $index_middle  .=$apt->admin_form_opan("dodown");



         $index_middle .=$apt->admin_table_head("������� ���� �������");



       while($apt->row =$apt->dbarray($result))

       {

           $result2 = $apt->query("SELECT down_id FROM rafia_comment WHERE down_id=" . $apt->row["id"] . "");



           $numrows = $apt->dbnumrows($result2);



           $index_middle .=  $apt->admin_table_cell("cat_id=$cat_id&id","edit","");

       }



         $index_middle .= $apt->admin_table_close();



        $index_middle .=  $apt->admin_form_close('3');



       $apt->html_Output($left_menu);



}

else

{

       $apt->head(LANG_TITLE_LOG_IN);



      eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");





}

}

//---------------------------------------------------

//

//---------------------------------------------------



else if( $apt->get['action']== "dodown" )

{



    if ( $apt->checkcadmincat($apt->post['cat_id']))

    {

        $cat_id =  $apt->post['cat_id'];

        $catid  =  $apt->post['catid'];



        if (count($apt->post['do']) > 0)

        {

             if($apt->post['move'])

             {

                 foreach($apt->post['do'] as $id)

                 {



                    $result = $apt->query("update rafia_download set cat_id='$catid' where id='$id'");

                    $result = $apt->query("update rafia_comment set cat_id='$catid' where thread_id='$id'");

                }

                if ($result)

                {

                    $numrows = $apt->dbnumquery("rafia_download","cat_id='$catid'");

                    $result  = $apt->query("update rafia_cat set countopic='$numrows' where id='$catid'");

                    $numrows = $apt->dbnumquery("rafia_comment","cat_id='$catid'");

                    $result  = $apt->query("update rafia_cat set countcomm='$numrows' where id='$catid'");

                    $numrows = $apt->dbnumquery("rafia_download","cat_id='$cat_id'");

                    $result  = $apt->query("update rafia_cat set countopic='$numrows' where id='$cat_id'");

                    $numrows = $apt->dbnumquery("rafia_comment","cat_id='$cat_id'");

                    $result  = $apt->query("update rafia_cat set countcomm='$numrows' where id='$cat_id'");



                    $apt->bodymsg(LANG_MSG_LOGED_IN,$apt->refe);

                 }



            }

            elseif($apt->post['del'])

            {

                foreach($apt->post['do'] as $id)

                {





                    $result  = $apt->query("delete from  rafia_download where id='$id'");

                    $filename = $apt->upload_path."/".$id.".down";

                    @unlink($filename);

                    if($apt->getuploadsdb($id,'down_id')){

                        $apt->query("delete from  rafia_comment where down_id='$id'");

                    }

                }

                if ($result)

                {

                    $numrows = $apt->dbnumquery("rafia_download","cat_id='$cat_id'");

                    $result  = $apt->query("update rafia_cat set countopic='$numrows' where id='$cat_id'");

                    $numrows = $apt->dbnumquery("rafia_comment","cat_id='$cat_id'");

                    $result  = $apt->query("update rafia_cat set countcomm='$numrows' where id='$cat_id'");



                    $apt->bodymsg(LANG_MSG_POST_HAS_BEEN_DELETED,$apt->refe);

                }

            }

            elseif($apt->post['allow'])

            {

                 foreach($apt->post['do'] as $id)

                 {

                    $result = $apt->query("update rafia_download set allow='yes' where id=$id");

                 }

                 if ($result)

                 {

                     $apt->bodymsg(LANG_MSG_POST_HAS_APPROVED,$apt->refe);

                }

             }

         }

         else

        {

            $apt->errmsg(LANG_ERROR_CHOICE);

        }

    }

     else

    {

         $apt->errmsg(LANG_ERROR_DEL_BY_ADMIN);



}

}

elseif ($apt->get['action']=="comment")

{

    $cat_id = $apt->setid('cat_id');
    $id = $apt->setid('down_id');

   if( !$apt->checkcadmincat($cat_id) )

   {

       $apt->head(LANG_TITLE_LOG_IN);



       eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");



      exit;

   }



    $apt->head(LANG_TITLE_MODERATE_POSTS);



    $result = $apt->query("SELECT * FROM rafia_comment WHERE

                             down_id='$id' ORDER BY id ASC");



    if($apt->dbnumrows($result) > 0)

    {

         $index_middle .=  $apt->admin_form_opan("deletecomment&cat_id=".$cat_id);



         $index_middle .=   $apt->admin_table_head("����� ������ ����������");



        while($apt->row =  $apt->dbarray($result))

        {

              $apt->row["title"] = "������ : ".$apt->row['name']."<hr>".$apt->rafia_code($apt->row['comment']);





            $index_middle .=   $apt->admin_table_cell("","editcomment","","");

        }



         $index_middle .=   $apt->admin_table_close();



         $index_middle .=  $apt->admin_form_close(0,0);



    }

    else

    {

    $index_middle .=  "<p>&nbsp;������ ���� �� ��� ������� .</p>";

    }

    $apt->html_Output($left_menu);



}

else if( $apt->get['action'] == "del" )
{

    $cat_id = $apt->post['cat_id'];



    if((!$apt->checkcadmincat($cat_id)) ||(!$apt->checkcmodcat('can_delete')))

    {

       $apt->head(LANG_TITLE_LOG_IN);



      eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");



      exit;

   }

   if(!empty( $apt->post['idp']))
    {

          $id = $apt->post['idp'];


        $result = $apt->query("delete from  rafia_download where id=$id");

        if($result)

        {

            $filename = $apt->upload_path."/".$id.".forum";

            @unlink($filename);

            if($apt->getuploadsdb($id,'down_id')){

               $apt->query("delete from  rafia_comment where down_id='$id'");

           }



        }

    }

    else if(!empty( $apt->post['idc']))
    {

         $id = $apt->post['idc'];

         $filename = $apt->upload_path."/".$id.".comment";

         @unlink($filename);

         $result = $apt->query("delete from  rafia_comment where id=$id");

    }

    if($result)

    {

        $Rurl = "download.php?action=list&cat_id=$cat_id";

        $apt->bodymsg(LANG_MSG_POST_HAS_BEEN_DELETED,$Rurl);

    }

}



else if($apt->get['action']=="wait")

{



     if (( $apt->cookie['cgroup'] ==  $apt->a_g) || ( $apt->cookie['cgroup'] ==  $apt->m_g))

    {

        $apt->head(LANG_TITLE_MODERATE_POSTS);



        $result = $apt->query("SELECT * FROM rafia_download WHERE allow='wit' ORDER BY id ASC");



        if($apt->dbnumrows($result))

        {

            $index_middle .= $apt->admin_form_opan("dodown");



            $index_middle .= $apt->admin_table_head("������ ��� ��������");



             while($apt->row = $apt->dbarray($result))

            {

                @extract($row);



                $index_middle .=$apt->admin_table_cell("down_id","edit","",0);

            }



            $index_middle .= $apt->admin_table_close();

            $index_middle .= $apt->admin_form_close('3',0);



            }

            else

            {

                $index_middle .= "<p>�� ���� ������ ��� ��������.</p>";

            }

             $apt->html_Output($left_menu);

        }

        else

        {

            $apt->head(LANG_TITLE_LOG_IN);



  eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");



        }

}

else if($apt->get['action'] == "deletecomment" )

{


    $cat_id  = $apt->setid('cat_id');
    $do  = $apt->post['do'];
    if(( $apt->checkcadmincat($cat_id) ) && ($apt->checkcmodcat('can_delete')))
    {
        if (count($do) >0)
        {
		if($apt->post['del']){
            foreach($do as $id)
            {
                $result = $apt->query("delete from  rafia_comment where id=$id");
                $filename = $apt->upload_path."/".$id.".comment";
                @unlink($filename);
            }
        }elseif($apt->post['allow']){
            foreach($do as $id)
            {
                $result = $apt->query("update rafia_comment set allow='yes' where id=$id");
            }
        }
        }
        $url = $apt->refe;
        if ($result)
        {
		if($apt->post['del']){
            $apt->bodymsg(LANG_MSG_POST_HAS_BEEN_DELETED,$url);
		}else{
            $apt->bodymsg(LANG_MSG_POST_HAS_APPROVED,$url);
		}
        }
        else
        {
            $apt->bodymsg(LANG_ERROR_ADD_DB,$url);
        }
    }
    else
    {
        $apt->head(LANG_TITLE_LOG_IN);
         eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");
    }




}

elseif($apt->get['action'] == "sticky" )

{

   //if ($apt->checkcmodcat('can_sticky'))

   $downid = $apt->setid('downid');

   $cat_id  = $apt->setid('cat_id');

   

   if (( $apt->cookie['cgroup'] ==  $apt->a_g) || ( $apt->cookie['cgroup'] ==  $apt->m_g))

   {



        $result = $apt->query("update rafia_download set sticky='1' where id=$downid  and cat_id=$cat_id");



        if ($result)

        {



             $url="download.php?action=view&id=$downid";



             $apt->bodymsg(LANG_MSG_THREAD_HAS_STUCK,$url);

        }



    }



}

elseif($apt->get['action']=="unsticky")

{

    $downid = $apt->setid('downid');

    $cat_id  = $apt->setid('cat_id');

    

    if (( $apt->cookie['cgroup'] ==  $apt->a_g) || ( $apt->cookie['cgroup'] ==  $apt->m_g))

    {

        $result = $apt->query("update rafia_download set sticky='0' where id=$downid and cat_id=$cat_id");



        if ($result)

        {

           $url = "download.php?action=view&id=$downid";



            $apt->bodymsg(LANG_MSG_THREAD_HAS_UNSTUCK,$url);

        }

    }

}

elseif($apt->get['action']=="open")

{

    $downid = $apt->setid('downid');

    $cat_id  = $apt->setid('cat_id');

    

    if (( $apt->cookie['cgroup'] ==  $apt->a_g) || ( $apt->cookie['cgroup'] ==  $apt->m_g))

    {

        $result = $apt->query("update rafia_download set close='0' where id=$downid and cat_id=$cat_id");



        if ($result)

        {

            $url = "download.php?action=view&id=$downid";



            $apt->bodymsg(LANG_MSG_POST_HAS_OPENED,$url);

        }

     }

}

elseif($apt->get['action']=="close")

{

   $downid = $apt->setid('downid');

   $cat_id  = $apt->setid('cat_id');

    if (( $apt->cookie['cgroup'] ==  $apt->a_g) || ( $apt->cookie['cgroup'] ==  $apt->m_g))

    {



        $result = $apt->query("update rafia_download set close='1' where id=$downid and cat_id=$cat_id");



        if ($result)

        {

            $url="download.php?action=view&id=$downid";



            $apt->bodymsg(LANG_MSG_THREAD_HAS_CLOSED,$url);

        }

    }

}

if(isset($fo))

{

    print $apt->script->post_java();

}

$apt->foot($pageft);

?>
