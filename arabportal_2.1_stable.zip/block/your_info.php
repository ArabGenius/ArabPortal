<?php
######################################
#                                    #
# Your Info block 1.0 for PHP-NUKE   #
# Copyright (c) 2003 by Dutchies     #
# http://www.dutchies.be             #
#                                    #
# file: blocks/block-your_info.php   #
#                                    #
######################################

global $apt;
$ip = $_SERVER["REMOTE_ADDR"];

$isphash = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$ispstr = preg_split("/\./", $isphash);
$xy = count($ispstr);
$x = $xy - 1;
$y = $xy - 2;
$i = $xy - 3;
$pc  = "" . $ispstr[$i] . "";
$isp = "" . $ispstr[$y] . "." . $ispstr[$x] . "";
$ip  = "" . $_SERVER['REMOTE_ADDR'] . "";

$content .= "<center><img src=images/who_online/online.gif></center>";
$content .= "<center><table border=\"0\" cellspacing=\"1\" width=\"98%\"  align=\"center\">
<tr><td width=\"100%\" colspan=\"2\"  align=\"center\">��������</td></tr>";
$content .= "<tr><td width=\"10%\"  align=\"center\" title=\""._NICKNAME."\">
<img border=\"0\" src=\"images/who_online/you.gif\"></td>
<td width=\"90%\"  title=\"��� �����\">".$apt->cookie['cname']."</td></tr>";
$content .= "<tr><td width=\"10%\"  align=\"center\" title=\"ip Add\">
<img border=\"0\" src=\"images/who_online/icon_links.gif\"></td>
<td width=\"90%\"  title=\"ip aadress\">&nbsp;$ip</td></tr>
<tr><td width=\"10%\"  align=\"center\" title=\"���� ���� ��������\">
<img border=\"0\" src=\"images/who_online/name.gif\"></td>
<td width=\"90%\"  title=\"interneti �henduse pakkuja\">&nbsp;$isp</td></tr>
<tr><td width=\"10%\"  align=\"center\" title=\"network\">
<img border=\"0\" src=\"images/who_online/network.gif\"></td>
<td width=\"90%\" title=\"�henduse t��p\">&nbsp;$pc</td></tr>
</table></center><br>";
echo $content;
?>
