<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 01/01/2007 Time: 00:00 AM  |
+===========================================+
*/

require_once('global.php');
 $menu = new menu;
$middle_menu_count  =  $apt->getsettings("count_middle_menu");
$middle_menu = "<table border=0 cellpadding=0 cellspacing=0 width=100%><tr valign=top>";
$middle_menus = $menu->_menu(3);
$ex = @explode('<!-- BLOCK END -->',$middle_menus);
$m=0;
foreach($ex as $amenu){
$middle_menu .= '<td valign=top>'.$amenu.'</td>';
$m++;
if($m==$middle_menu_count)$middle_menu .= "</tr>";
}
$middle_menu .= "</tr></table><br>";

if ( $apt->get['action'] == "" )
{
    $arr_subject = explode ("\n",$apt->getsettings('mailsubject'));

    $apt->head(LANG_TITLE_CONTACT_US);

    $fo = new form;
    $form .= $fo->inputform($apt->lang_form['16'], "text", "fromname","*");
    $form .= $fo->inputform($apt->lang_form['14'], "text", "fromail","*");
    $form .= $fo->selectsform($apt->lang_form['22']);
    $form .= $fo->textarea($apt->lang_form['23'],"message","","8");
    $form .= $fo->hiddenform  ("spam","1");
    $image = "themes/".$GLOBALS[themepath]."/do.gif";

        $output = array("action"      => "$PHP_SELF?action=sended",
                        "title"      => LANG_TITLE_CONTACT_US,
                        "method"     => '',
                        "name"       => '',
                        "content"    => $form,
                        "image"      => $image
                       );
         $index_middle  = $fo->formtable($output,1,'mailnotspam');

    $right_menu    =  $menu->_menu(1);
    $apt->html_Output("");
    
}elseif ( $apt->get['action'] == "maillist" ){
$posttybe  = $apt->format_data($apt->post['posttybe']);
     if ($posttybe=="add")
     {
         if (!$apt->check_email($apt->post['email']))
         {
             $apt->errmsg(LANG_ERROR_VALID_EMIAL);
         }
         @extract($HTTP_POST_VARS);

         $email  = $apt->format_data($apt->post['email']);

         $result = $apt->query("SELECT * FROM rafia_email WHERE email ='$email'");

       if ($apt->dbnumrows($result) < 1){
             $email  = $apt->format_data($apt->post['email']);
             $result = $apt->query("insert into rafia_email (email) values ('$email')");
             if ($result)
             {
                 $apt->bodymsg(LANG_MSG_ADDEMAIL_OK,"index.php");
             }
             else
             {
                 $apt->bodymsg(LANG_ERROR_ADD_DB,"index.php");
             }
         }
         else
         {
             $apt->bodymsg(LANG_ERROR_EMIAL_EXISTED,"index.php");
         }
     }
     elseif($posttybe=="delete")
     {
         @extract($HTTP_POST_VARS);
         
         if (!$apt->check_email($apt->post['email']))
         {
             $apt->errmsg(LANG_ERROR_VALID_EMIAL);
         }
         
         $email  = $apt->format_data($apt->post['email']);
         
         $result = $apt->query("SELECT * FROM rafia_email WHERE email ='$email'");
         
         if ($apt->dbnumrows($result) < 1)
         {
             $apt->bodymsg(LANG_ERROR_VALID_EMIAL,"index.php");
         }
         else
         {
             $result = $apt->query("delete from  rafia_email where email='$email'");

             if ($result)
             {
                 $apt->bodymsg(LANG_MSG_DELEMAIL_OK,"index.php");
             }
             else
             {
                 $apt->bodymsg(LANG_ERROR_ADD_DB,"index.php");
             }
         }
     }
 }
else if($apt->get['action']=="send")
{
    @extract($HTTP_POST_VARS);

    if (!$apt->full($HTTP_POST_VARS))
       {
           $apt->errmsg(LANG_ERROR_VALIDATE);
       }

    if (!$apt->check_email($apt->post['tomail']))
       {
           $apt->errmsg(LANG_ERROR_VALID_EMIAL);
       }

    if (!$apt->check_email($apt->post['fromail']))
       {
           $apt->errmsg(LANG_ERROR_VALID_EMIAL);
       }

       $mail = new email;

       $mail->send($tomail,@constant($apt->getsettings("sendpage")),$message,$fromname,$fromail,0);


    $apt->bodymsg($lang_form['41'],"index.php");
}
else if($apt->get['action']=="sendpage")
{
    $apt->head(LANG_TITLE_TEL_FRIEND);
    $fo = new form;
    $form .= $fo->inputform ($apt->lang_form['20'], "text", "tomail","*");
    $form .= $fo->inputform ($apt->lang_form['16'], "text", "fromname","*");
    $form .= $fo->inputform ($apt->lang_form['14'], "text", "fromail","*");
    
    if ( empty ($apt->refe) )
    {
        $pageurl = $apt->getsettings("siteURL");
    }
    else
    {
        $pageurl = $apt->refe;
    }

   
    $form .=$fo->textarea($lang_form['23'],"message","������ ����� ����� ����\n����� ������ .. ����� �� ���� ��� ������ \n\n\r".$apt->refe,"8");
    
    $image = "themes/".$GLOBALS[themepath]."/do.gif";

        $output = array("action"      => "$PHP_SELF?action=send",
                        "title"      => LANG_TITLE_TEL_FRIEND,
                        "method"     => '',
                        "name"       => '',
                        "content"    => $form,
                        "image"      => $image
                       );
         $index_middle  = $fo->formtable($output);
         
    
    $right_menu    =  $menu->_menu(1);
    
    $apt->html_Output("");
}
else if($apt->get['action']=="sended")
{
    @extract($HTTP_POST_VARS);

    $this_url = explode('/',$_SERVER['HTTP_HOST']);
    $reff_url = explode('/',$_SERVER['HTTP_REFERER']);

    if($this_url[0] !== $reff_url[2]){
    $apt->bodymsg('���� ... �� ����� ����� ����� �� ���� ������',"mail.php");
    }

    if($spam !== 'mailnotspam'){
    $apt->bodymsg('���� ... ��� ������� ��� ������',"mail.php");
    exit;
    }

    if (!$apt->full($HTTP_POST_VARS))
       {$apt->errmsg(LANG_ERROR_VALIDATE);}

    if (!$apt->check_email($fromail))
       {$apt->errmsg(LANG_ERROR_VALID_EMIAL);}

if($apt->getsettings('sendme_by') == 'mail'){
       $mail = new email;
       $mail->send($apt->getsettings("sitemail"),$subject,$message,$fromname,$fromail,0);
}else{
$msgdate   = $apt->time;
$fromname = $apt->format_post($apt->post[fromname]);
$fromail = $apt->format_post($apt->post[fromail]);
$subject = $apt->format_post($apt->post[subject]);
$message   = $fromail."=^+^=".$apt->format_post($apt->post[message]);
$ufromid   = $apt->format_data($apt->cookie['cid']);

$apt->query("INSERT INTO rafia_messages
(mailus,msgbox,msgdate,msgisread,msgtitle,message,ufromid,fromname)
VALUES
('1','1','$msgdate','1','$subject','$message','$ufromid','$fromname')");

}
       $url = $apt->getsettings("siteURL");
       if(substr($url,-1) != '/'){$url = $url . '/';}
	 $admin_url = $url.'admin/';
       $mail = new email;
       $mail->send($apt->getsettings("sitemail"),"����� ��� ���� ������","��� ���� ����� �� ����� ���� ������ \n �������� �� ���� ���� ������ � ���� ��� ����� ����� ������ \n $admin_url",$apt->getsettings("sitetitle"),$apt->getsettings("sitemail"),0);

       $apt->bodymsg($lang_form['41'],"index.php");
}
else if($apt->get['action']=="sendtouser")
{
    @extract($HTTP_POST_VARS);

    if (!$apt->full($HTTP_POST_VARS))
    {
        $apt->errmsg(LANG_ERROR_VALIDATE);
    }

    if(!$apt->check_email($fromail))
    {
        $apt->errmsg(LANG_ERROR_VALID_EMIAL);
    }

       $mail = new email;

       $mail->send($tomail,$subject,$message,$fromname,$fromail,0);

    header("Refresh: 1;url=index.php");
}
else if($apt->get['action']=="sendtousers")
{
$userid = $apt->setid('userid');
   $result = $apt->query("SELECT showemail,email,username FROM
                            rafia_users where userid='$userid'");

   $row = $apt->dbarray($result);

   @extract($row);

   if($showemail=="1")
   {
       $apt->head (LANG_TITLE_SEND_MESSAGE_TO_MEMBER);
       $fo = new form;
       $form .= $fo->hiddenform ("tomail","$email");
       $form .= $fo->inputform  ($apt->lang_form['16'],"text", "fromname","*");
       $form .= $fo->inputform  ($apt->lang_form['14'],"text", "fromail","*");
       $form .= $fo->inputform  ($apt->lang_form['22'],"text", "subject","*");
       $form .= $fo->textarea   ($apt->lang_form['23'],"message"," ������ ����� ����� ���� �������\n  ��� ����  $username\n","8");

       $image = "themes/".$GLOBALS[themepath]."/do.gif";

        $output = array("action"      => "$PHP_SELF?action=sendtouser",
                        "title"      => LANG_TITLE_SEND_MESSAGE_TO_MEMBER,
                        "method"     => '',
                        "name"       => '',
                        "content"    => $form,
                        "image"      => $image
                       );
         $index_middle  = $fo->formtable($output);
         $right_menu    =  $menu->_menu(1);
         $apt->html_Output("");
   }
   else
   {
       $apt->errmsg ($username ." , �������� ����� ��� �����" );
   }
}

$apt->foot($pageft);
?>