<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 01/01/2007 Time: 00:00 AM  |
+===========================================+
*/

require_once('global.php');

$apt = new func();
$apt->arrSetting  = $apt->settings();
$apt->start_loginfo();

$maxlifetime             = $apt->conf['maxlifetime'] ?  $apt->conf['maxlifetime'] : get_cfg_var("session.gc_maxlifetime");

$apt->upload_path        = $apt->conf['upload_path'];

if ($apt->get['action']=="image")
{
    $id = intval($_GET[id]);
    if ($apt->retcheckgroup('view_news_img'))   // Added by Myrosy
    {
        $result = $apt->query("SELECT * FROM rafia_upload WHERE upid='$id'");
        if($apt->dbnumrows($result)>0)
        {
            $rowfile = $apt->dbarray($result);
            @extract($rowfile);
		if(($_GET[thumb] =="y") and ($upcat=='news')){
            if(file_exists($apt->upload_path."/".$uppostid.".newsthumb")){
            $pathfile = $apt->upload_path."/".$uppostid.".newsthumb";}else{
            $pathfile = $apt->upload_path."/".$uppostid.".".$upcat;}
		}else{
            $pathfile = $apt->upload_path."/".$uppostid.".".$upcat;
		}

            header ("Content-type: $uptypes");
            $open = @fopen($pathfile,r);
            $data = @fread($open,@filesize($pathfile));
            @fclose($open);
            print($data);

            $apt->query("UPDATE rafia_upload SET upclicks = upclicks+1 WHERE upid = '$id'");
        }
    }
    else
    {
         $apt->errmsg (LANG_MSG_NOT_VIEW);  // Added by Myrosy
    }
}
if ($apt->get['action']=="save")
{
	if($apt->check_str($apt->get['type'])== true)
	{
		$savetype = $apt->get['type'];
	}
	if($apt->check_num($apt->get['id'])== true)
	{
		$saveid = $apt->get['id'];
	}
		@header( 'Content-Type: text/html' );
        @header( "Refresh: 1;url=".$apt->getsettings("siteURL")."/archive/".$savetype."/save/".$saveid.".html" );
}


?>