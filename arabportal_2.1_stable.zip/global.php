<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 01/01/2007 Time: 00:00 AM  |
+===========================================+
*/

if(is_file("install/index.php")){
$open = @fopen("install/SysMsg.tpl",r);
$data = @fread($open,@filesize("install/SysMsg.tpl"));
@fclose($open);
echo $data;
exit;
}

define('TURN_BLOCK_ON', true);

function rff_callback($matches)
{
	global $apt;
	return $apt->ReadFromFile($matches[1],$matches[2]);
}

function inc_callback($matches)
{
	global $apt;
	return $apt->includeFile($matches[1],$matches[2]);
}

$_GET = array_map('RemoveXSS', $_GET); 
require_once("func/Files.php");
require_once('html/JavaScript.php');
require_once('admin/conf.php');
require_once("func/info.php");
require_once('func/mysql.php');
require_once('func/email.php');
require_once('func/CatTree.php');
require_once('func/mainsub.php');
require_once('func/functions.php');
require_once("func/Session.php");
require_once('func/upload.php');
require_once('func/printer.php');
require_once('func/menu.php');
require_once('lang/arabic.php');
require_once('func/form.php');
require_once('func/search.php');
require_once('func/counter.php');
require_once('func/module.php');
require_once('func/Cache.php');
require_once('func/Spams.php');

$apt = new func();
$start = $apt->get['start']; // Added By Myrosy (Pages Problem)

$forum_middle = '';
$adminJump = '';
$Jump = '';
$form = '';
$middle_menu = '';
$ads_head = '';
$ads_foot = '';
$title = '';
$add_new_post ='';
$add_new_reply ='';

$SetMain = array();
$SetRows = array();

$apt->arrSetting  = $apt->settings();
$apt->lang_form   = $lang_form;
$apt->all_groups = $apt->allgroups();

$Counter = new Counter();

//$sess = new sessions();
//$sess->start_sessions ();

$apt->start_loginfo();

$maxlifetime             = $apt->conf['maxlifetime'] ?  $apt->conf['maxlifetime'] : get_cfg_var("session.gc_maxlifetime");

$apt->upload_path        = $apt->conf['upload_path'];

$apt->hijri_date         = $apt->getsettings("hijri_date");

if(!isset($apt->get['start']))
{
    $start = 0;
}


//---------------------------------------------------
//                        theme
//---------------------------------------------------

if(isset($apt->cookies['logintheme']));
{
    $apt->theme =  $apt->cookie['ctheme'];
}

if((isset($apt->theme)) ||($apt->theme != '0'))
{

    $theme_result = $apt->query("SELECT rafia_design.usertheme,rafia_templates.theme
                                   FROM rafia_design,rafia_templates
                                   WHERE rafia_design.theme ='". $apt->theme."'
                                   AND rafia_templates.theme ='". $apt->theme."'
                                   AND rafia_templates.theme = rafia_design.theme
                                   AND rafia_design.usertheme='1'");
                             
    if($apt->dbnumrows($theme_result)==0)
    {
        $apt->theme = $apt->getsettings('theme');
    }
}

if(empty($apt->theme))
{
    $apt->theme = $apt->getsettings('theme');
}
if($apt->conf['Theme_From_File']==1)
{
    $Cache = new Cache();
        if($Cache->isCache() == false)
             $Cache->mkCache ($apt->theme);

}
//echo $apt->theme;
//---------------------------------------------------
//                       end theme
//---------------------------------------------------


//-------------------start Turn Off APT---------------
if ($apt->cookie['cgroup'] !== '1'){
if($apt->getsettings('turn_off')=='yes'){
$file = basename($apt->self);
if(($apt->get[action] !== "login") or ($file !== "members.php")){
	$apt->head("������ ����");
	$turn_off_msg = $apt->getsettings('turn_off_msg');
	eval (" print \"" . $apt->gettemplate ( 'turn_off_site' ) . "\";");
	exit;
}
}
}
//--------------------end Turn Off APT----------------
//

//-------------------start IP PAN---------------
$pan_ips = $apt->getsettings('pan_ip');
$pan_ips = @explode("\n",$pan_ips);
if(in_array($apt->ip,$pan_ips)){
$apt->errmsg("���� ... ��� ����� �� ������ ��� ��� ������");
exit;
}
//--------------------end Turn Off APT----------------
//


if(count($_POST) > 0)
{
    $apt->check_referer();
}

$session =  md5(uniqid(rand()));

//---------------------------------------------------
//                      pm  messages
//---------------------------------------------------
if($apt->cookie['cid'] >0)
{
    $resultnew = $apt->query("SELECT * FROM rafia_messages WHERE
                              msgbox='1' and userbox='".$apt->cookie['cid']."'
                              and userbox != '$apt->Guestid' and msgisread='1'");
                                           
    $pmumrows = $apt->dbnumrows($resultnew);

    if ( $pmumrows > 0)
    {
       $apt->ifpm = 1;
    }
}

//---------------------------------------------------
//                        design
//---------------------------------------------------

$result = $apt->query("SELECT * FROM rafia_design WHERE theme='".$apt->theme."'");

  $drow         = $apt->dbarray($result);

  $themepath      = $drow["themepath"];
  $themewidth      = $drow["themewidth"];

  $apt->themepath = $themepath;
  
  $pagehd =  $apt->replace_callback($drow['pagehd']);
  $pageft =  $apt->replace_callback($drow['pageft']);

  eval("\$pagehd =\"".str_replace("\"","\\\"",stripslashes($pagehd)). "\";");
  eval("\$pageft =\"".str_replace("\"","\\\"",stripslashes($pageft)). "\";");


/////////////////////////////
$timestamp   = $apt->time;
$lifetimeout = 300;
$timeout     = $timestamp-$lifetimeout;
$online_ip   = $apt->ip;
$session_id  = session_id() ;


$useronline   = $apt->format_data($apt->cookie['cname']);
$useronlineid = $apt->format_data($apt->cookie['cid']);

if(($useronline =='') and ($useronlineid =='')){
$apt->cookie['clogin'] = '';
$apt->cookie['cname'] = 'Guest';
$apt->cookie['cid'] = $apt->Guestid;
$useronline   = $apt->format_data($apt->cookie['cname']);
$useronlineid = $apt->format_data($apt->cookie['cid']);
}

$REQUEST_URI  = $apt->format_data($_SERVER[REQUEST_URI]);
$session_id   = $apt->format_data($session_id);
$PHP_SELF     = $apt->format_data($_SERVER[PHP_SELF]);

//$apt->query("update rafia_users set lastlogin='$timestamp' WHERE userid='$useronlineid'");
$apt->query("DELETE FROM rafia_online WHERE onlineSID ='$session_id' or timestamp < $timeout");

$apt->query("INSERT INTO rafia_online (timestamp,
                                          onlineip,
                                          onlinefile,
                                          onlinepage,
                                          onlineSID,
                                          user_online,
                                          useronlineid)
                                  VALUES ('$timestamp',
                                          '$online_ip',
                                          '$PHP_SELF',
                                          '$REQUEST_URI',
                                          '$session_id',
                                          '$useronline',
                                          '$useronlineid')",'rafia_online');


//////////////////////////// function check cookies ////////////////
function checkcookie()
{
    @extract($GLOBALS);
    
    unset($Login);
    
    if (( $apt->cookie['clogin'] != 'rafiaphp' ) && (!$apt->cookie['cid'] > 0 or $apt->cookie['cid'] == $apt->Guestid))
    {
        $apt->head(LANG_TITLE_LOG_IN);
        
         eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");
         
        $apt->foot($pageft);
        
        exit;
   }
}

function Login()
{
    @extract($GLOBALS);
    $apt->head(LANG_TITLE_LOG_IN);
    eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");
    $apt->foot($pageft);
}

function checkgroup($info)
{
    @extract($GLOBALS);
    
     if(!isset($apt->cookie['cgroup']))
     {
       $apt->cookie['cgroup'] = 3;
     }
     
    $query = $apt->dbfetch("SELECT $info FROM rafia_groups WHERE groupid='".$apt->cookie['cgroup']."' LIMIT 1");
                              
     if($query[$info]!='1')
    {
        $apt->head(LANG_TITLE_LOG_IN);
        eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");
        $apt->foot($pageft);
        exit;
    }
}


$urlarr = array($_rafia,$id,$cat_id,$userid,$msgid,$start,$page,
                $adsid,$news_id,$thread_id,$down_id,$allowid,$mineID);

while (list($key, $value) = each ($urlarr))
{
    if (!empty($key))
    {
        if (eregi ('[^0-9]', $value))
        {
            $apt->errmsg(LANG_ERROR_URL);
        }
    }

}
$index_middle = '';


//for upgrade ��� ��� ��������

function getimagefile($postid)
{
    global $apt;
    $file_left = $apt->upload_path."/left/$postid.jpg";

    if (file_exists($file_left))
    {
          $image = "<img src=\"$file_left\"  align=\"left\">";
          return $image;
     }
     $file_right = $apt->upload_path."/right/$postid.jpg";
    if (file_exists($file_right))
    {
          $image = "<img src=\"$file_right\"  align=\"right\">";
          return $image;
     }
     unset($image);
  return $image;
}

//-------------------------------------------------------
// ������ ������� ��������� ������� �� ����� XSS (������ �� ��� �������)
//-------------------------------------------------------
function RemoveXSS($val) {
   $val = preg_replace('/([\x00-\x08][\x0b-\x0c][\x0e-\x20])/', '', $val);
   $search = 'abcdefghijklmnopqrstuvwxyz';
   $search .= 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
   $search .= '1234567890!@#$%^&*()';
   $search .= '~`";:?+/={}[]-_|\'\\';
   for ($i = 0; $i < strlen($search); $i++) {
      $val = preg_replace('/(&#[x|X]0{0,8}'.dechex(ord($search[$i])).';?)/i', $search[$i], $val); // with a ;
      $val = preg_replace('/(&#0{0,8}'.ord($search[$i]).';?)/', $search[$i], $val); // with a ;
   }

   $ra1 = Array('javascript', 'vbscript', 'expression', 'applet', 'meta', 'xml', 'blink', 'link', 'style', 'script', 'embed', 'object', 'iframe', 'frame', 'frameset', 'ilayer', 'layer', 'bgsound', 'title', 'base');
   $ra2 = Array('onabort', 'onactivate', 'onafterprint', 'onafterupdate', 'onbeforeactivate', 'onbeforecopy', 'onbeforecut', 'onbeforedeactivate', 'onbeforeeditfocus', 'onbeforepaste', 'onbeforeprint', 'onbeforeunload', 'onbeforeupdate', 'onblur', 'onbounce', 'oncellchange', 'onchange', 'onclick', 'oncontextmenu', 'oncontrolselect', 'oncopy', 'oncut', 'ondataavailable', 'ondatasetchanged', 'ondatasetcomplete', 'ondblclick', 'ondeactivate', 'ondrag', 'ondragend', 'ondragenter', 'ondragleave', 'ondragover', 'ondragstart', 'ondrop', 'onerror', 'onerrorupdate', 'onfilterchange', 'onfinish', 'onfocus', 'onfocusin', 'onfocusout', 'onhelp', 'onkeydown', 'onkeypress', 'onkeyup', 'onlayoutcomplete', 'onload', 'onlosecapture', 'onmousedown', 'onmouseenter', 'onmouseleave', 'onmousemove', 'onmouseout', 'onmouseover', 'onmouseup', 'onmousewheel', 'onmove', 'onmoveend', 'onmovestart', 'onpaste', 'onpropertychange', 'onreadystatechange', 'onreset', 'onresize', 'onresizeend', 'onresizestart', 'onrowenter', 'onrowexit', 'onrowsdelete', 'onrowsinserted', 'onscroll', 'onselect', 'onselectionchange', 'onselectstart', 'onstart', 'onstop', 'onsubmit', 'onunload');
   $ra = array_merge($ra1, $ra2);

   $found = true; // keep replacing as long as the previous round replaced something
   while ($found == true) {
      $val_before = $val;
      for ($i = 0; $i < sizeof($ra); $i++) {
         $pattern = '/';
         for ($j = 0; $j < strlen($ra[$i]); $j++) {
            if ($j > 0) {
               $pattern .= '(';
               $pattern .= '(&#[x|X]0{0,8}([9][a][b]);?)?';
               $pattern .= '|(&#0{0,8}([9][10][13]);?)?';
               $pattern .= ')?';
            }
            $pattern .= $ra[$i][$j];
         }
         $pattern .= '/i';
         $replacement = substr($ra[$i], 0, 2).'<x>'.substr($ra[$i], 2); // add in <> to nerf the tag
         $val = preg_replace($pattern, $replacement, $val); // filter out the hex tags
         if ($val_before == $val) {
            $found = false;
         }
      }
   }
return $val;
}

?>