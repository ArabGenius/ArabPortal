<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 22/10/2006 Time: 10:00 PM  |
+===========================================+
*/

error_reporting  (E_ERROR | E_WARNING | E_PARSE);

if(is_file("./../install/index.php")){
$open = @fopen("./../install/SysMsg.tpl",r);
$data = @fread($open,@filesize("./../install/SysMsg.tpl"));
@fclose($open);
$data = str_replace('themes/apt','./../themes/apt',$data);
$data = str_replace('install','./../install',$data);
echo $data;
exit;
}

require_once('conf.php');
if($CONF['class_folder'] == '')$CONF['class_folder']='aclass';
if(! @fopen($CONF['class_folder']."/index.html",r)){
exit("<br><br><center dir=rtl><b>���� ,,, ���� �� ��� ���� ������ ������ ����� �� $CONF[class_folder]</b></center>");
}

require_once("lang/arabic.php");
require_once('../html/JavaScript.php');
require_once("../func/info.php");
require_once("../func/mysql.php");
require_once("../func/functions.php");
require_once('../func/email.php');
require_once('../func/counter.php');
require_once($CONF['class_folder']."/admin_func.php");
require_once('../func/Cache.php');
require_once('../func/Files.php');

$apt = new func;

$apt->arrSetting  = $apt->settings();
$apt->upload_path = $apt->conf['upload_path'];

$admin = new admin_func;

if(count($_POST) > 0)
{
    $apt->check_referer();
}

function check_if_admin()
{
    global $apt,$admin;
    
   if(!$admin->is_login() === true)
   {
       $admin->login_form();
   }
}
?>