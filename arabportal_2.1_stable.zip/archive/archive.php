<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|                                           |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 24/10/2006 Time: 04:00 PM  |
+===========================================+
*/

class archive
{
    var  $bgColor = '';
    var  $RowHtml = '';
    var  $module  = '';
    var  $RealUrl = '';
    var  $save     = 0;

    function archive($module)
    {
         $this->module = $module;

    }
                             // LEFT JOIN rafia_cat
                             // ON  rafia_news.cat_id = rafia_cat.id
                           //  rafia_cat.title as titlecat,

    function loud_view($save = 0)
    {
        global $apt;
        $this->save = $save;
        
        $id  = $apt->setid('id');

        $this->RealUrl = $apt->getsettings('siteURL')."/$this->module.php?action=view&id=".$id;

        $row = $apt->dbfetch("SELECT rafia_$this->module.*,
                              rafia_users.userid,rafia_users.username
                              FROM rafia_$this->module
                              LEFT JOIN rafia_users
                              ON  rafia_$this->module.userid = rafia_users.userid
                              WHERE id='$id' AND rafia_$this->module.allow = 'yes'
                              LIMIT 1");
        @extract($row);
        
        //$apt->query("UPDATE rafia_news SET reader = reader+1 WHERE id = '$id'");

        $row[title]         =  $apt->format_data_out($row[title]);

        $row[news_head]     =  $apt->rafia_code_print($row[news_head]);

        $row[post]          =  $apt->rafia_code_print($row[post]);

        $row[date]          =  $apt->Hijri($row[date_time])." ".$apt->gettime($row[date_time]);

        $RetView            = $this->RetView($row,1);

        if($row[c_comment] > 0)
        $RetView            .= $this->getComment($id);
        if($this->save != 1)
		echo $this->OutPut($RetView);
		else
		{
			$FileName = $apt->conf['site_path'].'/html/Cache/news.html';
			if(Files::write( $FileName ,$this->OutPut($RetView)))
			Files::download($FileName);

		}

       //return $ViewLink;
    }


    function getComment($id)
    {
        global $apt;

        if($this->module == 'forum')
        $modid = 'thread';
        else
        $modid = $this->module;
        
        $result = $apt->query ("SELECT rafia_comment.* ,rafia_users.userid,rafia_users.username

                                FROM rafia_comment,rafia_users

                                WHERE ".$modid."_id='$id'

                                AND rafia_comment.userid = rafia_users.userid

                                ORDER BY id ASC");
                                   
         while($row =$apt->dbarray($result))
         {
             $row[title]     =  $apt->format_data_out($row[title]);

             $row[post]      =  $apt->rafia_code_print($row[comment]);

             $row[date]      =  $apt->Hijri($row[timestamp])." ".$apt->gettime($row[timestamp]);

             $RetView        .= $this->RetView($row);
         }

        return $RetView;
    }

    function getCategories($catType)
    {
       return '';
    }

    function href($Link,$title)
    {
       $ViewLink = "<a href=\"$Link\">$title</a>";
       return $ViewLink;
    }

    function TableCell($cell)
    {
        $Html = "<tr>";

        if($this->bgColor=="#F3F8FD")
        $this->bgColor="#DFE9F4";
        else
        $this->bgColor="#F3F8FD";

        for ( $i=0; $i < count($cell); $i++ )
        {
            if(!is_numeric($cell[$i]))
            $align = 'right';
            else
            $align = 'center';

            $Html .= "<td align=\"$align\" bgColor=\"$this->bgColor\">{$cell[$i]}</td>";

        }

        $Html .=  "</tr>";

        return $Html;
    }


    function Table($cell)
    {

        $Html .= '<table border="0" cellpadding="0" cellspacing="0" width="96%">';
        $Header = "<tr>";
        $i=0;
        foreach ($cell as $value)
        {
            $Header .= "<td width=\"{$this->ColWidth[$i]}%\"><p><font color=\"#000000\">{$value}</font></p></td>";
            $i++;
        }
        $Header .=  "</tr>";

        $Html .= "<td noWrap align=\"middle\" colSpan=\"$i\"></td>".$Header;
        $Html .=  $this->RowHtml;
        $Html .= "<td noWrap align=\"middle\" colSpan=\"$i\"></td>";
        $Html .=  "</table></div>";

        return $Html;
    }


function OutPut($OutPut='')
{
    global $apt;
    $sitetitle = $apt->getsettings("sitetitle");
    
if ($this->save == 1)
$download = "<style>\n".Files::read("Default.css").'</style>';

	

return <<<EOF
<HTML DIR=RTL>
<head>
<meta http-equiv=Content-Type content=text/html; charset=windows-1256>
<meta http-equiv=Content-Language content=ar-sa>
<META content="arabportal" name=keywords>
<META content="Arab Portal , Powered by rafia" name=description>
<META content=ALL name=ROBOTS>
<title>$sitetitle</title>
<link rel="stylesheet" type="text/css" href="../../Default.css">
$download
</head>
<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" >



<br>
$OutPut

<!-- Footer Start -->
<br>
<table border="0" cellpadding="0" cellspacing="0" width="100%" id="table2">
<tr>
<td>
</td>
<td width="100%" align="center">Powered by:
<a target="_blank"  href="http://www.arabportal.net">Arab Portal</a> v2.1.0, Copyright� 2006
    </td>
    <td>
</td>
 </tr>
</table>
<!-- Footer End -->
</body>
</html>
EOF;
}

function RetView($OutPut = array(),$Trail=0)
{
    //global $apt;
if($Trail !=0 )
{
    $title ="<div class=\"Trail\" align=\"right\">
      $OutPut[title]
      <br>
      <span class=small>
      ���� ������ :".$this->href($this->RealUrl,$this->RealUrl)."
      </span>
      </div>";
}
return <<<EOF

<div align="center">
$title

<table border="0" width="96%" id="table16" class="forum_alt3">
<tr>
<td width="10%" class="forum_alt1" valign="top">

<span class=small>
������: <a href="../../../members.php?action=info&userid=$OutPut[userid]">$OutPut[username]</a>
<br>
<br>
<br>
</span>
</td>
<td width="90%" valign="top" class="forum_alt2" colspan="2">

<div class="forum_alt2">
<span class=small>
&nbsp;��� �� $OutPut[date] </font>
</span>
</div>
<hr color="#7394B6" size="1">

                 		$OutPut[post]

                 <br>

      <hr color="#7394B6" size="1">
        </td>
					</tr>
 				<tr>
						<td width="15%" class="small" valign="top" align="center">
						 &nbsp;</td>
						<td width="40%" valign="top" class=small>
                           &nbsp;</td>
						<td width="40%" valign="top" align="left">

               &nbsp;</td>
					</tr>
				</table>

EOF;
}

}
