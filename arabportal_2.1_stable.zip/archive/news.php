<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|                                           |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 22/10/2006 Time: 10:00 PM  |
+===========================================+
*/
require_once('../global.php');
require_once('archive.php');


$arch = new archive('news');

if($apt->get['act']=="view")
{
    $id  = $apt->setid('id');
    if( $id > 0)
    $arch->loud_view();
}
if($apt->get['act']=="save")
{
    $id  = $apt->setid('id');
    if( $id > 0)
    $arch->loud_view(1);
}

?>
