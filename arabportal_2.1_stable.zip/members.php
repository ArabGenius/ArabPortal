<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 01/01/2007 Time: 00:00 AM  |
+===========================================+
*/

require_once('global.php');

$menu = new menu;
$menu->menuid       =  $apt->getsettings("index_menuid");
$right_menu   = $menu->_menu(1);
$middle_menu_count  =  $apt->getsettings("count_middle_menu");
$middle_menu = "<table border=0 cellpadding=0 cellspacing=0 width=100%><tr valign=top>";
$middle_menus = $menu->_menu(3);
$ex = @explode('<!-- BLOCK END -->',$middle_menus);
$m=0;
foreach($ex as $amenu){
$middle_menu .= '<td valign=top>'.$amenu.'</td>';
$m++;
if($m==$middle_menu_count)$middle_menu .= "</tr>";
}
$middle_menu .= "</tr></table><br>";

$perpagelist = 30;
////////////////login //////////////

if (isset($apt->post[username]) && isset($apt->post[userpass]))
{
    @extract($HTTP_POST_VARS);
    $apt->setoutcookie();
    $username = $apt->format_data($username);

    $userpass = $apt->format_data(md5($userpass));

    $fullarr =  array($username,$userpass);
    
    if (!$apt->full($fullarr))
    {
        $apt->errmsg(LANG_ERROR_VALIDATE);
    }

    $result = $apt->query("SELECT * FROM rafia_users WHERE
                              (username ='$username') AND
                              (password ='$userpass')");

    if ($row = $apt->dbnumrows($result) == 0)
    {
        $apt->errmsg(LANG_ERROR_LOGIN);
    }

    $row = $apt->dbarray($result);

    if ($row["allowpost"] == "no")
    {
        $apt->errmsg(LANG_ERROR_YOU_STOPPING);
    }

    if ($row["allowpost"] == "wit")
    {
        $apt->errmsg(LANG_ERROR_NON_ACTIVATES);
    }

    if (($row["username"] == $username) &&($row["password"] == $userpass))
    {
        @extract($row);
        $activate   = $apt->makeactivate();
        $userip     = $apt->ip;
        $lastlogin  = time();
        $cookie     = serialize(array('rafiaphp', $activate, $userid, $apt->time,session_id()));
        $apt->set_cookie ("",base64_encode($cookie));
        
        $_SESSION["sessid"]      = $userid;
        $_SESSION["sessname"]    = $username;
        $_SESSION["sessadmin"]   = $useradmin;
        $_SESSION["sessgroup"]   = $usergroup;
        $_SESSION["sesstheme"]   = $usertheme;
        $_SESSION["selastvisit"] = $lastlogin;

// Added By MaaSTaaR
      $X_url = explode('/',$_SERVER['HTTP_HOST']);
	$Y_url = explode('/',$_SERVER['HTTP_REFERER']);
	$goto = ($X_url[0] != $Y_url[2]) ? $goto = 'index.php' : $goto = $apt->refe;
// MaaSTaaR End
        $apt->query("update rafia_users set userip='$userip',lastlogin='$lastlogin',activate='$activate' WHERE userid='$userid'");
        $apt->bodymsg(LANG_MSG_LOGED_IN . $username, $goto);  // Added by MaaSTaaR
    }

}
if ($apt->get['action']=="info")
{

    checkgroup('view_site');
    
    checkcookie();

    $apt->head(LANG_TITLE_PERSONAL_FILE);

    $member_lang_head = LANG_TITLE_PERSONAL_FILE;
    
    $userid =  intval( $apt->get['userid']);
    
    $result = $apt->query("SELECT username,email,homepage,avatar,allposts,datetime,viewemail,showemail FROM rafia_users WHERE userid='$userid'");

    $row    = $apt->dbarray($result);
    
    @extract($row);

    $username     =  $apt->format_data_out($username);
    $homepage     =  $apt->format_data_out($homepage);
    $email        =  $apt->format_data_out($email);
    $usertitles   =  explode("-", $apt->userRating($allposts));
    $usertitle    =  $usertitles[1];
    $date         =  $apt->Hijri($datetime);

    if($viewemail == 0)
    {
        $email ="�� ���� �� ����";
    }
    if($showemail == 0)
    {
        $showemail = 'no';
    }
    else
    {
        $showemail = '<a href="mail.php?action=sendtousers&userid='.$userid.'">����� ����� ��� ������</a>';
    }
    if($avatar == 0){
        $avatar_pic = "<img src=images/no_pic.gif>";
    }else{
        $avatarfile = $apt->upload_path."/".$userid.".".'avatar';
        if(file_exists($avatarfile)){
        $avatar_pic = "<img src=members.php?action=image&userid=".$userid.">";
        }else{
        $avatar_pic = "<img src=images/no_pic.gif>";
        }	
    }

    $showemail =  $apt->adminset($showemail);
    
     if($allposts >0)
     {
         $newsPosts  = $apt->dbnumquery("rafia_news","userid=".$userid);
         $forumPosts = $apt->dbnumquery("rafia_forum","userid=".$userid);
         
         if($newsPosts >0){
             $newsPosts = " <a href=\"news.php?action=byuser&userid=$userid\"> ��� ������� �������</a>";
         }else{$newsPosts = "";}

         if($forumPosts > 0){
             $forumPosts = " || <a href=\"forum.php?action=byuser&userid=$userid\">��� ������� �������</a>";
         }else{$forumPosts = "";}

     }
    
    eval("\$index_middle = \" " . $apt->gettemplate ( 'member_info' ) . "\";");

    $apt->html_Output($left_menu);

}
elseif ($apt->get['action']=="cp")
{
    checkgroup('view_site');

    checkcookie();

    $apt->head(LANG_TITLE_PERSONAL_FILE);

    $member_lang_head = LANG_TITLE_PERSONAL_FILE;

    $result = $apt->query("SELECT * FROM rafia_users WHERE userid='".$apt->cookie['cid']."'");
    $row    = $apt->dbarray($result);
    @extract($row);

    $username     =  $apt->format_data_out($username);
    $homepage     =  $apt->format_data_out($homepage);
    $email            =  $apt->format_data_out($email);
    $usertitles   =  explode("-", $apt->userRating($allposts));
    $usertitle    =  $usertitles[1];
    $date            =  $apt->Hijri($datetime);

    if($showemail == 0){
        $showemail = 'no';
    }else{
        $showemail = 'yes';
    }

    $showemail =  $apt->adminset($showemail);

    if($avatar == 0){
        $avatar_pic = "<img src=images/no_pic.gif>";
    }else{
        $avatarfile = $apt->upload_path."/".$apt->cookie['cid'].".".'avatar';
        if(file_exists($avatarfile)){
        $avatar_pic = "<img src=members.php?action=image&userid=".$apt->cookie['cid'].">";
        }else{
        $avatar_pic = "<img src=images/no_pic.gif>";
        }	
    }

    eval("\$index_middle = \" " . $apt->gettemplate ( 'members_link' ) . "\";");

    eval("\$index_middle .= \" " . $apt->gettemplate ( 'member_cp' ) . "\";");

    $apt->html_Output($left_menu);
}
elseif ($apt->get['action']=="changepass")
{
    checkgroup('view_site');
    checkcookie();

    $apt->head(LANG_TITLE_CHANGE_PASSWORD);
    $result = $apt->query("SELECT * FROM rafia_users WHERE userid='".$apt->cookie['cid']."'");
    $row    = $apt->dbarray($result);
    @extract($row);
     $fo = new form;
    eval("\$index_middle = \" " . $apt->gettemplate ( 'members_link' ) . "\";");
    $form .=  $fo->inputform  ($apt->lang_form['24'],"password", "opassword","*");
    $form .=  $fo->inputform  ($apt->lang_form['12'],"password", "npassword","*");
    $form .=  $fo->inputform  ($apt->lang_form['13'],"password", "npassword2","*");

    $image = "themes/".$GLOBALS[themepath]."/do.gif";
    $output = array("action"      => "$PHP_SELF?action=UP",
                    "title"      => LANG_TITLE_CHANGE_PASSWORD,
                    "method"     => '',
                    "name"       => '',
                    "content"    => $form,
                    "image"      => $image
                   );
    $index_middle .= $fo->formtable($output);
    $apt->html_Output($left_menu);

}
else if ($apt->get['action']=="UP")
{
    checkgroup('view_site');
    checkcookie();
    
    @extract($HTTP_POST_VARS);
    
    if ($apt->txtcounmxs($npassword,4))
    {
        $apt->errmsg(LANG_ERROR_PASS_MUST_MORE);
    }
    if ($npassword != $npassword2)
    {
        $apt->errmsg (LANG_ERROR_PASS_EQUAL);
    }

    $result = $apt->query("SELECT password FROM rafia_users WHERE userid='".$apt->cookie['cid']."'");

    $row    = $apt->dbarray($result);

    if ( md5($opassword) != $row["password"] )
    {
        $apt->errmsg(LANG_ERROR_PASS);
    }

    $npassword = $apt->format_data(md5($npassword));

    $result    = $apt->query("update rafia_users set
                              password='$npassword'
                              WHERE userid='".$apt->cookie['cid']."'");
    if ($result)
    {
        $apt->setoutcookie ();
        
        $apt->bodymsg(LANG_MSG_PASSWORD_HAS_CHANGED,"$PHP_SELF?action=cp");
          
     }
     else
    {
        $apt->bodymsg(LANG_ERROR_ADD_DB,"$PHP_SELF?action=cp");
    }
}
if ($apt->get['action']=="edit")
{
    checkgroup('view_site');
    checkcookie();

    $apt->head(LANG_TITLE_EDIT_OPTIONS);

    $result = $apt->query("SELECT * FROM rafia_users WHERE userid='".$apt->cookie['cid']."'");

    $row = $apt->dbarray($result);
    @extract($row);

    $homepage   = $apt->format_data_out($homepage);
    $email      = $apt->format_data_out($email);

    eval("\$index_middle = \" " . $apt->gettemplate ( 'members_link' ) . "\";");
    if($avatar == 0){
        $avatar_pic = '�� ����<input type=hidden value=0 name=avatar>';
    }else{
        $avatarfile = $apt->upload_path."/".$apt->cookie['cid'].".".'avatar';
        if(file_exists($avatarfile)){
        $avatar_pic = "<input type=hidden value=1 name=avatar><img src=members.php?action=image&userid=".$apt->cookie['cid'].">";
        }else{
        $avatar_pic = '�� ����<input type=hidden value=0 name=avatar>';
        }	
    }

    $fo = new form;
    $fo->use_smiles =0;
    $form .= $fo->inputform($apt->lang_form['15'],"text", "homepage","","$homepage",40);
    $form .= $fo->inputform($apt->lang_form['14'],"text","email","*","$email",30);
    $form .= $fo->yesorno($apt->lang_form['37'], "viewemail", $viewemail);
    $form .= $fo->yesorno($apt->lang_form['32'], "showemail", $showemail);
    $form .= $fo->yesorno    ($apt->lang_form['31'], "html_msg", $html_msg);
    $form .= $fo->selectstheme ($usertheme);
    $form .= "<tr><td nowrap class=\"info_bar\">������ ������� ������� : </td>
		  <td align=right width=\"100%\">$avatar_pic</td></tr>";
    $form .= $fo->inputform  ("���� ���� ����� �����<br>(���� �� 100*100)","file","avfile","");
    $fo->countpost  = $apt->getsettings("txtcount7");
    $form .= $fo->txtcount  ();
    $form .= $fo->textarea   ($apt->lang_form['17'],"post",$signature,6);


    $image = "themes/".$GLOBALS[themepath]."/do.gif";
    $output = array("action"      => "$PHP_SELF?action=update",
                    "title"      => LANG_TITLE_EDIT_OPTIONS,
                    "method"     => '',
                    "name"       => '',
                    "content"    => $form,
                    "image"      => $image
                   );

         $index_middle .= $fo->formtable($output);
    $apt->html_Output($left_menu);

}
else if ($apt->get['action']=="update")
{
    checkgroup('view_site');
    checkcookie();
    @extract($HTTP_POST_VARS);
    
    if (!$apt->check_email($email))
    {
        $apt->errmsg(LANG_ERROR_VALID_EMIAL);
    }
    
    if (!$apt->txtcounmxs($post,$apt->getsettings("txtcount7")))
    {
        $apt->errmsg(LANG_ERROR_LETTER_MAX);
    }
    $apt->set_cookie ("logintheme",$usertheme);
    $_SESSION["sesstheme"]   = $usertheme;
    
    $homepage  =   $apt->format_data($homepage);
    $email     =   $apt->format_data($email);
    $signature =   $apt->format_post($post);
    $showemail =   intval($apt->format_data($showemail));
    $usertheme =   $apt->format_data($usertheme);
    $html_msg  =   intval($apt->format_data($html_msg));
    $avatar  =   intval($apt->format_data($avatar));

    if ($apt->files["avfile"]["tmp_name"] != ''){
    $size_limit = 15;
    $allow_ext = array('.gif','.png','.jpg');
    $allow_types = array('image/jpeg', 'image/jpg', 'image/pjpeg', 'image/png', 'image/x-png', 'image/gif');
    $file 	= $apt->files["avfile"]["tmp_name"];
    $size 	= $apt->files["avfile"]["size"];
    $type 	= $apt->files["avfile"]["type"];
    $rname 	= $apt->files["avfile"]["name"];
    $ext  	= strrchr($rname,'.');
    $size = @intval($size / 1024);
    $allow_e = in_array($ext,$allow_ext);
    $allow_t = in_array($type,$allow_types);
    $imsize = getimagesize($file);
    $x = $imsize[0];
    $y = $imsize[1];

    if($x > 100){
    $apt->errmsg("���� ... �� ���� ������ ���� ����� ���� �� 100*100");
    }elseif($y > 100){
    $apt->errmsg("���� ... �� ���� ������ ���� ����� ���� �� 100*100");
    }elseif(!$allow_e){
    $apt->errmsg("���� ... �� ���� ������ ��� �������� �� �������");
    }elseif(!$allow_t){
    $apt->errmsg("���� ... �� ���� ������ ��� ����� �� �������");
    }elseif($size > $size_limit){
    $apt->errmsg("���� ... ����� ���� ����� ���� ���� �� ����� ������� ��<br>����� ������� �� �� $size_limit ��������");
    }else{
    if(@is_uploaded_file($file)){
    $avatarfile = $apt->upload_path."/".$apt->cookie['cid'].".".'avatar';
    $do = @move_uploaded_file($file,"$avatarfile");}
    }
    if($do){$newavatar = 1;}else{$newavatar = 0;}
    }else{
    if($avatar == 1){
    $newavatar = 1;}else{
    $newavatar = 0;}
    }

    if (!$apt->is_Str($usertheme))
    {
        $usertheme ="arabportal";  
    }

    $result    =   $apt->query("update rafia_users set homepage='$homepage',
                                                         email='$email',
                                                         viewemail='$viewemail',
                                                         showemail='$showemail',
                                                         html_msg='$html_msg',
                                                         usertheme='$usertheme',
                                                         signature='$signature',
                                                         avatar='$newavatar'
                                                         WHERE userid='".$apt->cookie['cid']."'");

     if ($result)
    {

        $apt->bodymsg(LANG_MSG_INFORMATION_HAS_MODIFIED,"$PHP_SELF?action=cp");
    }
    else
    {
        $apt->bodymsg(LANG_ERROR_ADD_DB,"$PHP_SELF?action=cp");
    }
}
else if ($apt->get['action']=="signup")
{
    if ($apt->getsettings("newuserallow") == 'no')
    {
        $apt->errmsg(LANG_ERROR_REGISTER_CLOSED);
    }



    if ( $apt->cookie['clogin'] != 'rafiaphp' )
    {
        session_unset();
        session_destroy();
       $apt->setoutcookie();
        $apt->head(LANG_TITLE_REGISTRATION);
        eval("\$index_middle = \" " . $apt->gettemplate ( 'register_policy' ) . "\";");


        $fo = new form;
        $fo->countpost = $apt->getsettings("txtcount7");
        $fo->use_smiles = 0;
        $form .= $fo->inputform  ($apt->lang_form['11'],"text", "username","*");
        $form .= $fo->inputform  ($apt->lang_form['12'],"password", "password","*");
        $form .= $fo->inputform  ($apt->lang_form['13'],"password", "password2","*");
        $form .= $fo->inputform  ($apt->lang_form['14'],"text", "email","*","","30");
        $form .= $fo->inputform  ($apt->lang_form['38'].$apt->lang_form['14'],"text", "email2","*","","30");
        $form .= $fo->inputform  ($apt->lang_form['15'],"text", "homepage","","http://","30");  // Edited by Myrosy
        $form .= $fo->yesorno($apt->lang_form['37'], "viewemail", 0);
        $form .= $fo->yesorno    ($apt->lang_form['32'], "showemail", 1);
        $form .= $fo->yesorno    ($apt->lang_form['31'], "html_msg", 0);
        $form .= $fo->selectstheme ($apt->theme);
        $form .= $fo->hiddenform  ("spam","1");
        $form .= $fo->txtcount   ();
        $form .= $fo->textarea   ($apt->lang_form['17'],"post",$signature,"6");

        $image = "themes/".$GLOBALS[themepath]."/do.gif";

        $output = array("action"      => "members.php?action=insert",
                        "title"      => LANG_TITLE_REGISTRATION,
                        "method"     => 'post',
                        "name"       => '',
                        "content"    => $form,
                        "image"      => $image
                       );
                       
         $index_middle .= $fo->formtable($output,1,'regnotspam');
         $apt->html_Output($left_menu);
    }
    else
    {
        $apt->head(LANG_TITLE_REGISTRATION);
        $apt->errmsg(LANG_ERROR_MEMBER_REGISTER_REACCESS);
    }
}
else if ($apt->get['action']=="insert")
{
    $newuserallow = $apt->getsettings("newuserallow");
    
    if ($newuserallow == 'no')
    {
        $apt->errmsg($error_member[8]);
    }
    @extract($HTTP_POST_VARS);

    $this_url = explode('/',$_SERVER['HTTP_HOST']);
    $reff_url = explode('/',$_SERVER['HTTP_REFERER']);

    if($this_url[0] !== $reff_url[2]){
    $apt->bodymsg('���� ... �� ����� ����� ������ �� ���� ������',"members.php?action=signup");
    }

    if($spam !== 'regnotspam'){
    $apt->bodymsg('���� ... ��� ������� ��� ������',"members.php?action=signup");
    exit;
    }

    $fullarr =  array($username,$password,$email);

    if (!$apt->full($fullarr))
    {
        $apt->errmsg(LANG_ERROR_VALIDATE);
    }

    if ($apt->check_name($username))
    {
        $apt->errmsg (LANG_ERROR_USERNAME_MUST_BE);
    }
    
    if ($apt->txtcounmxs($username,2))
    {
        $apt->errmsg(LANG_ERROR_USERNAME_MUST_MORE);
    }
    
  if (!$apt->checkifues("username",$username))
    {
        $apt->errmsg (LANG_ERROR_USERNAME_EXISTED);
    }

    if ($apt->txtcounmxs($password,3))
    {
        $apt->errmsg(LANG_ERROR_PASS_MUST_MORE);
    }

    if ($password != $password2)
    {
        $apt->errmsg (LANG_ERROR_PASS_EQUAL);
    }

  if (!$apt->check_email($email))
    {
        $apt->errmsg(LANG_ERROR_VALID_EMIAL);
    }
    if ($email != $email2)
    {
        $apt->errmsg (LANG_ERROR_EMAIL_EQUAL);
    }
    if (!$apt->checkifues("email",$email))
    {
        $apt->errmsg (LANG_ERROR_EMIAL_EXISTED);
    }

    if (!$apt->txtcounmxs($post,$apt->getsettings("txtcount7")))
    {
        $apt->errmsg(LANG_ERROR_LETTER_MAX);
    }
      
    $username  = $apt->format_data($username);
    $password  = $apt->format_data(md5($password));
    $homepage  = $apt->format_data($homepage);
    $email     = $apt->format_data($email);
    $signature = $apt->format_post($post);
    $activate  = $apt->makeactivate();
    $viewemail = $apt->format_data($viewemail);
    $showmail  = intval($apt->format_data($showmail));
    $usertheme = $apt->format_data($usertheme);
    $html_msg  = intval($apt->format_data($html_msg));

    if (!$apt->is_Str($usertheme))
    {
        $usertheme ="arabportal";    // Edited By Myrosy

    }

    $datetime  = time();

    $result=$apt->query("insert into rafia_users (username,
                                                    password,
                                                    usergroup,
                                                    email,
                                                    homepage,
                                                    viewemail,
                                                    showemail,
                                                    signature,
                                                    datetime,
                                                    allowpost,
                                                    activate,
                                                    usertheme,
                                                    html_msg)
                                              values
                                                    ('$username',
                                                    '$password',
                                                    '2',
                                                    '$email',
                                                    '$homepage',
                                                    '$viewemail',
                                                    '$showemail',
                                                    '$signature',
                                                    '$datetime',
                                                    '$newuserallow',
                                                    '$activate',
                                                    '$usertheme',
                                                    '$html_msg')");

   if ($result)
   {
   	   $Counter->increment('usersCount');
   	   
       if($newuserallow == "wit")
       {
           $url       = $apt->getsettings("siteURL")."/members.php?action=activate&allowid=$activate";
           $sitetitle = $apt->getsettings("sitetitle");
           $sitemail  = $apt->getsettings("sitemail");
           eval("\$subject = \" " . $apt->getsettings("subject_activate") . "\";");

           $replace   =  array(  "{username}"  => $apt->post['username'] ,
                                 "{sitetitle}" => $sitetitle,
                                 "{url}"       => $url,
                                 "{sitemail}"  => $delaleurl);
           $mail = new email;
           $message = $apt->getmessage('msg_activate',0,$replace);
           $mail->send($email,
           $subject,
           $message,
           $sitetitle,
           $sitemail,
           0);
           
           $apt->head($title);

          $index_middle = LANG_MSG_YOUR_REGISTRATION_WHIT_APPROVED;

          $apt->html_Output($left_menu);
        }
        else
        {

            $apt->bodymsg(LANG_MSG_YOUR_REGISTRATION_SUCCESSFULLY,"index.php");
        }
   }
   else
   {
        $apt->bodymsg(LANG_ERROR_ADD_DB,"index.php");
   }
}
else if ($apt->get['action']=="logout")
{
    session_unset();
    session_destroy();
    $apt->setoutcookie();
    header("Refresh: 0;url=".$apt->refe);
    $apt->bodymsg(LANG_MSG_LOGED_OUT,$apt->refe);
}
else if ($apt->get['action']=="lostpass")
{
    if(!isset($HTTP_GET_VARS['code']))
    {
        $apt->errmsg(LANG_ERROR_URL);
    }
    $code = $apt->format_data($HTTP_GET_VARS['code']);

    $result = $apt->query("SELECT email,username FROM rafia_users WHERE activate='$code' and useradmin !='1'");

    if($apt->dbnumrows($result)>0)
    {
         $apt->head (LANG_TITLE_SEND_MESSAGE_TO_MEMBER);
         $fo = new form;


       $form .= $fo->hiddenform ("code","$code");
       $form .= $fo->hiddenform ("action","uppass");
       $form .= $fo->inputform  ("��� �������","text", "myuserid","*");
       $form .= $fo->inputform  ("���� ������ ������� ","text", "mynewpass","*");
       $form .= $fo->inputform  ("�����  ���� ������ ������� ","text", "mynewpass2","*");
       $image = "themes/".$GLOBALS[themepath]."/do.gif";

        $output = array("action"      => "$PHP_SELF?action=uppass",
                        "title"       => "����� ���� ���� �����",
                        "method"      => '',
                        "name"        => '',
                        "content"     => $form,
                        "image"       => $image
                       );
         $index_middle  = $fo->formtable($output);
         $right_menu    =  $menu->_menu(1);
         $apt->html_Output("");

    }
    else
    {
        $apt->errmsg("�� ���� ����� ���� ������ ������ ������ ����� ������");
    }
}
else if ($apt->get['action']=="uppass")
{
     $arr_post_vars = array($apt->post['action'],
                            $apt->post['code'],
                            $apt->post['myuserid'],
                            $apt->post['mynewpass'],
                            $apt->post['mynewpass2']);
                            
     if (!$apt->full($arr_post_vars))
     {
         $apt->errmsg(LANG_ERROR_VALIDATE);
     }
     if ($apt->post['mynewpass'] != $apt->post['mynewpass2'])
    {
        $apt->errmsg (LANG_ERROR_PASS_EQUAL);
    }

    if ($apt->txtcounmxs($apt->post['mynewpass'],4))
    {
        $apt->errmsg(LANG_ERROR_PASS_MUST_MORE);
    }

    $mynewpass = $apt->format_data(md5($apt->post['mynewpass']));

    $result    = $apt->query("update rafia_users set
                                password='$mynewpass'
                                WHERE activate='".$apt->post['code']."'
                                and userid='".$apt->post['myuserid']."'
                                and useradmin !='1'");
    if ($result)
    {
        $apt->setoutcookie ();

        $apt->bodymsg(LANG_MSG_PASSWORD_HAS_CHANGED,"$PHP_SELF?action=cp");

     }
     else
    {
        $apt->bodymsg(LANG_ERROR_ADD_DB,"index.php");
    }
}
else if ($apt->get['action']=="activate")
{
    $get_activate = $apt->format_data($HTTP_GET_VARS['allowid']);

    $result = $apt->query("SELECT allowpost FROM rafia_users WHERE
                           activate='$get_activate'");


    $row = $apt->dbarray($result);

    @extract($row);

    if ($allowpost == "no")
    {
        $apt->head(LANG_TITLE_REGISTRATION);

        $index_middle = LANG_ERROR_YOU_STOPPING;

       $apt->html_Output($left_menu);

    }
    elseif (( $allowpost == "wit") || ($allowpost == "yes"))
    {
        $result = $apt->query("update rafia_users set  allowpost='yes' WHERE activate='$get_activate'");

        if ($result)
        {
            $apt->head(LANG_TITLE_REGISTRATION);
            $index_middle = '<b>'.LANG_MSG_YOUR_ACCOUNT_HAS_APPROVED;
            $index_middle .='<a href="members.php?action=cp"><br><font color="#FF0000">���� ������</a>';
            $apt->html_Output($left_menu);
       
          //  $apt->bodymsg(LANG_MSG_YOUR_ACCOUNT_HAS_APPROVED,"members.php?action=cp");
        }
        else
        {
            $apt->bodymsg(LANG_ERROR_ADD_DB,"index.php");
        }
    }
}
else if ($apt->get['action']=="delale")
{
    if ($news_id !="")
    {
        $result = $apt->query("delete from  rafia_alert
                                              WHERE news_id='$news_id'
                                              and userid='$userid'");
    }
    elseif ($thread_id !="")
    {
        $result = $apt->query("delete from  rafia_alert
                                              WHERE thread_id='$thread_id'
                                              and userid='$userid'");
    }
    elseif ($down_id !="")
    {
        $result = $apt->query("delete from  rafia_alert
                                              WHERE down_id='$down_id'
                                              and userid='$userid'");
    }
    if ($result)
    {
         $apt->bodymsg('',"index.php");
    }
    else
    {
         $apt->bodymsg(LANG_ERROR_ADD_DB."index.php");
    }
}
else if ($apt->get['action']=="image"){
     $userid = $apt->setid('userid');
     $avatarfile = $apt->upload_path."/".$userid.".".'avatar';
     if(file_exists($avatarfile)){
     $filesize = @filesize($avatarfile);
     header("Content-type: image/gif");
     header("Content-disposition: inline; filename=".$userid.".gif");
     header("Content-Length: $filesize");
     header("Pragma: no-cache");
     header("Expires: 0");
     $readfile = readfile($avatarfile, "r");
     }
}else if ($apt->get['action']=="")
{
     checkgroup('view_site');
     checkgroup('allow_members_list');    
     $apt->head(LANG_TITLE_MEMBERS);

     $member_lang_head = LANG_TITLE_MEMBERS;

     $result      = $apt->query("SELECT * FROM rafia_users WHERE userid >'0' and userid != $apt->Guestid ORDER BY userid ASC LIMIT $start,$perpagelist");   // Edited By Myrosy

     $page_result = $apt->query("SELECT * FROM rafia_users");

      $apt->numrows  = $apt->dbnumrows($page_result);

         eval("\$index_middle .= \" " . $apt->gettemplate ( 'show_members' ) . "\";"); // Added By Myrosy
     while($row = $apt->dbarray($result))
	 {
         @extract($row);

         $homepage = $apt->addToURL ($homepage);
         $username = $apt->format_data_out($username);
         $email    = $apt->format_data_out($email);
         $apt->color($color);
         eval("\$index_middle .= \" " . $apt->gettemplate ( 'show_members_list' ) . "\";"); // Added By Myrosy

     }

     $index_middle .= $apt->pagenum($perpagelist,"");
     
     $apt->html_Output($left_menu);

}
if(isset($fo))
{
    print $apt->script->post_java();
}
$apt->foot($pageft);

?>