<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|                                           |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 22/10/2006 Time: 10:00 PM  |
+===========================================+
prevent spam
*/
class Spams
{
   var $timeOut  = 30;
   
    function Spams()
    {
        global $apt;
        if(isset($this->conf['spam_timeOut']))
        {
            $this->timeOut = $this->conf['spam_timeOut'];
        }
    }
    function is_ip()
    {
        global $apt;
        
        $valid = TRUE;
        $ip = $apt->ip;
        $ip = explode(".", $ip);
        if(count($ip)!=4)
        {
            return false;
        }
        foreach($ip as $block)
        {
            if(!is_numeric($block) || $block>255 || $block<0)
            {
                $valid = false;
            }
        }
        return $valid;
    }

    function checkSpams()
    {
        global $apt;
        
        if($this->is_ip()==false)
        {
            $apt->errmsg('��� ��  IPAddress : '.$apt->ip);
        }
        $IPAddress = $apt->ip;
        
        $result = $apt->query("SELECT spamtime FROM rafia_spam WHERE spamip='$IPAddress'");

        if( $apt->numRows($result) > 0)
        {
            $row = $apt->dbarray( $result ) ;
            if($row[0]+($this->timeOut) > time())
            {
                return false;
            }
            else
            {
                $this->updateSpams();
                return TRUE;
            }
        }
        else
        {
            $this->insertSpams();
            return TRUE;
        }
 	}
  
    function insertSpams()
    {
        global $apt;
        
        if($this->is_ip()==false)
        {
            $apt->errmsg('��� ��  IPAddress : '.$apt->ip);
        }
        $spamip   = $apt->ip;
        $spamtime = time();
        $apt->query("insert into rafia_spam (spamtime, spamip) values ('$spamtime', '$spamip')",'rafia_spam');

 	}
    function updateSpams()
    {
        global $apt;

        if($this->is_ip()==false)
        {
            $apt->errmsg('��� ��  IPAddress : '.$apt->ip);
        }
        $spamip   = $apt->ip;
        $spamtime = time();
        $apt->query("update rafia_spam set spamtime ='$spamtime' where spamip='$spamip'");

 	}
}