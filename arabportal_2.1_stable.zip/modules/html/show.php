<?php
if (RUN_MODULE !== true)
{
    die ("<center><h3>���� ��� ������� ��� ������</h3></center>");
}

$file = $_GET['file'];

if (eregi("http\:\/\/", $apt->get[file])){
	$apt->errmsg (_MOD_NOT_AUTH);
}elseif(eregi("/", $apt->get[file])){
	$apt->errmsg (_MOD_NOT_AUTH);
}

$mod->modInfo[left_menu] = 0;

$images = array("jpg","gif","bmp","tif","png");
$videos  = array("rm","wmv","mpg","avi","mov","ram","wma");
$zip = array("zip","rar","gz","tar","bz","bz2");
$pages = array("html","htm","txt");

$ext = strtolower(end(explode('.', $file)));

if (in_array($ext,$pages)) {
$open = @fopen("modules/html/files/$file",r);
$data = @fread($open,@filesize("modules/html/files/$file"));
@fclose($open);
echo $data;
}elseif (in_array($ext,$images)) {
header("Content-Type: image/$ext");
header("Content-disposition: inline; filename=$file");
header("Pragma: no-cache");
header("Expires: 0");
$open = @fopen("modules/html/files/$file",r);
$data = @fread($open,@filesize("modules/html/files/$file"));
@fclose($open);
echo $data;
exit;
}else{
header( "Content-Type: application/x-ms-download");
header("Content-disposition: attachment; filename=$file");
header("Pragma: no-cache");
header("Expires: 0");
$open = @fopen("modules/html/files/$file",r);
$data = @fread($open,@filesize("modules/html/files/$file"));
@fclose($open);
echo $data;
exit;
}



?>