<?php

if (RUN_MODULE !== true)
{
    die ("<center><h3>���� ��� ������� ��� ������</h3></center>");
}

$mod_theme	= $mod->modInfo[themeid];
$mod_name	= $mod->modInfo[mod_name];
$modid	= $mod->modInfo[id];
$mod_title	= $mod->modInfo[mod_title];

$blade = $_GET[blade];
$t = $_GET[t];

if (isset($blade)==0) {$blade="main";}
if ($blade == "main") {
@set_time_limit(0);
$url = "http://www.aljazeera.net/NR/exeres/4E190DB9-1C92-43A3-A209-8E5DE79CC343.htm";
$string = $apt->get_contents($url);
$site= "http://www.aljazeera.net";
$string2 = @explode('<!-- BreakingNews End -->', $string);
$string3 = @explode('<!-- Body End -->', $string2[1]);
$news = str_replace('href="','style="text-decoration: none" href="mod.php?mod=aljazeera&blade=news&t=',$string3[0]);
$news = str_replace('src="','SRC="'.$site,$news);

include("ConvertCharset.class.php");
$ToCharset = 'windows-1256'; 
$FromCharset = 'utf-8'; 
$convert  = new ConvertCharset(); 
$news = $convert->Convert($news, $FromCharset, $ToCharset);
$middle = $news;

eval("\$index_middle = \" " . $apt->getmodtemplate ( 'main', $modid,$mod_theme ) . "\";");

} elseif ($blade == "news") {
@set_time_limit(0);
$site= "http://www.aljazeera.net";
$url = "http://www.aljazeera.net".$t;
$string = $apt->get_contents($url);
$string2 = @explode('<!-- PageServices End -->', $string);
$string3 = @explode('<td class="tdSourceAgency" noWrap width="10%"><span id="ReadOnlyMetadataPlaceholder5"><span>&#1575;&#1604;&#1580;&#1586;&#1610;&#1585;&#1577; </span></span></td>', $string2[1]);
$news = str_replace('src="','src="'.$site,$string3[0]);
$news = str_replace('http://www.aljazeera.net/News/Images/icons/print.gif','modules/aljazeera/images/blank.gif',$news);
$news = str_replace('http://www.aljazeera.net/News/Images/icons/email.gif','modules/aljazeera/images/blank.gif',$news);
//$news = str_replace('','',$news);

include("ConvertCharset.class.php");
$ToCharset = 'windows-1256';
$FromCharset = 'utf-8';
$convert  = new ConvertCharset(); 
$news = $convert->Convert($news, $FromCharset, $ToCharset);
$middle .= $news;
eval("\$index_middle = \" " . $apt->getmodtemplate ( 'news', $modid,$mod_theme ) . "\";");
}

echo $index_middle;
?>