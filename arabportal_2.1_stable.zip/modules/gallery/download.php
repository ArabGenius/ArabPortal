<?php
/***************************************************************************
			   ������ ���� ����� ����� ������� �������
			   ����� ����� ����� || ���� ��� �������
			www.arabiaone.org (arabgenius@hotmail.com)
***************************************************************************/

if (RUN_MODULE !== true){
	die ("<center><h3>���� ��� ������� ��� ������</h3></center>");
}

$imgid = $apt->setid('imgid');
$zip = intval($_GET[zip]);
$result = $apt->query("SELECT * FROM rafia_gallery_image where imgid='$imgid'");
if($apt->dbnumrows($result)== 0){
	$apt->errmsg("���� ... ������ ���� ���� ���� ��� ������ �� �� �����");
}else{
	$row = $apt->dbarray($result);
	@extract($row);
	if($zip ==1){
		include("modules/gallery/config.php");
		include("modules/gallery/zip.php");
		$file_path = "modules/gallery/photos/$imglink";
		$file_name = basename($file_path);
		$file_path2 = "modules/gallery/thumb/$imglink";
		$zipfile = new zipfile();
		$file_size = @filesize($file_path);
		$file_size2 = @filesize($file_path2);
		$fp = @fopen($file_path, "r");
		if ($fp) {
		$file_data = @fread($fp, $file_size);
		@fclose($fp);
		}
		$fp2 = @fopen($file_path2, "r");
		if ($fp2) {
		$file_data2 = @fread($fp2, $file_size2);
		@fclose($fp2);
		}

		$imgsize = @intval($file_size / 1024);
		$size = @GetImageSize($file_path);
		$wt = $size[0];
		$ht = $size[1];
		$imgdate = $apt->Hijri($imgdate);
		$imgrate	= @round($rate/$rateno,2);
		$imgtitle = $apt->format_data_out($imgtitle);
		$imgdesc = $apt->format_data_out($imgdesc);

		$sitetitle = $apt->getsettings("sitetitle");
		$siteURL = $apt->getsettings("siteURL");

			$textsource = "<html dir=rtl><meta http-equiv=Content-Type content=text/html; charset=windows-1256>
		<title>$sitetitle</title><center>";
		$textsource = "<html dir=rtl>

<meta http-equiv=Content-Type content=text/html; charset=windows-1256 />
<title>$sitetitle-���� �����-$imgtitle</title>
<style>
.cell_Q { background: #3A76A1 url('%22modules/gallery/images/ds_bluedark_bg.gif%22') no-repeat; width:19%; color:#FFFFFF; font-family:Arial, Helvetica, Tahoma, Verdana, sans-serif; font-size:12pt; font-weight:bold; background-color:#3A76A1 }
.cell_R { color:#000000; font-family:Arial, Helvetica, Tahoma, Verdana, sans-serif; font-size:12pt; font-weight:bold;}
.cell_A { background: #73B3E1 url('%22modules/gallery/images/ds_bluelight_bg.gif%22') no-repeat; width:31%; font-family:Tahoma, MS Sans Serif, Arial, Helvetica, Verdana, sans-serif; color:#FF0000; font-size:10pt; background-color:#73B3E1}
.cell_A a:active { color: #FF0000; font-size: 10pt;}
.cell_A a:link {  color: #1F5577; font-size: 10pt;}
.cell_A a:visited {  color: #FF0000; font-size: 10pt;}
.cell_A a:hover {  color: #A89B00; font-size: 10pt;}

.headline { color: #000000; font-family: Arial, Helvetica, Tahoma, Verdana, sans-serif; font-size: 12pt; font-weight: bold; }
.date {  color: #1F5577;  font-family: MS Sans Serif, Tahoma, Arial, Helvetica, Verdana, sans-serif; font-size: 10pt; }
</style>
<div align=center>
  <table border=0 width=90% id=table108 cellspacing=0 cellpadding=0>
    <tr>
      <td>
      <div align=center>
        <table border=0 width=100% id=table110 cellspacing=0 cellpadding=0>
          <tr>
            <td>
            <table border=0 width=100% id=table111 cellspacing=0 cellpadding=0>
              <tr>
                <td>
                <table border=0 width=100% id=table112 cellspacing=0 cellpadding=0>
                  <tr>
                    <td background=%22modules/gallery/images/ds_frame_headline_bg.gif/%22 align=center height=26>
                    <table border=0 width=100% id=table113 cellspacing=0 cellpadding=0>
                      <tr>
                        <td align=center class=headline>$imgtitle</td>
                        <td align=left width=130 class=date>$imgdate</td>
                      </tr>
                    </table>
                    </td>
                  </tr>
                </table>
                </td>
              </tr>
            </table>
            </td>
          </tr>
          <tr>
            <td>
            <table border=0 width=100% id=table114 cellspacing=0 cellpadding=0>
              <tr>
                <td bgcolor=#F1F1F1 valign=top height=5>
                <img border=0 src=%22modules/gallery/images/spacer.gif/%22 width=1 height=1 /></td>
              </tr>
              <tr>
                <td bgcolor=#F1F1F1 valign=top>
                <table border=1 width=100% id=table115 cellspacing=0 cellpadding=0 bordercolor=#1F5577 style=border-collapse: collapse>
                  <tr>
                    <td background=%22modules/gallery/images/ds_bluedark_bg.gif/%22 align=center width=110 class=cell_q>
                    ����� ������</td>
                    <td width=190 class=cell_a>
                    <div align=center>
                      <table border=0 width=90% id=table116 cellspacing=0 cellpadding=0>
                        <tr>
                          <td class=cell_a>$username</td>
                        </tr>
                      </table>
                    </div>
                    </td>
                    <td background=%22modules/gallery/images/ds_bluedark_bg.gif/%22 align=center width=110 class=cell_q>
                    ����� ������</td>
                    <td width=190 class=cell_a>
                    <div align=center>
                      <table border=0 width=90% id=table117 cellspacing=0 cellpadding=0>
                        <tr>
                          <td class=cell_a>$imgrate / 5</td>
                        </tr>
                      </table>
                    </div>
                    </td>
                  </tr>
                  <tr>
                    <td background=%22modules/gallery/images/ds_bluedark_bg.gif/%22 align=center class=cell_q>
                    ��� ������</td>
                    <td class=cell_a>
                    <div align=center>
                      <table border=0 width=90% id=table118 cellspacing=0 cellpadding=0>
                        <tr>
                          <td class=cell_a>$imgsize ��������</td>
                        </tr>
                      </table>
                    </div>
                    </td>
                    <td background=%22modules/gallery/images/ds_bluedark_bg.gif/%22 align=center class=cell_q>
                    ���� ��������</td>
                    <td class=cell_a>
                    <div align=center>
                      <table border=0 width=90% id=table119 cellspacing=0 cellpadding=0>
                        <tr>
                          <td class=cell_a>$imgview</td>
                        </tr>
                      </table>
                    </div>
                    </td>
                  </tr>
                  <tr>
                    <td background=%22modules/gallery/images/ds_bluedark_bg.gif/%22 align=center class=cell_q>
                    ����� ������</td>
                    <td class=cell_a>
                    <div align=center>
                      <table border=0 width=90% id=table120 cellspacing=0 cellpadding=0>
                        <tr>
                          <td class=cell_a>$ht � $wt</td>
                        </tr>
                      </table>
                    </div>
                    </td>
                    <td background=%22modules/gallery/images/ds_bluedark_bg.gif/%22 align=center class=cell_q>
                    ���� �������</td>
                    <td class=cell_a>
                    <div align=center>
                      <table border=0 width=90% id=table121 cellspacing=0 cellpadding=0>
                        <tr>
                          <td class=cell_a>$imgdown</td>
                        </tr>
                      </table>
                    </div>
                    </td>
                  </tr>
                  <tr>
                    <td background=%22modules/gallery/images/ds_bluedark_bg.gif/%22 align=center class=cell_q no-repeat valign=top>
                    ��� ������</td>
                    <td colspan=3 class=cell_a>
                    <div align=center>
                      <table border=0 width=96% id=table122 cellspacing=0 cellpadding=0>
                        <tr>
                          <td class=cell_a>$imgdesc</td>
                        </tr>
                      </table>
                    </div>
                    </td>
                  </tr>
                </table>
                <table border=0 width=100% id=table123 cellspacing=0 cellpadding=0>
                  <tr>
                    <td>
                    <img border=0 src=%22modules/gallery/images/spacer.gif/%22 width=1 height=15 /></td>
                  </tr>
                  <tr>
                    <td>
                    <table border=1 width=100% id=table127 cellspacing=0 cellpadding=0 bgcolor=#D8F0FF style=border-collapse: collapse bordercolor=#1F5577>
                      <tr>
                        <td align=center class=cell_R><b>���� <span lang=en-us>
                        <a href=$siteURL>$sitetitle</a></span><br />
                        <hr><a href=http://www.arabportal.net>���� ������� �������</a><br />
                        <a href=http://www.arabiaone.org>����� ���� �����</a></b></td>
                        </tr>
                      </table>
                      </td>
                    </tr>
                  </table>
                  </td>
                </tr>
              </table>
              </td>
            </tr>
          </table>
          </div>
        </td>
      </tr>
    </table>
    </div>

</html>";

		$site_title = $apt->getsettings("sitetitle");
		$site_url = $apt->getsettings("siteURL");
		$source = "[DEFAULT]
BASEURL=$site_url/mod.php?mod=gallery
[InternetShortcut]
URL=$site_url/mod.php?mod=gallery
Modified=000E9EEB1F8FC6010C";
		$zipfile->add_file($textsource, "readme.html");
		$zipfile->add_file($source, "gallery.url");
		$zipfile->add_file($file_data, $file_name);
		$zipfile->add_file($file_data2, 'thumb_'.$file_name);
		$zip_file_name = substr($file_name,0,10);
		$zipfile->send("$zip_file_name.zip");
			$update = $apt->query("Update rafia_gallery_image set imgdown=imgdown+1 where imgid='$imgid'");
 		exit;
	}else{
		$file_name = basename("modules/gallery/photos/$imglink");
		$filesize = @filesize("modules/gallery/photos/$imglink");
		header( "Content-Type: application/x-ms-download");
		header("Content-disposition: attachment; filename=$file_name");
		header("Content-Length: $filesize");
		header("Pragma: no-cache");
		header("Expires: 0");
		@readfile("modules/gallery/photos/$imglink");
			$update = $apt->query("Update rafia_gallery_image set imgdown=imgdown+1 where imgid='$imgid'");
		exit;
	}
}
?>