<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 22/10/2006 Time: 10:00 PM  |
+===========================================+
*/

if (RUN_MODULE !== true)
{
    die ("<center><h3>���� ��� ������� ��� ������</h3></center>");
}

$mod_theme = $mod->modInfo[themeid];
$mod_name = $mod->modInfo[mod_name];
$mod_title = $mod->modInfo[mod_title];

echo $apt->table_cat_module("<a href=mod.php?mod=$mod_name>&nbsp;$mod_title</a>");

$middle = "<SCRIPT LANGUAGE=javascript>
function show_hide_FAQ(msg_id)
	{
		msg_id.style.display=msg_id.style.display=='none' ? '' : 'none'
	}
</SCRIPT>";
$result = $apt->query("SELECT * FROM rafia_faqcategories ORDER BY cat_id ASC");
while($row = $apt->dbarray($result)){
	@extract($row);
	$category = $apt->format_data_out($category);
	$middle .= "<table border='0' width='95%' id='table4' cellspacing='1' cellpadding='0'>
	<tr><td class='forum_header'>&nbsp;$category</td></tr>";

	$result_q = $apt->query("SELECT * FROM rafia_faqs where cat_id=$cat_id ORDER BY faq_id ASC");
	while($rowq = $apt->dbarray($result_q)){
	@extract($rowq);
		$middle .= "<tr><td class='forum_alt1'><A href=\"javascript:show_hide_FAQ(f$faq_id)\">$question</a></td></tr>";
		$middle .= "<tr id='f$faq_id'><td class='forum_alt2'><font class='fontht'>$answer</font></td></tr><SCRIPT>show_hide_FAQ(f$faq_id)</SCRIPT>";
	}
	$middle .= "</table>";
}
echo $middle;
?>