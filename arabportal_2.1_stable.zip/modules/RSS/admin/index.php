<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|                                           |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 22/10/2006 Time: 10:00 PM  |
+===========================================+
*/
if (!eregi("mod.php", $PHP_SELF)) { die ("���� ��� ������� ��� ������"); }

$admin->head();
echo "<table border=0 width=80% cellspacing=2 cellpadding=6>
  <tr>
    <td disabled align=center class=datacell><a href=mod.php?act=edit&mod=RSS&modid=$modid&$session><b>������ ��������</b></a></td>
    <td align=center class=datacell><a href=mod.php?act=edit&mod=RSS&modid=$modid&op=add&$session><b>��� ���� ����</b></a></td>
  </tr>
</table>
<br>";

echo '
<table border=0 width=80% cellspacing=2 cellpadding=6><tr>
<td width=100% bgcolor=#3A789F colspan=4 align=center  background=images/td_back.gif>
<font color=#FFFFFF><b>����� ����� �������</b></td></tr>';

$result = mysql_query ("SELECT * FROM rafia_rss");
while ($row = mysql_fetch_array($result)) {
$r_id 	= $row['r_id']; 
$url  	= $row['url']; 
$sitename   = $row['sitename']; 
echo "
<tr>
<td class=datacell>&nbsp; <b>$sitename</b> </td>
<td class=datacell> <center><a target=_blank href=$url><img border=0 src=./../modules/RSS/images/xml.gif></center><a/> </td>
<td class=datacell> <b><center><a href=mod.php?act=edit&mod=RSS&modid=$modid&op=edit&$session&r_id=$r_id>�����</a></center></b> </td>
<td class=datacell> <b><center><a href=mod.php?act=edit&mod=RSS&modid=$modid&op=del&$session&r_id=$r_id>����</a></center></b> </td>
</tr>";

}
echo '</table>';

?>