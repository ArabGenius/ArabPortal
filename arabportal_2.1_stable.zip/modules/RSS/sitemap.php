<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|                                           |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 22/10/2006 Time: 10:00 PM  |
+===========================================+
*/
include('admin/conf.php');
$url = $apt->getsettings("siteURL");
$site= $apt->getsettings("sitetitle");
if(substr($url,-1) != '/'){
$url = $url . '/';
}

header("Content-Type: text/xml");
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
echo "<urlset xmlns=\"http://www.google.com/schemas/sitemap/0.84\">\n";

echo "<url>\n";
echo "<loc>$url</loc>\n";
echo "<priority>1.0</priority>\n";
echo "<changefreq>hourly</changefreq>\n";
echo "</url>\n";

echo "<url>\n";
echo "<loc>".$url."news.php</loc>\n";
echo "<priority>1.0</priority>\n";
echo "<changefreq>hourly</changefreq>\n";
echo "</url>\n";

echo "<url>\n";
echo "<loc>".$url."forum.php</loc>\n";
echo "<priority>1.0</priority>\n";
echo "<changefreq>hourly</changefreq>\n";
echo "</url>\n";

echo "<url>\n";
echo "<loc>".$url."download.php</loc>\n";
echo "<priority>1.0</priority>\n";
echo "<changefreq>hourly</changefreq>\n";
echo "</url>\n";

echo "<url>\n";
echo "<loc>".$url."link.php</loc>\n";
echo "<priority>1.0</priority>\n";
echo "<changefreq>hourly</changefreq>\n";
echo "</url>\n";


$resultm = mysql_query ("SELECT * FROM rafia_mods WHERE mod_sys!='0' ORDER BY mod_name ASC");
while ($row = mysql_fetch_array($resultm)) {
$mod_name = $row['mod_name']; 

echo "<url>\n";
echo "<loc>".$url."mod.php?mod=$mod_name</loc>\n";
echo "<priority>1.0</priority>\n";
echo "<changefreq>hourly</changefreq>\n";
echo "</url>\n";
}

$result = mysql_query ("SELECT * FROM rafia_news
                                 WHERE allow='yes'
                                 ORDER BY id ASC");
while ($row = mysql_fetch_array($result)) {
$id = $row['id']; 

echo "<url>\n";
echo "<loc>".$url."news.php?action=view&amp;id=$id</loc>\n";
echo "<priority>1.0</priority>\n";
echo "<changefreq>daily</changefreq>\n";
echo "</url>\n";

}

$results = mysql_query ("SELECT id FROM rafia_forum
                                 WHERE allow='yes'
                                 ORDER BY id ASC");

while ($row = mysql_fetch_array($results)) {
$id = $row['id']; 
echo "<url>\n";
echo "<loc>".$url."forum.php?action=view&amp;id=$id</loc>\n";
echo "<priority>1.0</priority>\n";
echo "<changefreq>weekly</changefreq>\n";
echo "</url>\n";

}

$results = mysql_query ("SELECT id FROM rafia_download
                                 WHERE allow='yes'
                                 ORDER BY id ASC");

while ($row = mysql_fetch_array($results)) {
$id = $row['id']; 
echo "<url>\n";
echo "<loc>".$url."download.php?action=view&amp;id=$id</loc>\n";
echo "<priority>1.0</priority>\n";
echo "<changefreq>weekly</changefreq>\n";
echo "</url>\n";

}

$results = mysql_query ("SELECT id FROM rafia_links
                                 WHERE allow='yes'
                                 ORDER BY id ASC");

while ($row = mysql_fetch_array($results)) {
$id = $row['id']; 
echo "<url>\n";
echo "<loc>".$url."link.php?action=goto&amp;id=$id</loc>\n";
echo "<priority>1.0</priority>\n";
echo "<changefreq>weekly</changefreq>\n";
echo "</url>\n";

}
echo "</urlset>";
exit();
?>