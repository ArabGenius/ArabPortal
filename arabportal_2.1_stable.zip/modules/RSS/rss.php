<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|                                           |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 22/10/2006 Time: 10:00 PM  |
+===========================================+
*/
include('admin/conf.php');
$url = $apt->getsettings("siteURL");
$site= $apt->getsettings("sitetitle");
$result = mysql_query ("SELECT * FROM rafia_news
                                 WHERE allow='yes'
                                 ORDER BY id DESC limit 10");
if(substr($url,-1) != '/'){
$url = $url . '/';
}

$time = date('Y.m.d (h:i a)');
include("modules/RSS/ConvertCharset.class.php");
$FromCharset = 'windows-1256'; 
$ToCharset = 'utf-8'; 
$convert  = new ConvertCharset(); 

header("Content-Type: text/xml");
echo "<?xml version=\"1.0\"?>\n";
echo "<rss version=\"2.0\">\n";
echo "<channel>\n";

$site = $convert->Convert($site, $FromCharset, $ToCharset); 
$desc = $convert->Convert("������� ���� ������� �������", $FromCharset, $ToCharset); 
echo "<title>$site</title>\n";
echo "<link>$url</link>\n";
echo "<description>$desc</description>\n";
echo "<date>$time</date>\n";

while ($row = mysql_fetch_array($result)) {
$id = $row['id']; 
$ntitle = $row['title']; 
$news_head = $row['news_head']; 
$ntitle = $convert->Convert($ntitle, $FromCharset, $ToCharset); 
$news_head = $convert->Convert($news_head, $FromCharset, $ToCharset); 

echo "<item>\n";
echo "<title>$ntitle</title>\n";
echo "<link>".$url."news.php?action=view&amp;id=$id</link>\n";
echo "<description>$news_head</description>\n";
echo "</item>\n\n";

}

echo "</channel>\n";
echo "</rss>";
exit();
?>