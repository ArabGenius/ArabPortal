<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 22/10/2006 Time: 10:00 PM  |
+===========================================+
*/

if (RUN_MODULE !== true)
{
    die ("<center><h3>���� ��� ������� ��� ������</h3></center>");
}

$mod_id = $mod->modInfo[id];
$mod_theme = $mod->modInfo[themeid];
$mod_name = $mod->modInfo[mod_name];
$mod_title = $mod->modInfo[mod_title];

$use_news      = $mod->getmodsettings('use_news',$mod_name);
$use_forum     = $mod->getmodsettings('use_forum',$mod_name); 
$use_download  = $mod->getmodsettings('use_download',$mod_name);
$use_link	   = $mod->getmodsettings('use_link',$mod_name);
$use_mods      = $mod->getmodsettings('use_mods',$mod_name);
$use_pages     = $mod->getmodsettings('use_pages',$mod_name);

echo $apt->table_cat_module("<a href=mod.php?mod=$mod_name>&nbsp;$mod_title</a>");


function site_map($title,$site_map_list)
{
return <<<EOF
 <div align="center">
  <center>
  <table border="0" width="100%">
    <tr>
      <td align='right' width="100%"><b>
<font class=normal><ul><li>{$title}
</font><DL>{$site_map_list}</DL></ul></td>
    </tr>
  </table>
  </center>
</div>
EOF;
}

function sublistmap($id,&$file)
{
    global $file,$apt;

    $result = $apt->query("SELECT * FROM rafia_cat WHERE subcat='$id' ORDER BY ordercat ASC");

    if($apt->dbnumrows($result)>0)
    {
         while($row=$apt->dbarray($result))
         {
              $mentitle = $row["title"];
              $menid    = $row["id"];
              $cat .= "<LI><dd><a href=$file.php?action=list&cat_id=$menid class=normal>$mentitle</a>";
         }
    }
    return $cat;
}

if($use_news == 1)
{

   $result = $apt->query("SELECT * FROM rafia_cat WHERE catType='1' and subcat ='$cat_id' ORDER BY ordercat ASC");   // Added by Myrosy

   $title ="<a href=news.php>��������� </a>";

   if ($apt->dbnumrows($result) > 0)
   {
       while($menu = $apt->dbarray($result))
       {
           $mentitle = $menu["title"];
           $menid    = $menu["id"];
           $file     = "news";
           $site_map_list .= "<li><DT><a href=$file.php?action=list&cat_id=$menid class=normal> $mentitle</a>";

           $site_map_list .= sublistmap($menid,$file);
       }
    }

   $arr[] = site_map($title,$site_map_list);
    unset($site_map_list);
}

if($use_forum == 1)
{
    global $file;
    $result = $apt->query("SELECT * FROM rafia_cat WHERE catType='2' and subcat ='$cat_id' ORDER BY ordercat ASC");  // Added by Myrosy

    $title ="<a href=forum.php> ��������� </a>";
   if ($apt->dbnumrows($result) > 0)
   {
       while($menu = $apt->dbarray($result))
       {
        $mentitle = $menu["title"];
        $menid    = $menu["id"];
        $file     = "forum";
        $site_map_list .= "<li><DT><a href=$file.php?action=list&cat_id=$menid class=normal>$mentitle</a>";
        $site_map_list .= sublistmap($menid,$file);
       }
    }
    $arr[] = site_map($title,$site_map_list);
    unset($site_map_list);
}

if($use_download == 1)
{
    $result = $apt->query("SELECT * FROM rafia_cat WHERE catType='3' and subcat ='$cat_id' ORDER BY ordercat ASC");  // Added by Myrosy

    $title ="<a href=download.php>����� ������� </a>";
   if ($apt->dbnumrows($result) > 0)
   {
    while($menu = $apt->dbarray($result))
    {
        $mentitle = $menu["title"];
        $menid    = $menu["id"];
        $file     = "download";
        $site_map_list .= "<li><DT><a href=$file.php?action=list&cat_id=$menid class=normal>$mentitle</a>";
        $site_map_list .= sublistmap($menid,$file);
    }
    }
    $arr[] = site_map($title,$site_map_list);
    unset($site_map_list);
}

if($use_link == 1)
{
            $result = $apt->query("SELECT * FROM rafia_cat WHERE catType='4' and subcat ='$cat_id' ORDER BY ordercat ASC");  // Added by Myrosy

    $title ="<a href=link.php> ���� �������</a>";
    if ($apt->dbnumrows($result) > 0)
   {
       while($menu = $apt->dbarray($result))
       {
        $mentitle = $menu["title"];
        $menid    = $menu["id"];
        $file     = "link";
        $site_map_list .= "<li><DT><a href=$file.php?action=list&cat_id=$menid class=normal>$mentitle</a>";
        $site_map_list .= sublistmap($menid,$file);
       }
    }
    $arr[] = site_map($title,$site_map_list);
    unset($site_map_list);
}

////////  set Output ////////

$index_middle  = "";

if($use_news+$use_forum+$use_download+$use_link != 0){
$index_middle .=  "<br><center><table border='0' width='100%' align='center' cellpadding='2'><tr class=normal><font color=\"#cc3300\">�  ����� ������ �������� </font>";

while (list(, $value) = each ($arr))
{

        $index_middle .=  "<td align='right' valign='top'>";
        $index_middle .= $value;
        $index_middle .=  "</td>";
        $count++;
        if ($count == 1)
        {
            $index_middle .=  "</tr>";
            $count = 0;
        }
}
$index_middle .=  "</tr></table>";
}



if($use_pages == 1){
$resultt =  $apt->query("SELECT * FROM rafia_pages where active='1' ORDER BY name ASC");

if ($apt->dbnumrows($resultt) > 0)
{
$index_middle .=  "<br><center><table border='0' width='100%' align='center' cellpadding='2'><tr class=normal><font color=\"#cc3300\">�  ����� ������  </font>";

    $index_middle .=  "<td align='right' valign='top'></td>";
    while ($tempp = $apt->dbarray($resultt))
    {
        extract($tempp);
        $index_middle .=  "&nbsp;&nbsp;&nbsp;&nbsp;  * <a href=index.php?action=pages&id=$id class=normal>$name</a><br>";
    }
    $index_middle .=  "</td></tr></table>";

}
}

if($use_mods == 1){
$resultt =  $apt->query("SELECT * FROM rafia_mods WHERE mod_sys!='0' ORDER BY mod_name ASC");

if ($apt->dbnumrows($resultt) > 0)
{
$index_middle .=  "<br><center><table border='0' width='100%' align='center' cellpadding='2'><tr class=normal><font color=\"#cc3300\">�  ������� �������� </font>";

    $index_middle .=  "<td align='right' valign='top'></td>";
    while ($tempp = $apt->dbarray($resultt))
    {
        extract($tempp);
        $index_middle .=  " &nbsp;&nbsp;&nbsp;&nbsp;  * <a href=mod.php?mod=$mod_name class=normal>$mod_title</a><br>";
    }
    $index_middle .=  "</td></tr></table>";

}
}


echo $index_middle;
?>