<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|                                           |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 22/10/2006 Time: 10:00 PM  |
+===========================================+
*/
if (!eregi("mod.php", $PHP_SELF)) { die ("���� ��� ������� ��� ������"); }

$admin->head();
echo "
<table border=0 width=80% cellspacing=2 cellpadding=6>
  <tr>
    <td align=center class=datacell><a href=mod.php?act=edit&mod=myfiles&modid=$modid&$session><b>������� �������</b></a></td>
    <td disabled align=center class=datacell><a href=mod.php?act=edit&mod=myfiles&modid=$modid&op=list&$session><b>����� ������� �������</b></a></td>
  </tr>
</table><br>";
echo '
<table border=0 width=80% cellspacing=2 cellpadding=6><tr>
<td width=100% bgcolor=#3A789F colspan=4 align=center  background=images/td_back.gif>
<font color=#FFFFFF><b>����� �������</b></td></tr>';

$user = array();
$result = $apt->query("SELECT * FROM rafia_users where userid != '-1' ORDER BY userid");
while($row=$apt->dbarray($result)){
@extract($row);
$user[$userid] = $username;
}

$handle = @opendir("./../modules/myfiles/files/");
while($file = @readdir($handle)){
if (($file != ".") && ($file != "..")){
         	$ext = @explode('_', $file);
		if (($ext[0] !== 'lastupload') and ($ext[0] !== 'index.php')){
         	$date = @explode('.', $ext[1]);
         	$uid = $ext[0];
		$unm = $user[$uid];
         	$name = $ext[1];
		$furl = "./../modules/myfiles/files/".$file;
		$fsize = @filesize("./../modules/myfiles/files/$file");
		if($fsize >= 1048576){
        	$fsize = round($fsize / 1048576 * 100) / 100 . " �������� ";
		}elseif($fsize >= 1024){
   	      $fsize = round($fsize / 1024 * 100) / 100 . " �������� ";
		}
		$date = $apt->Hijri($date[0]);
		echo "<tr><td class=datacell>&nbsp;<b>	<a target=_blank title='$fsize' href='$furl'>$file</a></b></td><td class=datacell><b><center>$unm</center></b></td>
		<td class=datacell><b><center>$date</center></b></td><td class=datacell><b><center>
			<a href='mod.php?act=edit&mod=myfiles&modid=$modid&op=del&$session&file=$file'>&nbsp; ���� &nbsp;</a></center></b></td>
		</tr>";
		unset($name,$fsize,$date,$unm,$uid);
     		}
}
}
@closedir($handle);

echo '</table>';

?>