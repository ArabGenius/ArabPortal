<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 01/01/2007 Time: 00:00 AM  |
+===========================================+
*/


if (RUN_MODULE !== true)
{
    die ("<center><h3>���� ��� ������� ��� ������</h3></center>");
}

$catid= $apt->setid('catid');
include("modules/media/config.php");
$index_middle = $apt->table_cat_module("<a href=mod.php?mod=$mod_name>&nbsp;$mod_title</a>");

$media_middle = '';
$result = $apt->query("SELECT * FROM rafia_media_cat where cat_main='0' and cat_sub='$catid'");
while(@extract($apt->dbarray($result))){
eval("\$media_middle .= \" " . $apt->getmodtemplate ( 'media_category', $modid,$mod_theme ) . "\";");
}

$uresult = $apt->query("SELECT userid,username FROM rafia_users");
while(@extract($apt->dbarray($uresult))){
$user[$userid] = $username;
}
if(($allow_user ==0) and ($member_gp != 1)){
$open_hide = "<!--";
$close_hide = " -->";
}
eval("\$media_middle .= \" " . $apt->getmodtemplate ( 'media_list_top', $modid,$mod_theme ) . "\";");
$result = $apt->query("SELECT * FROM rafia_media_items where item_allow=1 and item_cat='$catid' order by item_show DESC");
$media_items ='';
while(@extract($apt->dbarray($result))){
$item_user = $user[$item_uid];
$item_date = $apt->Hijri($item_date);
eval("\$media_middle .= \" " . $apt->getmodtemplate ( 'media_list_middle', $modid,$mod_theme ) . "\";");
}
eval("\$media_middle .= \" " . $apt->getmodtemplate ( 'media_list_botton', $modid,$mod_theme ) . "\";");

eval("\$index_middle .= \" " . $apt->getmodtemplate ( 'media_main', $modid,$mod_theme ) . "\";");
echo $index_middle;

?>