<?php
/*
+===========================================+
|      ArabPortal V2.2.x Copyright � 2009   |
|   -------------------------------------   |
|                     BY                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Info      |
|   -------------------------------------   |
|  Last Updated: 25/08/2008 Time: 03:35 AM  |
+===========================================+
*/

@header( "Refresh: 30;url=online.php" );

include('global.php');
unset($ads_head,$ads_foot);

$menu = new menu;
$menu->menuid       =  $apt->getsettings("index_menuid");

$left_menu          = $menu->_menu(2);
$right_menu         = $menu->_menu(1);
$middle_menu_count  =  $apt->getsettings("count_middle_menu");
$middle_menu = "<table border=0 cellpadding=0 cellspacing=0 width=100%><tr valign=top>";
$middle_menus = $menu->_menu(3);
$ex = @explode('<!-- BLOCK END -->',$middle_menus);
$m=0;
foreach($ex as $amenu){
$middle_menu .= '<td valign=top>'.$amenu.'</td>';
$m++;
if($m==$middle_menu_count)$middle_menu .= "</tr>";
}
$middle_menu .= "</tr></table><br>";

$apt->head("���������� �����");

$searchEngine = Array(		  "Google" => "google",
					  "DMOZ" => "dmoz\.org",
					  "Yahoo" => "yahoo",
					  "MSN" => "msn\.com",
					  "LookSmart" => "looksmart\.com",
					  "AlltheWeb" => "alltheweb\.com",
					  "Lycos" => "lycos\.com",
					  "Netscape" => "netscape\.com",
					  "HotBot" => "hotbot\.com",
					  "Altavista" => "altavista\.com",
					  "ArabyBot" => "araby\.com");


$result = $apt->query("SELECT DISTINCT onlineip,onlinepage,onlinefile,user_online,useronlineid FROM rafia_online  ORDER BY useronlineid DESC");

while($row = $apt->dbarray($result))
{
    $user_online   = $row[user_online];
    $useronlineid  = $row[useronlineid];
    $useragent   	 = $row[user_agent];
    $onlinefile    = $row[onlinefile];
    $onlinefile    = explode("/",$onlinefile);
    $onlinefile    = $onlinefile[count($onlinefile)-1];
    $onlinepage    = $row[onlinepage];
    $onlinepage    = explode("/",$onlinepage);
    $onlinepage    = $onlinepage[count($onlinepage)-1];

	foreach($searchEngine as $key => $value){
		if(preg_match("/".$value."/i", $useragent)){
			$user_online = '���� ��� '.$key;
		}
	}

    if ( $apt->cookie['cadmin'] >'0' ){
        $onlineip     = $row[onlineip];
    }else{
        $onlineip     = "---";
    }
    if($useronlineid == $apt->Guestid){$user_online = "����";}
    $apt->color($color);
    $index_middle .= " <center><table border=\"0\" width=\"90%\"><tr>
    <td width=\"7%\" bgcolor=\"$color\" align=\"center\">$userid </td>
    <td width=\"30%\" bgcolor=\"$color\"><font class=fontablt>  </font><font class=fontablt>$user_online</font></td>
    <td width=\"33%\" bgcolor=\"$color\"><font class=fontablt><a href=\"$onlinepage\">������ �� $onlinefile</a></font></td>
    <td width=\"40%\" bgcolor=\"$color\" align=\"center\"><font class=fontablt>$onlineip
    </font></td></tr></table></center>";
}

$apt->html_Output($left_menu);

?>
