<?php
/*
+===========================================+
|      ArabPortal V2.2.x Copyright � 2009   |
|   -------------------------------------   |
|                     BY                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Info      |
|   -------------------------------------   |
|  Last Updated: 25/09/2008 Time: 01:35 AM  |
+===========================================+
*/

include('global.php');
$apt->GroupAllow('view_site');
$cat_img = "newnews.gif";

$index_middle = '';
$form='';

//---------------------------------------------------

$menu = new menu;

unset($ads_head,$ads_foot);

//---------------------------------------------------

if($apt->get['action']==""){
//die($apt->cookie['cgroup'].$apt->s_g);
     if (( $apt->cookie['cgroup'] == $apt->a_g) || ( $apt->cookie['cgroup'] == $apt->s_g))
    {
        $apt->head(LANG_TITLE_MODERATE_POSTS);
        $index_middle = " <a href=comment.php?sec=news>����� ������� �������</a>   ||    <a href=comment.php?sec=forum>����� ������� �������</a>";
	  $field = 'news_id'; $cfile = "news";
	  if($apt->get['sec']=="forum"){$field = "thread_id"; $cfile = "forum"; }else{$field = "news_id"; $cfile = "news";}
        $menu->menuid =  "1,5";
        $right_menu = $menu->_menu(1);
        $result = $apt->query("SELECT * FROM rafia_comment WHERE allow !='yes' and $field !='0' ORDER BY id DESC");
        if($apt->dbnumrows($result)){
           $form = $apt->script->post_java();
           $form .= "<form method=\"POST\" action=\"$apt->self?action=dosec\" name='admin'>";
           $index_middle .= $form ;
           $index_middle .=  " <div align=center><table border=0 width=80%  cellspacing=0 cellpadding=0>
           <tr><td width=\"100%\" bgcolor=\"#34597D\" style=\"padding-top: 3; padding-bottom: 3\" class=\"normal_dark_link\">
           <span class=orang_b> �   </span>����� ���������</td></tr><tr><td width=100% bgcolor=FFFFFF><div align=center>
           <table border=1 cellpadding='3' cellspacing='0' style='border-collapse: collapse; border-width: 0' bordercolor='111111' width='100%' id='AutoNumber7'>";;
           while($apt->row = $apt->dbarray($result)){
           $apt->row["title"] = "<a name=\"comment$id\"></a>������ : ".$apt->row['name']." || <a href=$cfile.php?action=view&id=" . $apt->row["$field"] . "><b> ������� ������� </b></a><hr>".$apt->rafia_code($apt->row['comment']);
           $form='';
           $form .=  "<tr><td class=bgcolor1 width=50%><b> " . $apt->row["title"] . "</b></td>";
           $form .=  "<td width=10% class=bgcolor1 align=center valign=\"top\"><a href=comment.php?action=editcomment&id=" . $apt->row["id"] . "><b>�����</b></a></td>";
           $form .=  "<td width=10% class=bgcolor1 align=center valign=\"top\"><input type=checkbox name=\"do[]\" value=" . $apt->row["id"] . "></td> ";
           $index_middle .=  $form;
           }
           $index_middle .= $apt->admin_table_close();

           $form  ="<input type=\"button\" name=\"CheckAll\" value=\"����� ����\" onclick=\"checkAll(document.admin)\" >  " ;
           $form .="<input type=\"button\" name=\"UnCheckAll\" value=\"����� �������\" onclick=\"uncheckAll(document.admin)\" >  " ;
           $form .="<input type=\"submit\" name=\"del\"  value=\"������\" onClick=\"if (!confirm('�� ���� ����� �� ����ݿ')) return false;\">";
           $form .="&nbsp;&nbsp;<input type=\"submit\" name=\"allow\"  value=\"����� \"></form>";

           $index_middlea = $form;
           $index_middle .= $index_middlea;
       }else{$index_middle .= "<p>�� ���� ���� �������.</p>";}

       $apt->html_Output($left_menu);
       }
       else
       {
           $apt->head(LANG_TITLE_LOG_IN);
           eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");
       }

}
/*+===============  =================+ */
else if($apt->get['action']=="editcomment")
{
      $apt->GroupAllow('add_news_c') ;
      $id = $apt->setid('id');
      if(!$apt->CheckGroup('edit_comment_own') &&  !$apt->CheckGroup('edit_news') )
      {
          $apt->head(LANG_ERROR);
          $apt->errmsg(LANG_ERROR_CAN_NOT_EDIT);
      }
      $result     = $apt->query("select * from rafia_comment where id='$id'");
      $apt->row = $apt->dbarray($result);
      $apt->row['post_id'] = $apt->row['$field'];
      if ($apt->cookie['cid'] == $apt->row['userid'] ||  $apt->checkcadmincat($apt->row['cat_id']) )
      {
          $apt->head(LANG_TITLE_EDIT_POST);
             $fo = new form;
             $index_middle =$fo->comment_form('edit');
             $right_menu   =  $menu->_menu(1);
             
             $apt->html_Output("");
      }
      else
      {
          $apt->errmsg(LANG_ERROR_CAN_NOT_EDIT);
      }
}
/*+===============  =================+ */
else if($apt->get['action']=="UC")
{
      $id = $apt->setid('id');
      if(!$apt->CheckGroup('edit_comment_own') &&  !$apt->CheckGroup('edit_comment') )
      {
          $apt->errmsg(LANG_ERROR_CAN_NOT_EDIT);
      }
      @extract($_POST);
      if ($apt->post['del'] =='1')
      {
           $cat_id = $apt->post['cat_id'] ;
           $apt->delmsg($cat_id,'',$id);
      }
     if (!$apt->full($post))
     {
         $apt->errmsg(LANG_ERROR_VALIDATE);
     }
     if (!$apt->txtcounmxs($post,$apt->getsettings('txtcount6')))
     {
         $apt->errmsg(LANG_ERROR_LETTER_MAX);
     }
       //////////////////////////////////////////////
   if ($apt->post['editupload'] == "delete" )
    {
        $row = $apt->dbfetch("SELECT * FROM rafia_upload WHERE upid='$uploadfile'");
        @extract($row);
        $filename = $apt->upload_path."/".$uppostid.".".$upcat;
        if(@unlink($filename))
        {
            $apt->query("DELETE FROM rafia_upload WHERE upid='$uploadfile'");
            $apt->query("update rafia_comment set
                                          uploadfile = '0'
                                          where id = '$id'");
        }
    }
     //////////////////////////////////////////////
    if($apt->post['editupload'] == 'new' )
    {
        if ($apt->CheckGroup('upload_forum_file'))
        {
            if (is_uploaded_file($apt->files["phpfile"]['tmp_name']))
            {
                $up  = new RaFiaUpload;
                $up->cat = "comment";
                $up->uploads = $apt->files["phpfile"];
                if ($up->uploads["size"] > ($apt->getsettings("commentfilemxsize")*1024))
                {
                  $apt->errmsg(LANG_ERROR_SIZE_MUST_LESS.$apt->getsettings("commentfilemxsize")." kb");
                }
                if ($up->checkend( $apt->getsettings("commentfileupload")) == false)
                {
                    $apt->errmsg("��� ����� �� ������� �� ����  ����� ������� <br>");
                }
                $up->uploadfile(1);
            }
        }
    }
    ////////////////
      $title   =  $apt->format_data($title);
      $comment =  $apt->format_post($post);
    if ($apt->checkcadmincat($apt->post['cat_id']) )
    {
        $result = $apt->query("update rafia_comment set
                                        title = '$title',
                                        allow = '$allow',
                                        comment = '$comment'
                                        where id = '$id'");
    }
    else
    {
        $result = $apt->query("update rafia_comment set
                                        comment = '$comment',
                                        allow = '$allow'
                                        where id = '$id'");
    }

// ahmed
if($allow == 'yes'){
	$apt->query ("UPDATE rafia_cat SET countcomm=countcomm+1 WHERE id='$cat_id'");
      $apt->query ("UPDATE rafia_news SET c_comment = c_comment+1 WHERE id = '$id'");
}


    $url = "$commentpage#comment$id";
    if ($result)
    {
        $apt->bodymsg(LANG_MSG_YOUR_POST_HAS_EDITED,$url);
    }
    else
    {
        $apt->bodymsg(LANG_ERROR_ADD_DB,$url);
    }
}
//---------------------------------------------------

else if($apt->get['action']=="dosec")
{
$do =  $apt->post['do'];
if(count($do) == 0)$apt->bodymsg("�� ��� ����� �� ��",$apt->refe);
if($apt->post['allow']){
        if (count($do) > 0)
        {
                 foreach($apt->post['do'] as $id)
                 {
                    $result = $apt->query("update rafia_comment set allow='yes' where id='$id'");
                }

       $apt->bodymsg("�� ����� ������",$apt->refe);
       }
}elseif($apt->post['del']){
        $do =  $apt->post['do'];
        if (count($do) > 0)
        {
                 foreach($apt->post['do'] as $id)
                 {
                    $result = $apt->query("delete from rafia_comment where id='$id'");
                }

       $apt->bodymsg("�� ��� ������",$apt->refe);
       }
}

}


if(isset($fo))
{
    print $apt->script->post_java();
}
$apt->foot($pageft);
?>