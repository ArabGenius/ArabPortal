<?php
/*
+===========================================+
|      ArabPortal V2.2.x Copyright � 2009   |
|   -------------------------------------   |
|                     BY                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Info      |
|   -------------------------------------   |
|  Last Updated: 25/08/2008 Time: 03:35 AM  |
+===========================================+
*/
	  @set_time_limit(300);
        @ini_set("memory_limit","256M");
        if (@phpversion() >= '5.0.0')
        require_once('func/pdf/tcpdf5.php');
        else
        require_once('func/pdf/tcpdf4.php');

        @ini_set('zend.ze1_compatibility_mode', '1');

        include('func/archarsetc.class.php');
        $utf = new ArCharsetC();
        $pdf = new TCPDF('P', 'mm', 'A4', true);

        require_once('admin/conf.php');
        require_once('func/info.php');
        require_once('func/mysql.php');
        $mysql = new mysql();
        include('func/pdf/function.php');
        $id = intval($_GET['id']);
        $row = $mysql->dbfetch("SELECT name,title,news_head,post FROM rafia_news WHERE id='$id' and allow='yes' LIMIT 1");

        if(empty($row))die('<br><br><br><br><center><h3>���� .. ���� ��� ����� �� �������</h3></center>');

        @extract($row);

	  $filename = "doc_".$id;
        $pdf->SetCreator('ArabPortal 2.2');
        $pdf->SetAuthor($utf->win2utf($name));
        $pdf->SetTitle($utf->win2utf($title));
        $pdf->SetSubject($utf->win2utf($CONF['site_title']));
        $pdf->SetKeywords($utf->win2utf("������� ������� 2.2 - $title"));
        $pdf->SetHeaderData("", "", $utf->win2utf($CONF['site_title']), $utf->win2utf($title . " ������ : ". $name));
        $pdf->setHeaderFont(Array('almohanad', '', 10));
        $pdf->setFooterFont(Array('almohanad', '', 12));
        $pdf->SetMargins(15, 17, 15);
        $pdf->SetHeaderMargin(5);
        $pdf->SetFooterMargin(10);
        $pdf->SetAutoPageBreak(TRUE, 25);
        $pdf->setImageScale(4);
        $lg = Array();
        $lg['a_meta_charset'] = "UTF-8";
        $lg['a_meta_dir'] = "rtl";
        $lg['a_meta_language'] = "ar";
        $lg['w_page'] = $utf->win2utf("����");
        $pdf->setLanguageArray($lg);
        $pdf->AliasNbPages();
        $pdf->AddPage();

	  ////////--------- PHOTO ----------
	  if(file_exists("upload"."/".$id.".news")){
	  $pic =  "upload"."/".$id.".news";

	  $op = fopen("upload"."/".$id.".jpg",'w');

	  if($op){
	  $fr = fread( fopen($pic,'r'), @filesize($pic));
	  @fwrite($op,$fr);
	  @fclose($op);
	  $mime = @getimagesize("upload"."/".$id.".jpg");
	  $type = $mime[mime];

	  if($type = "image/gif"){
	  $image = @ImageCreateFromGIF("upload"."/".$id.".jpg");
	  }elseif($type = "image/jpeg"){
	  $image = @ImageCreateFromJPEG("upload"."/".$id.".jpg");
	  }elseif($type = "image/png"){
	  $image = @ImageCreateFromPNG("upload"."/".$id.".jpg");
	  }else{
	  $image = @ImageCreateFromJPEG("upload"."/".$id.".jpg");
	  }

	  $width = @imagesx($image) ;
	  $height = @imagesy($image) ;

	  if (function_exists('ImagecreateTrueColor')){
	  $thumb = @ImageCreateTrueColor($width,$height);
	  @ImageCopyResampled($thumb,$image,0,0,0,0,$width,$height,$width,$height);
	  }else{
	  $thumb = @ImageCreate($width,$height);
	  @ImageCopyResized($thumb,$image,0,0,0,0,$width,$height,$width,$height);
	  }

	  @ImageJPEG($thumb, "upload"."/".$id.".jpg");
	  @imagedestroy($image);

	  $new_pic = "upload"."/".$id.".jpg";
	  }
	  }

	  if($ues_editor == 0){
	  $topic = rafia_code($news_head."\n".$post);
	  $topic = rep_smile($topic);
	  $topic = str_replace("</ br>","\n",$topic);
	  $topic = str_replace("<br />","\n",$topic);
	  $topic = str_replace("< br>","\n",$topic);
	  }else{
	  $topic = rep_smile($news_head."\n".$post);
 	  $topic = $news_head .'<br>'. $post;
	  }

	  $topic = str_replace("�","",$topic);
	  $topic = str_replace("�","",$topic);
	  $topic = str_replace("�","",$topic);
	  $topic = str_replace("�","",$topic);
	  $topic = str_replace(")"," ) ",$topic);
	  $topic = str_replace("("," ( ",$topic);
	  $explde = explode("\n",$topic);

        $pdf->SetFont("almohanad", "", 10);
        if($new_pic){
	  $pdf->WriteHTML('<span align=center><img src='.$new_pic.'></span>').$pdf->Ln();
	  foreach($explde as $x){$pdf->WriteHTML($utf->win2utf($x));}
        }else{foreach($explde as $x){$pdf->WriteHTML($utf->win2utf($x));}}
        $pdf->Ln(5);
        $pdf->SetFont("almohanad", "", 16);
        $pdf->Cell(0,10,$utf->win2utf("����� ������ ������� �� �������"),0,1,'C',0,$CONF['site_url'].'/news.php?action=view&id='.$id);
        @unlink($new_pic);
        $pdf->Output($filename.".pdf", "D");

?>