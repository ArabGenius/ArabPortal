<?php
/*
+===========================================+
|      ArabPortal V2.2.x Copyright � 2009   |
|   -------------------------------------   |
|                     BY                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Info      |
|   -------------------------------------   |
|  Last Updated: 25/08/2008 Time: 03:35 AM  |
+===========================================+
*/

require_once('global.php');
$apt->GroupAllow('view_site');
$apt->GroupAllow('use_search');
unset($ads_foot);

//---------------------------------------------------
// menu
//---------------------------------------------------

$menu = new menu;
$menu->menuid       =  $apt->getsettings("index_menuid");
$right_menu          = $menu->_menu(1);

//---------------------------------------------------


if(isset($apt->post['searchfor']))
{
    if (!$apt->full($apt->post['searchin']))
    {
        $apt->errmsg(LANG_ERROR_SCOPE_SEARCH);
    }
    if (!$apt->full($apt->post['searchfor']))
    {
        $apt->errmsg(LANG_ERROR_VALID_SEARCH);
    }
    if(($apt->post['searchfor'] == '*') or ($apt->post['membername'] == '*'))
    {
        $apt->errmsg(LANG_ERROR_VALID_SEARCH);
    }
// ADDED BY KHR2003
    if ($apt->post['catsearch'] == 'on'){
	if (!$apt->full($apt->post['choosecat'])){
        $apt->errmsg("�� ��� ������� �����");
	}
    }
// END ADD

    $searchin   = $apt->format_data($apt->post['searchin']);
    $searchfor  = $apt->format_data($apt->post['searchfor']);
    $membername = $apt->format_data($apt->post['membername']);
    $catsearch = $apt->format_data($apt->post['catsearch']);
    $choosecat = $apt->format_data($apt->post['choosecat']);

    $spell      = (int) $apt->post['spell'];
    $orderby_array = array('timestamp','c_comment','reader','name');
    $order_array = array('DESC','ASC');
    $searchfor  = str_replace("]","",$searchfor);
    $searchfor  = str_replace("[","",$searchfor);

    $membername  = str_replace("]","",$membername);
    $membername  = str_replace("[","",$membername);

    if (! @in_array($orderby_array,$apt->post['search_orderby'])){
        $search_orderby = $apt->post['search_orderby'];
    }else{
        $search_orderby = 'timestamp';
    }

    if (! @in_array($order_array,$apt->post['search_order'])){
        $search_order = $apt->post['search_order'];
    }else{
        $search_order = 'DESC';
    }

    if(! $search_orderby)$search_orderby = 'timestamp';
    if(! $search_order)$search_order = 'DESC';

     switch($searchin)
     {
         case "rafia_news":
         $fields = array('title','news_head','post');
         break;
         case "rafia_pages":         //  Added By Myrosy
         $fields = array('name','pagetext');
         break;         // End Myrosy
         case "rafia_links":
         $fields = array('title','post');
         break;
         case "rafia_download":
         $fields = array('title','post_head','post');
         break;
         default:
         $fields = array('title','post');
     }

    $search = new search($searchin,$fields);
    $search->spell = intval($spell);
    $id = $search->do_search($searchfor);
   
    if($id > 0)
    {
        $url  = "search.php?action=result&id=".$id."&spell=".$search->spell;
        $apt->bodymsg(LANG_MSG_SEARCHING_PLEASE_WAIT,$url);
    }
    else
    {   
        $index_middle .= LANG_MSG_SEARCHING_NO_MATCHES;
        $apt->head(LANG_TITLE_SEARCH_RESULTS);
        $apt->html_Output($left_menu);
        $apt->foot($pageft);
    }
}

if (($apt->get['action']=="search") or ($apt->get['action']==""))

{

    $apt->head(LANG_TITLE_SEARCH_RESULTS);
	  
	 $search = new search;
	 $catnews = $search->catlist(1,newop,cat);
	 $catforum = $search->catlist(2,forumop,cat);
	 $catdownload = $search->catlist(3,downloadop,cat);
	 $catlinks = $search->catlist(4,linksop,cat);
    eval("\$index_middle = \" " . $apt->gettemplate ( 'search_form' ) . "\";");

    $apt->html_Output($left_menu);

    $apt->foot($pageft);

}

elseif ($apt->get['action']=="result")

{
     $search = new search();
     $array  = array('title' => "�������",
                     'name'  => "������",
                     'c_comment' => "��� ������",
			   'reader' => "��������",
                     'timestamp' => "����� �������"
                     );

     $search->result_search($array);
     switch($search->db_table)
     {
         case "rafia_news":
         $search->fileName   = "news.php?action=view&";
         break;
         case "rafia_pages":         // Added By Myrosy
         $search->fileName   = "index.php?action=pages&";
         break;         // Myrosy End
         case "rafia_links":
         $search->fileName   = "link.php?action=goto&";
         break;
         case "rafia_download":
         $search->fileName   = "download.php?action=view&";
         break;
         default:
         $search->fileName   = "forum.php?action=view&";
     }
        $apt->head(LANG_TITLE_SEARCH_RESULTS);
        $apt->numrows  = $search->result_id;
        $perpage   = $search->search_max;
        $index_middle .= $search->result_outPut('title','timestamp');
        $index_middle .= $apt->pagenum($perpage,"result&id=".$apt->setid('id')."");
        $apt->html_Output($left_menu);
        $apt->foot($pageft);
}
?>