<?php
/*
+===========================================+
|      ArabPortal V2.2.x Copyright � 2009   |
|   -------------------------------------   |
|                     BY                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Info      |
|   -------------------------------------   |
|  Last Updated: 21/08/2008 Time: 04:45 AM  |
+===========================================+
*/


require_once("func/protection.php");
require_once('html/JavaScript.php');
require_once('admin/conf.php');
require_once("func/info.php");
require_once('func/mysql.php');
require_once('func/functions.php');
require_once('func/counter.php');
require_once('func/Files.php');

$apt = new func();
$Counter = new Counter();

$apt->arrSetting  = $apt->settings();
$apt->start_loginfo();
$apt->LoadGroupPerm($apt->cookie['cgroup']);

$maxlifetime             = $apt->conf['maxlifetime'] ?  $apt->conf['maxlifetime'] : get_cfg_var("session.gc_maxlifetime");

$apt->upload_path        = $apt->conf['upload_path'];

if ($apt->get['action']=="image")
{
        if (! $apt->checkgroup('view_news_img')){
		$pathfile = "images/errorIcon.png";
            header ("Content-type: images/png");
            echo Files::read($pathfile);
	  }else{
    	  $id = intval($_GET[id]);
        $result = $apt->query("SELECT * FROM rafia_upload WHERE upid='$id'");
        if($apt->dbnumrows($result)>0)
        {
            $rowfile = $apt->dbarray($result);
            @extract($rowfile);
		if(($_GET[thumb] =="y") and ($upcat=='news')){
            if(file_exists($apt->upload_path."/".$uppostid.".newsthumb")){
            $pathfile = $apt->upload_path."/".$uppostid.".newsthumb";}else{
            $pathfile = $apt->upload_path."/".$uppostid.".".$upcat;}
		}else{
            $pathfile = $apt->upload_path."/".$uppostid.".".$upcat;
		}
            header ("Content-type: $uptypes");
            echo Files::read($pathfile);
            $apt->query("UPDATE rafia_upload SET upclicks = upclicks+1 WHERE upid = '$id'");
        }
        }
}elseif ($apt->get['action']=="avatar")
{
     $userid = $apt->setid('userid');
     $avatarfile = $apt->upload_path."/".$userid.".".'avatar';
     if(file_exists($avatarfile)){
     $filesize = @filesize($avatarfile);
     header("Content-type: image/gif");
     header("Content-disposition: inline; filename=".$userid.".gif");
     header("Content-Length: $filesize");
     header("Pragma: no-cache");
     header("Expires: 0");
     echo Files::read($avatarfile);
     }
}elseif ($apt->get['action']=="save")
{

require_once('func/save.php');
$arch = new archive('news');
$id  = $apt->setid('id');
@header( "Content-Type: application/x-ms-download");
@header("Content-disposition: attachment; filename=news".$id.".html");
@header("Pragma: no-cache");
@header("Expires: 0");
$arch->loud_view(1);
}
?>