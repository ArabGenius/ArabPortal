<?php
/*
+===========================================+
|      ArabPortal V2.2.x Copyright � 2009   |
|   -------------------------------------   |
|                     BY                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Info      |
|   -------------------------------------   |
|  Last Updated: 28/09/2008 Time: 03:17 AM  |
+===========================================+
*/

include('global.php');
$apt->GroupAllow('view_site');
$cat_img = "newnews.gif";

$order_dir = $apt->format_data($apt->get[order_dir]);
$order_by = $apt->format_data($apt->get[order_by]);

if (empty($order_by)){
        $order_by = "date_time";
}
if (empty($order_dir)){
    $order_dir = DESC;
}

$order_by_array = array('id','date_time','userid','reader','c_comment','timestamp');
$order_dir_array = array('DESC','ASC');

$allow_dir = in_array($order_dir,$order_dir_array);
if(!$allow_dir){
$apt->errmsg("���� ... ��� ������� ��� ������");
}
$allow_by = in_array($order_by,$order_by_array);
if(!$allow_by){
$apt->errmsg("���� ... ��� ������� ��� ������");
}

$month = intval($_POST['month']);
$year = intval($_POST['year']);


function  getImageCat ()
{
    global $apt;
   $result = $apt->query("SELECT upid,uppostid,imagealign FROM rafia_upload WHERE upcat='catid'");

   if($apt->dbnumrows($result)>0)
   {
       $rowfile = $apt->dbarray($result);

       @extract($rowfile);

       $file_name = $apt->upload_path."/$uppostid.catid";

       if (file_exists($file_name))
       {
           if($imagealign =="")
           $imagealign = $apt->getsettings("CatMagealign");
           $image[$uppostid] = "<img src=\"news.php?action=image&id=".$upid."\"  align=\"".$imagealign."\">";
           return $image;
       }
   }

}


function years($selected=''){
$yearslist = "<select size='1' name='year'>";
for ( $y=2003; $y <2016; $y++ ){
if($selected == $y) $yearslist .= "<option selected value='$y'>$y</option>";
else $yearslist .= "<option value='$y'>$y</option>";
}
$yearslist .= "</select>";
return $yearslist;
}


function months($selected=''){
$monthslist = "<select size='1' name='month'>";
for ( $m=1; $m <13; $m++ ){
if($selected == $m) $monthslist .= "<option selected value='$m'>$m</option>";
else $monthslist .= "<option value='$m'>$m</option>";
}
$monthslist .= "</select>";
return $monthslist;
}

$menu = new menu;

if($apt->getsettings('use_adsin_news') == 'no'){
unset($ads_head,$ads_foot);
}

if ($apt->get['action']=="" || $apt->get['action']=="list" )
{
if(! $_POST['year']) $y = date(Y); else $y = date($_POST['year']);
if(! $_POST['month']) $m = date(m); else $m = date($_POST['month']);

    $apt->head(LANG_TITLE_NEWS."->".'����� ��������');
    $index_middle = '<br><center>'."<form method='POST' action='archive.php'>
	������ �������� �� ��� ".months($m)." �� ��� ".years($y)." <input type='submit' value='������ ����' name='submit'>
</form>";
    $perpagelist       = $apt->getsettings("newsperpagelist");

    $perpage_comment   = $apt->getsettings("newsperpagecomment");

if(! $_POST['year']){
$year = date(Y);
$month = date(m);
$nmonth = $month + 1;
$lastarchive = strtotime("$year/$month/01");
$nextarchive = strtotime("$year/$nmonth/01");
}else{
$nmonth = $month + 1;
$lastarchive = strtotime("$year/$month/01");
$nextarchive = strtotime("$year/$nmonth/01");
}

    $getImageCat = getImageCat();


    $result = $apt->query ("SELECT * FROM rafia_news
                                WHERE allow = 'yes'
                                AND date_time > '".$lastarchive ."' and date_time < '".$nextarchive ."'
                                ORDER BY $order_by $order_dir
                                LIMIT $start,$perpagelist");

    while($row = $apt->dbarray($result))

    {

        @extract($row);
        $numrows = $c_comment;

        $title         =  $apt->format_data_out($title);

        $name          =  $apt->format_data_out($name);

        $apt->numrows  =  $numrows ;

        $pagenum       =  $apt->pagenumlist ($perpage_comment,$id,"news.php");

        $title         =  $apt->title_cut($title,$apt->getsettings("max_title_cut"));

        $date          =  $timestamp;//date("d - m - Y",$timestamp); //
        $date          =  $apt->Hijri($date_time)." ".$apt->gettime($date_time);

        if($catmig == 0)

        {
                if($apt->getsettings("use_gd_thumb") == 'yes'){$usegd=true;}else{$usegd=false;}
                $newsimage = $apt->getnewsimage($id,$uploadfile,$usegd);
        }
        else
        {
           $newsimage  = $getImageCat[$cat_id];
        }

		if($apt->getsettings('html_links')=='yes'){
		$news_link = "news_view_".$id.".html";
    		}else{
    		$news_link = "news.php?action=view&id=".$id;
    		}

        eval("\$index_middle .= \" " . $apt->gettemplate ( 'news_topic_list' ) . "\";");

    }

    $apt->numrows = $apt->dbnumquery("rafia_news","allow='yes'  AND date_time > '".$lastarchive ."' and date_time < '".$nextarchive ."'");
    $archiveCount = intval($apt->get[archiveCount]);
    $pagenum        = $apt->pagenum($perpagelist,"list&archiveCount=$archiveCount");

    if($pagenum)
    {
        eval("\$index_middle .= \" " . $apt->gettemplate ( 'news_list_pagenum' ) . "\";");
    }

    $menu->menuid =  $apt->getsettings("news_menuid");

    $right_menu   =  $menu->_menu(1);

    if($apt->getsettings("news_left_menu"))

    $left_menu    =  $menu->_menu(2);

    $apt->html_Output($left_menu);

}
$apt->foot($pageft);
?>