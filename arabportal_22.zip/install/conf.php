<?php
/*
+===========================================+
|      ArabPortal V2.2.x Copyright � 2008   |
|   -------------------------------------   |
|                     BY                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Info      |
|   -------------------------------------   |
|  Last Updated: 08/08/2008 Time: 06:00 AM  |
+===========================================+
*/

// #############  Host Paths #############
$CONF['site_path']       = '{path}';
$CONF['upload_path']     = '{uppath}';
$CONF['site_url']        = '{sitelink}';
$CONF['date_format']     = "d-m-Y"; //hj|ar|en:

// ############ Parked Domains ###########
$CONF['parked_domain'][] = "";
$CONF['parked_domain'][] = "";

// #############  APT Settings ############
$CONF['site_mail']       = "{sitemail}";
$CONF['site_title']      = "{sitetitle}";
$CONF['maxlifetime']     = 1440;
$CONF['online_lifetime'] = 300;
$CONF['cookie_path']     = '/';
$CONF['cookie_domain']   = '{domain}';
$CONF['cookie_expires']  = 604800;
$CONF['cookie_info']     = '{cookie}';
$CONF['html_msg']        = 1;
$CONF['admin_group']     = 1;
$CONF['super_group']  	 = 2;
$CONF['moderate_group']  = 3;
$CONF['Guest_id']        = {guest};
$CONF['spam_timeOut']    = 30;  // sec
$CONF['search_timeOut']  = 1;  // days
// ################# Mail ###############
$CONF['Mailer']         = 'mail'; // mail , smtp , sendmail
$CONF['sendmail_path']  = '/usr/sbin/sendmail'; // if  use sendmail as Mailer
$CONF['smtp_Host']      = 'localhost'; // if  use smtp as Mailer
$CONF['smtp_Port']      = 25; // if  use smtp as Mailer
$CONF['smtp_Username']  = ''; // if  use smtp as Mailer
$CONF['smtp_Password']  = ''; // if  use smtp as Mailer

// ################ Admin #################
$CONF['class_folder']    = 'aclass';
$CONF['use_cookies']     = {use_cookies};
$CONF['isupgrade']       = 0;
$CONF['Theme_From_File'] = {Theme_From_File};
$CONF['gzip_compress']   = 0;
// ########## Database Informations ##########
// 0 = ����� �����
// 1 = ����� ����
$CONF['dbconntype']      = 0;
$CONF['dbserver']        = "{server_name}";
$CONF['dbname']          = "{server_db}";
$CONF['dbuser']          = "{server_un}";
$CONF['dbpword']         = "{server_pass}";
// ###########################################

?>