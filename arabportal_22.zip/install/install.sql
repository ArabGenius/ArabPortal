SET NAMES latin1;
#------------------- TABLE rafia_admin_menu -------------------
DROP TABLE IF EXISTS rafia_admin_menu; 

CREATE TABLE `rafia_admin_menu` (
  `menuid` int(10) NOT NULL auto_increment,
  `submenu` int(1) NOT NULL default '0',
  `orderby` int(10) NOT NULL default '0',
  `menutitle` varchar(100) default NULL,
  `menuurl` varchar(100) default NULL,
  PRIMARY KEY  (`menuid`)
) ;

INSERT INTO rafia_admin_menu VALUES (1,'',1,'_SETTINGS','');
INSERT INTO rafia_admin_menu VALUES (2,1,'','_MAIN_SETTINGS','index.php?action=settings');
INSERT INTO rafia_admin_menu VALUES (3,1,8,'_BACKUP','index.php?cat=backup');
INSERT INTO rafia_admin_menu VALUES (4,'',2,'_MENU','');
INSERT INTO rafia_admin_menu VALUES (5,4,1,'_MENU_LIST','index.php?cat=menu');
INSERT INTO rafia_admin_menu VALUES (6,4,2,'_ADD_NEW_MENU','index.php?cat=menu&act=add');
INSERT INTO rafia_admin_menu VALUES (7,'',3,'_POLLS_LIST','');
INSERT INTO rafia_admin_menu VALUES (8,7,3,'_POLLS','index.php?cat=poll');
INSERT INTO rafia_admin_menu VALUES (9,7,4,'_ADD_POLL','index.php?cat=poll&act=add');
INSERT INTO rafia_admin_menu VALUES (10,'',4,'_GROUP_MANG','');
INSERT INTO rafia_admin_menu VALUES (11,10,6,'_EDIT_GROUP','index.php?cat=groups&act=groups');
INSERT INTO rafia_admin_menu VALUES (12,10,7,'_ADD_GROUP','index.php?cat=groups&act=add');
INSERT INTO rafia_admin_menu VALUES (13,'',5,'_MEMEBRS_MANGAER','');
INSERT INTO rafia_admin_menu VALUES (14,13,'','_SEARCH','index.php?cat=users&act=search');
INSERT INTO rafia_admin_menu VALUES (15,13,1,'_MEMEBRS_REGISTE','index.php?cat=users');
INSERT INTO rafia_admin_menu VALUES (16,13,2,'_ADD_MEMEBER','index.php?cat=users&act=addusers');
INSERT INTO rafia_admin_menu VALUES (17,13,3,'_MAILING_MEMBERS','index.php?cat=users&act=emailusers');
INSERT INTO rafia_admin_menu VALUES (18,13,4,'_MEMBERS_WAITING','index.php?cat=users&act=userswait');
INSERT INTO rafia_admin_menu VALUES (19,13,5,'_MEMBERS_TITLES','index.php?cat=users&act=usertitles');
INSERT INTO rafia_admin_menu VALUES (20,13,6,'_CON_AVATARS','index.php?cat=users&act=avatars');
INSERT INTO rafia_admin_menu VALUES (21,'',6,'_MAILLIST_MANAGER','');
INSERT INTO rafia_admin_menu VALUES (22,21,'','_MAILLIST_MANAGER','index.php?cat=maillest&act=admin');
INSERT INTO rafia_admin_menu VALUES (23,21,1,'_MAILLIST_LIST','index.php?cat=maillest&act=list');
INSERT INTO rafia_admin_menu VALUES (24,21,2,'_SENDING_MAILLIST','index.php?cat=maillest&act=emails');
INSERT INTO rafia_admin_menu VALUES (25,'',7,'_ADS_MANAGER','');
INSERT INTO rafia_admin_menu VALUES (26,25,'','_ADD_ADS','index.php?cat=ads&act=add');
INSERT INTO rafia_admin_menu VALUES (27,25,1,'_EDIT_DELETE','index.php?cat=ads&act=list');
INSERT INTO rafia_admin_menu VALUES (28,25,2,'_ADS_REPORT','index.php?cat=ads&act=veiw');
INSERT INTO rafia_admin_menu VALUES (29,'',8,'_SMILES_MANAGER','');
INSERT INTO rafia_admin_menu VALUES (30,29,1,'_ADD_SMILES','index.php?cat=smiles&act=add');
INSERT INTO rafia_admin_menu VALUES (31,29,2,'_EDIT_DELETE','index.php?cat=smiles&act=list');
INSERT INTO rafia_admin_menu VALUES (32,'',9,'_THEME','');
INSERT INTO rafia_admin_menu VALUES (33,32,'','_EDIT_THEME','index.php?cat=template&act=design');
INSERT INTO rafia_admin_menu VALUES (34,32,1,'_ADD_THEME','index.php?cat=template&act=adddesign');
INSERT INTO rafia_admin_menu VALUES (35,32,2,'_SHOW_TEMPLATES','index.php?cat=template&act=temp');
INSERT INTO rafia_admin_menu VALUES (36,32,3,'_ADD_TEMPLATE','index.php?cat=template&act=add');
INSERT INTO rafia_admin_menu VALUES (37,32,4,'_COPY_UPLOAD_TEMPLATE','index.php?cat=template&act=copy');
INSERT INTO rafia_admin_menu VALUES (38,'',10,'_NEW_PAGES','');
INSERT INTO rafia_admin_menu VALUES (39,38,'','_EDIT_AND_DELETE','index.php?cat=pages&act=pages');
INSERT INTO rafia_admin_menu VALUES (40,38,1,'_ADD_NEW_PAGE','index.php?cat=pages&act=addpage');
INSERT INTO rafia_admin_menu VALUES (41,'',11,'_NEWS_CONTROL','');
INSERT INTO rafia_admin_menu VALUES (42,41,'','_NEWS_SETTINGS','index.php?cat=news');
INSERT INTO rafia_admin_menu VALUES (43,41,1,'_CATS_LIST','index.php?cat=news&act=cat');
INSERT INTO rafia_admin_menu VALUES (44,41,2,'_ADD_CAT','index.php?cat=news&act=addcat');
INSERT INTO rafia_admin_menu VALUES (45,41,3,'_MOD_LIST','index.php?cat=news&act=mod');
INSERT INTO rafia_admin_menu VALUES (46,41,4,'_ADD_MOD','index.php?cat=news&act=addmod');
INSERT INTO rafia_admin_menu VALUES (47,41,5,'_AVAILABLE_MENUS','index.php?cat=news&act=newsmenu');
INSERT INTO rafia_admin_menu VALUES (48,'',11,'_FORUM_PRO','');
INSERT INTO rafia_admin_menu VALUES (49,48,'','_FORUM_SETTINGS','index.php?cat=forum');
INSERT INTO rafia_admin_menu VALUES (50,48,1,'_CATS_LIST','index.php?cat=forum&act=cat');
INSERT INTO rafia_admin_menu VALUES (51,48,2,'_ADD_MAIN_CAT','index.php?cat=forum&act=addmine');
INSERT INTO rafia_admin_menu VALUES (52,48,3,'_ADD_SUB_CAT','index.php?cat=forum&act=addcat');
INSERT INTO rafia_admin_menu VALUES (53,48,4,'_MOD_LIST','index.php?cat=forum&act=mod');
INSERT INTO rafia_admin_menu VALUES (57,48,5,'_ADD_MOD','index.php?cat=forum&act=addmod');
INSERT INTO rafia_admin_menu VALUES (58,'',11,'_DOWNLOAD_PRO','');
INSERT INTO rafia_admin_menu VALUES (59,58,'','_DOWNLOAD_SETTINGS','index.php?cat=download');
INSERT INTO rafia_admin_menu VALUES (60,58,1,'_CATS_LIST','index.php?cat=download&act=cat');
INSERT INTO rafia_admin_menu VALUES (61,58,1,'_ADD_CAT','index.php?cat=download&act=addcat');
INSERT INTO rafia_admin_menu VALUES (62,58,2,'_MOD_LIST','index.php?cat=download&act=mod');
INSERT INTO rafia_admin_menu VALUES (63,58,3,'_ADD_MOD','index.php?cat=download&act=addmod');
INSERT INTO rafia_admin_menu VALUES (64,58,4,'_AVAILABLE_MENUS','index.php?cat=download&act=downmenu');
INSERT INTO rafia_admin_menu VALUES (65,'',11,'_WEB_LINKS','');
INSERT INTO rafia_admin_menu VALUES (66,65,'','_WEB_LINKS_SETTINGS','index.php?cat=link');
INSERT INTO rafia_admin_menu VALUES (67,65,1,'_CATS_LIST','index.php?cat=link&act=cat');
INSERT INTO rafia_admin_menu VALUES (68,65,1,'_ADD_CAT','index.php?cat=link&act=addcat');
INSERT INTO rafia_admin_menu VALUES (69,65,2,'_MOD_LIST','index.php?cat=link&act=mod');
INSERT INTO rafia_admin_menu VALUES (70,65,3,'_ADD_MOD','index.php?cat=link&act=addmod');
INSERT INTO rafia_admin_menu VALUES (71,65,4,'_AVAILABLE_MENUS','index.php?cat=link&act=linkmenu');
INSERT INTO rafia_admin_menu VALUES (72,4,3,'_MAIN_MENUS','index.php?cat=menu&act=indexmenu');
INSERT INTO rafia_admin_menu VALUES (73,'',1,'_MOD','mod.php');
INSERT INTO rafia_admin_menu VALUES (74,1,8,'_COUNTER','index.php?cat=stat');
INSERT INTO rafia_admin_menu VALUES (75,73,1,'_MOD_NEW','mod.php?act=new');
INSERT INTO rafia_admin_menu VALUES (76,73,2,'_MOD_SET','mod.php?act=set');
INSERT INTO rafia_admin_menu VALUES (77,73,3,'_MOD_MANAG','mod.php?act=manag');
INSERT INTO rafia_admin_menu VALUES (78,73,3,'_MOD_TEMP','mod.php?act=temp');
INSERT INTO rafia_admin_menu VALUES (79,1,8,'_CHECKNEW','index.php?cat=checknew');
INSERT INTO rafia_admin_menu VALUES (80,13,6,'_UPDATE_U_P','index.php?cat=users&act=update_u_p');
INSERT INTO rafia_admin_menu VALUES (81, 1, 8, '_MAIL_US', 'index.php?cat=mailus');

#------------------- TABLE rafia_admin_sess -------------------
DROP TABLE IF EXISTS rafia_admin_sess; 

CREATE TABLE `rafia_admin_sess` (
  `sessID` varchar(32) NOT NULL default '',
  `sessIP` varchar(32) NOT NULL default '',
  `sess_NAME` varchar(32) NOT NULL default '',
  `sess_TIME` int(11) NOT NULL default '0',
  `sess_VALUE` text NOT NULL,
  `sess_LOGTIME` int(10) NOT NULL default '0',
  PRIMARY KEY  (`sessID`)
) ;


#------------------- TABLE rafia_ads -------------------
DROP TABLE IF EXISTS rafia_ads; 

CREATE TABLE rafia_ads (
  adsid tinyint(10) unsigned NOT NULL auto_increment,
  adsimg varchar(200) default NULL,
  width int(3) NOT NULL default '0',
  height int(3) NOT NULL default '0',
  adsdatetime int(11) NOT NULL default '0',
  adsurl varchar(200) default NULL,
  adsisshow varchar(5) NOT NULL default 'no',
  adsname varchar(200) default NULL,
  numshow int(10) unsigned default '0',
  clicks int(10) NOT NULL default '0',
  viewin char(1) NOT NULL default 'h',
  active tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (adsid)
);


INSERT INTO rafia_ads VALUES (1,'images/e3lanat/e3lan.gif','','',1161540665,'http://www.arabportal.info','yes','������� �������',0,'','h',1);
INSERT INTO rafia_ads VALUES (2,'images/e3lanat/book.gif','','',1169222970,'http://www.arabportal.info','yes','������� ������� 2.2',0,'','m',1);
INSERT INTO rafia_ads VALUES (3,'images/e3lanat/service4ar.gif', 0, 0, 1192488883, 'http://www.service4ar.com', 'yes', '���� ����� �����', 2, 0, 'm', 1); 
INSERT INTO rafia_ads VALUES (4,'images/e3lanat/service4ar.swf','','',1169222970,'http://www.service4ar.com','yes','������� ������� 2.2',0,'','f',1);


#------------------- TABLE rafia_alert -------------------
DROP TABLE IF EXISTS rafia_alert; 

CREATE TABLE `rafia_alert` (
  `id` int(10) NOT NULL auto_increment,
  `news_id` int(10) NOT NULL default '0',
  `thread_id` int(10) NOT NULL default '0',
  `down_id` int(10) NOT NULL default '0',
  `userid` int(10) NOT NULL default '0',
  `sendmsg` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ;


#------------------- TABLE rafia_groups -------------------
DROP TABLE IF EXISTS rafia_groups; 
CREATE TABLE `rafia_groups` (
  `groupid` int(3) unsigned NOT NULL auto_increment,
  `grouptitle` varchar(100) NOT NULL default '',
  `editble` tinyint(1) default '0',
  `deletble` tinyint(1) default '0',
  PRIMARY KEY  (`groupid`)
);

INSERT INTO rafia_groups VALUES (1,'���� ������',1,'');
INSERT INTO rafia_groups VALUES (2,'����� ���',1,'');
INSERT INTO rafia_groups VALUES (3,'��������',1,'');
INSERT INTO rafia_groups VALUES (4,'�������',1,'');
INSERT INTO rafia_groups VALUES (5,'������',1,'');

#------------------- TABLE rafia_privilege -------------------
DROP TABLE IF EXISTS rafia_privilege; 

CREATE TABLE `rafia_privilege` (
  `id` int(15) NOT NULL auto_increment,
  `groupid` int(5) default NULL,
  `title` varchar(255) NOT NULL default '',
  `variable` varchar(255) NOT NULL default '',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `action` (`variable`)
);

INSERT INTO rafia_privilege VALUES (1,1,'','view_site','1');
INSERT INTO rafia_privilege VALUES (2,1,'','add_news','1');
INSERT INTO rafia_privilege VALUES (3,1,'','stat_news','yes');
INSERT INTO rafia_privilege VALUES (4,1,'','add_news_c','1');
INSERT INTO rafia_privilege VALUES (5,1,'','download_news_file','1');
INSERT INTO rafia_privilege VALUES (6,1,'','add_news_img','1');
INSERT INTO rafia_privilege VALUES (7,1,'','view_news_img','1');
INSERT INTO rafia_privilege VALUES (8,1,'','edit_news','1');
INSERT INTO rafia_privilege VALUES (9,1,'','edit_news_own','1');
INSERT INTO rafia_privilege VALUES (10,1,'','delete_news','1');
INSERT INTO rafia_privilege VALUES (11,1,'','print_news','1');
INSERT INTO rafia_privilege VALUES (12,1,'','ues_editor','1');
INSERT INTO rafia_privilege VALUES (13,1,'','view_forum','1');
INSERT INTO rafia_privilege VALUES (14,1,'','add_forum_post','1');
INSERT INTO rafia_privilege VALUES (15,1,'','stat_forum','yes');
INSERT INTO rafia_privilege VALUES (16,1,'','add_forum_c','1');
INSERT INTO rafia_privilege VALUES (17,1,'','upload_forum_file','1');
INSERT INTO rafia_privilege VALUES (18,1,'','download_forum_file','1');
INSERT INTO rafia_privilege VALUES (19,1,'','edit_forum','1');
INSERT INTO rafia_privilege VALUES (20,1,'','edit_forum_own','1');
INSERT INTO rafia_privilege VALUES (21,1,'','delete_forum','1');
INSERT INTO rafia_privilege VALUES (22,1,'','print_forum','1');
INSERT INTO rafia_privilege VALUES (23,1,'','view_download','1');
INSERT INTO rafia_privilege VALUES (24,1,'','stat_download','yes');
INSERT INTO rafia_privilege VALUES (25,1,'','add_download','1');
INSERT INTO rafia_privilege VALUES (26,1,'','add_download_c','1');
INSERT INTO rafia_privilege VALUES (27,1,'','upload_download_file','1');
INSERT INTO rafia_privilege VALUES (28,1,'','edit_download','1');
INSERT INTO rafia_privilege VALUES (29,1,'','edit_download_own','1');
INSERT INTO rafia_privilege VALUES (30,1,'','allow_download_alert','1');
INSERT INTO rafia_privilege VALUES (31,1,'','allow_download_rate','1');
INSERT INTO rafia_privilege VALUES (32,1,'','use_search','1');
INSERT INTO rafia_privilege VALUES (33,1,'','allow_comment','yes');
INSERT INTO rafia_privilege VALUES (34,1,'','edit_comment','1');
INSERT INTO rafia_privilege VALUES (35,1,'','edit_comment_own','1');
INSERT INTO rafia_privilege VALUES (36,1,'','upload_comment_file','1');
INSERT INTO rafia_privilege VALUES (37,1,'','view_link','1');
INSERT INTO rafia_privilege VALUES (38,1,'','add_link','1');
INSERT INTO rafia_privilege VALUES (39,1,'','stat_link','yes');
INSERT INTO rafia_privilege VALUES (40,1,'','allow_link_alert','1');
INSERT INTO rafia_privilege VALUES (41,1,'','allow_link_rate','1');
INSERT INTO rafia_privilege VALUES (42,1,'','allow_members_list','1');
INSERT INTO rafia_privilege VALUES (43,2,'','view_site','1');
INSERT INTO rafia_privilege VALUES (44,2,'','add_news','1');
INSERT INTO rafia_privilege VALUES (45,2,'','stat_news','yes');
INSERT INTO rafia_privilege VALUES (46,2,'','add_news_c','1');
INSERT INTO rafia_privilege VALUES (47,2,'','download_news_file','1');
INSERT INTO rafia_privilege VALUES (48,2,'','add_news_img','1');
INSERT INTO rafia_privilege VALUES (49,2,'','view_news_img','1');
INSERT INTO rafia_privilege VALUES (50,2,'','edit_news','1');
INSERT INTO rafia_privilege VALUES (51,2,'','edit_news_own','1');
INSERT INTO rafia_privilege VALUES (52,2,'','delete_news','1');
INSERT INTO rafia_privilege VALUES (53,2,'','print_news','1');
INSERT INTO rafia_privilege VALUES (54,2,'','ues_editor','1');
INSERT INTO rafia_privilege VALUES (55,2,'','view_forum','1');
INSERT INTO rafia_privilege VALUES (56,2,'','add_forum_post','1');
INSERT INTO rafia_privilege VALUES (57,2,'','stat_forum','yes');
INSERT INTO rafia_privilege VALUES (58,2,'','add_forum_c','1');
INSERT INTO rafia_privilege VALUES (59,2,'','upload_forum_file','1');
INSERT INTO rafia_privilege VALUES (60,2,'','download_forum_file','1');
INSERT INTO rafia_privilege VALUES (61,2,'','edit_forum','1');
INSERT INTO rafia_privilege VALUES (62,2,'','edit_forum_own','1');
INSERT INTO rafia_privilege VALUES (63,2,'','delete_forum','1');
INSERT INTO rafia_privilege VALUES (64,2,'','print_forum','1');
INSERT INTO rafia_privilege VALUES (65,2,'','view_download','1');
INSERT INTO rafia_privilege VALUES (66,2,'','stat_download','yes');
INSERT INTO rafia_privilege VALUES (67,2,'','add_download','1');
INSERT INTO rafia_privilege VALUES (68,2,'','add_download_c','1');
INSERT INTO rafia_privilege VALUES (69,2,'','upload_download_file','1');
INSERT INTO rafia_privilege VALUES (70,2,'','edit_download','1');
INSERT INTO rafia_privilege VALUES (71,2,'','edit_download_own','1');
INSERT INTO rafia_privilege VALUES (72,2,'','allow_download_alert','1');
INSERT INTO rafia_privilege VALUES (73,2,'','allow_download_rate','1');
INSERT INTO rafia_privilege VALUES (74,2,'','use_search','1');
INSERT INTO rafia_privilege VALUES (75,2,'','allow_comment','yes');
INSERT INTO rafia_privilege VALUES (76,2,'','edit_comment','1');
INSERT INTO rafia_privilege VALUES (77,2,'','edit_comment_own','1');
INSERT INTO rafia_privilege VALUES (78,2,'','upload_comment_file','1');
INSERT INTO rafia_privilege VALUES (79,2,'','view_link','1');
INSERT INTO rafia_privilege VALUES (80,2,'','add_link','1');
INSERT INTO rafia_privilege VALUES (81,2,'','stat_link','yes');
INSERT INTO rafia_privilege VALUES (82,2,'','allow_link_alert','1');
INSERT INTO rafia_privilege VALUES (83,2,'','allow_link_rate','1');
INSERT INTO rafia_privilege VALUES (84,2,'','allow_members_list','1');
INSERT INTO rafia_privilege VALUES (85,3,'','view_site','1');
INSERT INTO rafia_privilege VALUES (86,3,'','add_news','1');
INSERT INTO rafia_privilege VALUES (87,3,'','stat_news','wit');
INSERT INTO rafia_privilege VALUES (88,3,'','add_news_c','1');
INSERT INTO rafia_privilege VALUES (89,3,'','download_news_file','1');
INSERT INTO rafia_privilege VALUES (90,3,'','add_news_img','1');
INSERT INTO rafia_privilege VALUES (91,3,'','view_news_img','1');
INSERT INTO rafia_privilege VALUES (92,3,'','edit_news','');
INSERT INTO rafia_privilege VALUES (93,3,'','edit_news_own','1');
INSERT INTO rafia_privilege VALUES (94,3,'','delete_news','1');
INSERT INTO rafia_privilege VALUES (95,3,'','print_news','1');
INSERT INTO rafia_privilege VALUES (96,3,'','ues_editor','');
INSERT INTO rafia_privilege VALUES (97,3,'','view_forum','1');
INSERT INTO rafia_privilege VALUES (98,3,'','add_forum_post','1');
INSERT INTO rafia_privilege VALUES (99,3,'','stat_forum','yes');
INSERT INTO rafia_privilege VALUES (100,3,'','add_forum_c','1');
INSERT INTO rafia_privilege VALUES (101,3,'','upload_forum_file','1');
INSERT INTO rafia_privilege VALUES (102,3,'','download_forum_file','1');
INSERT INTO rafia_privilege VALUES (103,3,'','edit_forum','');
INSERT INTO rafia_privilege VALUES (104,3,'','edit_forum_own','1');
INSERT INTO rafia_privilege VALUES (105,3,'','delete_forum','1');
INSERT INTO rafia_privilege VALUES (106,3,'','print_forum','1');
INSERT INTO rafia_privilege VALUES (107,3,'','view_download','1');
INSERT INTO rafia_privilege VALUES (108,3,'','stat_download','wit');
INSERT INTO rafia_privilege VALUES (109,3,'','add_download','1');
INSERT INTO rafia_privilege VALUES (110,3,'','add_download_c','1');
INSERT INTO rafia_privilege VALUES (111,3,'','upload_download_file','1');
INSERT INTO rafia_privilege VALUES (112,3,'','edit_download','');
INSERT INTO rafia_privilege VALUES (113,3,'','edit_download_own','1');
INSERT INTO rafia_privilege VALUES (114,3,'','allow_download_alert','1');
INSERT INTO rafia_privilege VALUES (115,3,'','allow_download_rate','1');
INSERT INTO rafia_privilege VALUES (116,3,'','use_search','1');
INSERT INTO rafia_privilege VALUES (117,3,'','allow_comment','yes');
INSERT INTO rafia_privilege VALUES (118,3,'','edit_comment','1');
INSERT INTO rafia_privilege VALUES (119,3,'','edit_comment_own','1');
INSERT INTO rafia_privilege VALUES (120,3,'','upload_comment_file','1');
INSERT INTO rafia_privilege VALUES (121,3,'','view_link','1');
INSERT INTO rafia_privilege VALUES (122,3,'','add_link','1');
INSERT INTO rafia_privilege VALUES (123,3,'','stat_link','wit');
INSERT INTO rafia_privilege VALUES (124,3,'','allow_link_alert','1');
INSERT INTO rafia_privilege VALUES (125,3,'','allow_link_rate','1');
INSERT INTO rafia_privilege VALUES (126,3,'','allow_members_list','1');
INSERT INTO rafia_privilege VALUES (127,4,'','view_site','1');
INSERT INTO rafia_privilege VALUES (128,4,'','add_news','1');
INSERT INTO rafia_privilege VALUES (129,4,'','stat_news','wit');
INSERT INTO rafia_privilege VALUES (130,4,'','add_news_c','1');
INSERT INTO rafia_privilege VALUES (131,4,'','download_news_file','');
INSERT INTO rafia_privilege VALUES (132,4,'','add_news_img','1');
INSERT INTO rafia_privilege VALUES (133,4,'','view_news_img','1');
INSERT INTO rafia_privilege VALUES (134,4,'','edit_news','');
INSERT INTO rafia_privilege VALUES (135,4,'','edit_news_own','');
INSERT INTO rafia_privilege VALUES (136,4,'','delete_news','');
INSERT INTO rafia_privilege VALUES (137,4,'','print_news','1');
INSERT INTO rafia_privilege VALUES (138,4,'','ues_editor','');
INSERT INTO rafia_privilege VALUES (139,4,'','view_forum','1');
INSERT INTO rafia_privilege VALUES (140,4,'','add_forum_post','1');
INSERT INTO rafia_privilege VALUES (141,4,'','stat_forum','yes');
INSERT INTO rafia_privilege VALUES (142,4,'','add_forum_c','1');
INSERT INTO rafia_privilege VALUES (143,4,'','upload_forum_file','1');
INSERT INTO rafia_privilege VALUES (144,4,'','download_forum_file','1');
INSERT INTO rafia_privilege VALUES (145,4,'','edit_forum','');
INSERT INTO rafia_privilege VALUES (146,4,'','edit_forum_own','1');
INSERT INTO rafia_privilege VALUES (147,4,'','delete_forum','1');
INSERT INTO rafia_privilege VALUES (148,4,'','print_forum','1');
INSERT INTO rafia_privilege VALUES (149,4,'','view_download','1');
INSERT INTO rafia_privilege VALUES (150,4,'','stat_download','wit');
INSERT INTO rafia_privilege VALUES (151,4,'','add_download','1');
INSERT INTO rafia_privilege VALUES (152,4,'','add_download_c','1');
INSERT INTO rafia_privilege VALUES (153,4,'','upload_download_file','1');
INSERT INTO rafia_privilege VALUES (154,4,'','edit_download','');
INSERT INTO rafia_privilege VALUES (155,4,'','edit_download_own','1');
INSERT INTO rafia_privilege VALUES (156,4,'','allow_download_alert','1');
INSERT INTO rafia_privilege VALUES (157,4,'','allow_download_rate','1');
INSERT INTO rafia_privilege VALUES (158,4,'','use_search','1');
INSERT INTO rafia_privilege VALUES (159,4,'','allow_comment','yes');
INSERT INTO rafia_privilege VALUES (160,4,'','edit_comment','');
INSERT INTO rafia_privilege VALUES (161,4,'','edit_comment_own','1');
INSERT INTO rafia_privilege VALUES (162,4,'','upload_comment_file','1');
INSERT INTO rafia_privilege VALUES (163,4,'','view_link','1');
INSERT INTO rafia_privilege VALUES (164,4,'','add_link','1');
INSERT INTO rafia_privilege VALUES (165,4,'','stat_link','wit');
INSERT INTO rafia_privilege VALUES (166,4,'','allow_link_alert','1');
INSERT INTO rafia_privilege VALUES (167,4,'','allow_link_rate','1');
INSERT INTO rafia_privilege VALUES (168,4,'','allow_members_list','1');
INSERT INTO rafia_privilege VALUES (169,5,'','view_site','1');
INSERT INTO rafia_privilege VALUES (170,5,'','add_news','');
INSERT INTO rafia_privilege VALUES (171,5,'','stat_news','wit');
INSERT INTO rafia_privilege VALUES (172,5,'','add_news_c','');
INSERT INTO rafia_privilege VALUES (173,5,'','download_news_file','');
INSERT INTO rafia_privilege VALUES (174,5,'','add_news_img','');
INSERT INTO rafia_privilege VALUES (175,5,'','view_news_img','1');
INSERT INTO rafia_privilege VALUES (176,5,'','edit_news','');
INSERT INTO rafia_privilege VALUES (177,5,'','edit_news_own','');
INSERT INTO rafia_privilege VALUES (178,5,'','delete_news','');
INSERT INTO rafia_privilege VALUES (179,5,'','print_news','1');
INSERT INTO rafia_privilege VALUES (180,5,'','ues_editor','');
INSERT INTO rafia_privilege VALUES (181,5,'','view_forum','1');
INSERT INTO rafia_privilege VALUES (182,5,'','add_forum_post','');
INSERT INTO rafia_privilege VALUES (183,5,'','stat_forum','wit');
INSERT INTO rafia_privilege VALUES (184,5,'','add_forum_c','');
INSERT INTO rafia_privilege VALUES (185,5,'','upload_forum_file','');
INSERT INTO rafia_privilege VALUES (186,5,'','download_forum_file','');
INSERT INTO rafia_privilege VALUES (187,5,'','edit_forum','');
INSERT INTO rafia_privilege VALUES (188,5,'','edit_forum_own','');
INSERT INTO rafia_privilege VALUES (189,5,'','delete_forum','');
INSERT INTO rafia_privilege VALUES (190,5,'','print_forum','');
INSERT INTO rafia_privilege VALUES (191,5,'','view_download','1');
INSERT INTO rafia_privilege VALUES (192,5,'','stat_download','wit');
INSERT INTO rafia_privilege VALUES (193,5,'','add_download','');
INSERT INTO rafia_privilege VALUES (194,5,'','add_download_c','');
INSERT INTO rafia_privilege VALUES (195,5,'','upload_download_file','');
INSERT INTO rafia_privilege VALUES (196,5,'','edit_download','');
INSERT INTO rafia_privilege VALUES (197,5,'','edit_download_own','');
INSERT INTO rafia_privilege VALUES (198,5,'','allow_download_alert','1');
INSERT INTO rafia_privilege VALUES (199,5,'','allow_download_rate','1');
INSERT INTO rafia_privilege VALUES (200,5,'','use_search','');
INSERT INTO rafia_privilege VALUES (201,5,'','allow_comment','wit');
INSERT INTO rafia_privilege VALUES (202,5,'','edit_comment','');
INSERT INTO rafia_privilege VALUES (203,5,'','edit_comment_own','');
INSERT INTO rafia_privilege VALUES (204,5,'','upload_comment_file','');
INSERT INTO rafia_privilege VALUES (205,5,'','view_link','1');
INSERT INTO rafia_privilege VALUES (206,5,'','add_link','');
INSERT INTO rafia_privilege VALUES (207,5,'','stat_link','wit');
INSERT INTO rafia_privilege VALUES (208,5,'','allow_link_alert','1');
INSERT INTO rafia_privilege VALUES (209,5,'','allow_link_rate','1');
INSERT INTO rafia_privilege VALUES (210,5,'','allow_members_list','');


#------------------- TABLE rafia_cat -------------------
DROP TABLE IF EXISTS rafia_cat; 

CREATE TABLE `rafia_cat` (
  `id` int(10) NOT NULL auto_increment,
  `ordercat` int(10) NOT NULL default '0',
  `catType` int(3) NOT NULL default '0',
  `subcat` int(10) NOT NULL default '0',
  `title` varchar(100) NOT NULL default '',
  `dsc` text NOT NULL,
  `dscin` text NOT NULL,
  `countopic` int(10) NOT NULL default '0',
  `countcomm` int(10) NOT NULL default '0',
  `lastpostid` int(11) NOT NULL default '0',
  `moderateid` varchar(100) NOT NULL default '0',
  `ismine` tinyint(2) NOT NULL default '0',
  `groupost` varchar(200) NOT NULL default '0',
  `groupview` varchar(200) NOT NULL default '0',
  `cat_email` varchar(255) default NULL,
  `catClose` char(1) NOT NULL default '0',
  `homeshow` int(4) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ;

INSERT INTO rafia_cat VALUES (1, 0, 1, 0, '����� �����', '���� ������� �������', '', 1, 0, 1, '', 0, '', '', '', '', 1);
INSERT INTO rafia_cat VALUES (2, 0, 2, 0, '��������� ������', '', '', 0, 0, 0, '', 1, '', '', '', '', 0);
INSERT INTO rafia_cat VALUES (3, 0, 2, 2, '������� �����', '���� �������� ������ ����� ������ �� ���� ����', '', 0, 0, 3, '', 0, '', '', '', '0', 1);
INSERT INTO rafia_cat VALUES (4, 0, 3, 0, '����� �����', '��� ������� �������', '��� ������� �������', 0, 0, 1, '', 0, '', '', '', '', 1);
INSERT INTO rafia_cat VALUES (5, 0, 4, 0, '��� ������', '��� ������� �������', '��� ������� �������', 3, 0, 0, '', 0, '', '', '', '', 1);

#------------------- TABLE rafia_comment -------------------
DROP TABLE IF EXISTS rafia_comment;
CREATE TABLE rafia_comment (
  id int(10) NOT NULL auto_increment,
  news_id int(10) NOT NULL default '0',
  modType int(3) NOT NULL default '0',
  thread_id int(10) NOT NULL default '0',
  down_id int(10) NOT NULL default '0',
  userid int(10) NOT NULL default '0',
  name varchar(100) NOT NULL default '',
  title varchar(100) NOT NULL default '',
  date_time int(11) NOT NULL default '0',
  `comment` text NOT NULL,
  cat_id int(10) NOT NULL default '0',
  usesig tinyint(1) NOT NULL default '1',
  uploadfile int(10) NOT NULL default '0',
  `timestamp` int(10) NOT NULL default '0',
  allow char(3) NOT NULL default '',
  PRIMARY KEY  (id)
);




#------------------- TABLE rafia_counter -------------------
DROP TABLE IF EXISTS rafia_counter; 

CREATE TABLE `rafia_counter` (
  `conterID` int(1) NOT NULL auto_increment,
  `newsCount` int(12) NOT NULL default '0',
  `downCount` int(12) NOT NULL default '0',
  `forumCount` int(12) NOT NULL default '0',
  `gbCount` int(12) NOT NULL default '0',
  `linksCount` int(12) NOT NULL default '0',
  `usersCount` int(12) NOT NULL default '0',
  `commentCount` int(12) NOT NULL default '0',
  `totalCount` int(15) NOT NULL default '0',
  `mostCount` int(12) NOT NULL default '0',
  `mosttime` int(11) NOT NULL default '0',
  `dayCount` int(12) NOT NULL default '0',
  `timetoday` int(11) NOT NULL default '0',
  PRIMARY KEY  (`conterID`)
) ;

INSERT INTO rafia_counter VALUES (1, 1, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0); 


#------------------- TABLE rafia_design -------------------
#
# Table structure for table `rafia_design`
#

DROP TABLE IF EXISTS rafia_design; 
CREATE TABLE rafia_design (
  id tinyint(4) NOT NULL auto_increment,
  theme varchar(60) NOT NULL default '',
  usertheme int(1) NOT NULL default '0',
  themewidth varchar(10) NOT NULL default '',
  themepath varchar(100) default NULL,
  style_css longtext NOT NULL,
  pagehd text NOT NULL,
  pageft text NOT NULL,
  PRIMARY KEY  (id)
);


#
# Dumping data for table `rafia_design`
#

INSERT INTO rafia_design VALUES (1, 'portal', 1, '100%', 'portal', '.nav{\r\n    font-family: arial;\r\n    font-size: 16px;\r\n    font-weight: bold;\r\n    color: Gray; \r\n    align: right;\r\n    padding-right: 25px;\r\n    padding-bottom: 5px;\r\n    margin-bottom: 5px;\r\n    background-image: url(images/r.gif); background-repeat: no-repeat; background-position: right top;\r\n    border-bottom: 1px solid #C2C2C2;\r\n}\r\n.normal {font-family: arial;\r\n    font-size: 16px;\r\n    font-weight: bold;\r\n}\r\n.lettercell\r\n{\r\nbackground-color: #EEEEEE;\r\nfont-family: Tahoma;\r\nfont-size: 12 pt;\r\ntext-align: center;\r\ncolor: #505050\r\ndisplay: block;\r\nborder: 1px #999999 solid;\r\nwidth: 15px ;\r\n\r\n\r\n}\r\n\r\n.letter_table {\r\nborder-collapse: collapse;\r\ntext-align: right;\r\n}\r\n.orang_b     { font-family:Bold 16px Arial;\r\n               color: #FFFFFF; \r\n                background-color: #EE753A; \r\n                    padding:3;\r\n                    margin-left:3px;\r\n\r\n\r\n                    \r\n                    }\r\n.info_bar    { font-family: Tahoma; font-size: 10pt; color: #808080; background-color:\r\n               #EBEBEB }\r\n.normal_dark_link{ font-family: Arial; font-size: 12pt; color: #FFFFFF; font-weight: bold ;text-decoration:none;\r\n\r\npadding-top: 3; padding-bottom: 3\r\n}\r\n\r\n.normal_dark_link2{ font-family: Arial; font-size: 12pt; color: #FFFFFF; font-""weight: bold ;text-decoration: none;\r\n background-color: #34597D; \r\npadding-top: 3; padding-bottom: 3\r\n}\r\n\r\nBODY {\r\n    FONT-FAMILY: #Arial, Helvetica;\r\n    FONT-SIZE : 13px;\r\n    weight: bold;\r\n    COLOR : #3A3A3A;\r\n TEXT-DECORATION : none\r\n    }\r\n\r\nA:link      {\r\n    COLOR : #000000;\r\n    TEXT-DECORATION : none\r\n    }\r\nA:visited   {\r\nCOLOR : #000000;\r\n    TEXT-DECORATION : none\r\n    }\r\nA:hover     {\r\n    COLOR : #cc3300;\r\nTEXT-DECORATION : none\r\n    }\r\nA:active    {\r\nCOLOR : #000000;\r\n    TEXT-DECORATION : none;\r\n    }\r\n\r\nH1 { font-family: \'impact, arial\';\r\n        font-size: 20pt;\r\n        color:  #3A3A3A;\r\n        BACKGROUND-COLOR : #34597D\r\n}\r\n\r\n.fontht{\r\n    font-size: 13px;\r\n    font-family: Arial, Helvetica;\r\n    color: #3A3A3A;\r\n    font-weight: bold;\r\n    }\r\n.fontablt     {\r\n    font-family: tahoma;\r\n    font-size: 10 pt;\r\n     color: #505050\r\n    }\r\nSELECT {\r\n    font-size: 12px Tahoma;\r\n    background-color: #EBEBEB;\r\n    color: #666666;\r\n}\r\nTEXTAREA {\r\nFONT-FAMILY: Tahoma, MS Sans Serif, ;\r\nFONT-SIZE: 12px;\r\nborder: 1px #cccccc solid;\r\n\r\n}\r\n.text_box{\r\n    font:12px tahoma;\r\n border: 1px #cccccc solid;\r\n}\r\n\r\n.button{\r\n  font:12px tahoma;\r\n   background-color: #FFF;\r\n    border: 1px #cccccc solid;\r\n}\r\n\r\n.small{\r\n    font:13px tahoma;\r\n    color: #081440;\r\n\r\n}\r\n\r\n.small1{\r\n    font:13px tahoma;\r\n    color: #ffffff;\r\n\r\n}\r\n.table_main {\r\n   border: 1px #000000 solid;\r\n    background-color: #F1F1F1;\r\n    border-collapse: collapse;\r\n    bordercolor="#111111";\r\n    width="100%" ;\r\n}\r\n\r\n.forum_table_main {\r\n   border: 1px #000000 solid;\r\n    background-color: #F1F1F1;\r\n    border-collapse: collapse;\r\n    bordercolor="#111111";\r\n    width="90%" ;\r\n}\r\n\r\n.td_top_cat {\r\n   background-color: #B0CCB0;\r\n   font-size: 10 pt;\r\n   font-family: tahoma;\r\n   color: 000000;\r\nfont-weight: bold;\r\n\r\n   }\r\n\r\n.catlinkfont {\r\n   font-size: 16 px;\r\n   font-family: arial;\r\n   color: 000000;\r\n\r\n   }\r\n.td_bottom_cat {\r\n   background-color: #FFFFFF;\r\n   font-family: Arial, Helvetica;\r\n   font-size: 9 pt;\r\n   color: 000000\r\n}\r\n.td_top_list\r\n{\r\n    background: #34597D;\r\n    border:0px;  \r\n    vertical-align:top;\r\n    font-size: 12 pt;\r\n font-family: Arial, Helvetica;\r\n    color: #3A3A3A;\r\n    font-weight: bold;\r\n     color: #FFF;\r\n\r\n    \r\n}\r\n.td_middle_list\r\n{\r\n    text-align:right ;\r\n    vertical-align:top;\r\n   font-family: tahoma;\r\n   font-size: 10 pt;\r\n   color: 000000\r\n\r\n}\r\n.td_middle_list2\r\n{\r\n     background-color: E0E9E2;\r\n    text-align:right ;\r\n    vertical-align:top;\r\n   font-family: tahoma;\r\n   font-size: 10 pt;\r\n   color: 000000\r\n}\r\n.bgcolor1{\r\n background-color: #FFFFFF ;\r\n}\r\n.bgcolor2{\r\n background-color: #FFFFFF ;\r\n}\r\n.bgcolor3{\r\n background-color: #34597D;\r\n}\r\n.bgcolor4{\r\n background-color: #FFFFFF ;\r\n}\r\n\r\n.forum_control_bar{\r\n    background: #EEEEEE;\r\n    border-bottom: solid 1px #C1C1C1;\r\n    border-top: solid 1px #FFF;\r\n    font: 12px tahoma;\r\n}\r\n.small_dark_link{\r\n    font-family: tahoma; font-size: 12px; color: #FFFFFF; text-decoration: none;\r\nbackground-color: #34597D; \r\npadding-top: 3; padding-bottom: 3;padding-left: 3;\r\n}\r\n.forum_header{\r\n    font:bold 12pt arial;\r\n    text-align: center;\r\n    background-image: url(../../themes/portal/catbg2.gif);\r\n    background-repeat: repeat-x;\r\n    color: #ffffff;\r\n    padding: 3px;\r\n}\r\n\r\n.forum_header2{\r\n    font:bold 12pt arial;\r\n    text-align: center;\r\n    background-image: url(../../themes/portal/apt_23.gif);\r\n    background-repeat: repeat-x;\r\n    color: #ffffff;\r\n    padding: 3px;\r\n}\r\n\r\n.forum_alt1{\r\n    font:bold 12pt arial;\r\n    color: #02395E;\r\n    background: #F8F8F8;\r\n    padding: 0px;\r\n}\r\n\r\n.forum_alt2{\r\n    font-size: 16 pt;\r\n    font-family: Arial, Helvetica;\r\n    color: #34597D;\r\n    font-weight: bold;\r\n    }\r\n\r\n\r\n.forum_alt3{\r\n    font:bold 12pt arial;\r\n    color: #34597D;\r\n    background: #ffffff;\r\n    padding: 0px;\r\n    border-bottom: solid 3px #8CA7C3;\r\n    border-left: solid 1px #8CA7C3;\r\n    border-right: solid 1px #8CA7C3;\r\n    border-top: solid 1px #8CA7C3;\r\n}\r\n\r\n.forum_alt4{\r\n    font:bold 12pt arial;\r\n    text-align: right;\r\n    color: #00225E;\r\n}\r\n\r\n.news_cat_title {\r\n	background: url(themes/portal/cat_bg.gif) repeat-x bottom;\r\n	width: 100%;\r\n	height: 26px;\r\n	text-align: center;\r\n}\r\n.news_cat_title img {\r\n	margin-left: -3px;\r\n	margin-right: -4px;\r\n}\r\n.news_cat_title a {\r\n	height: 26px;\r\n	font-family: Arial;\r\n	font-size: 15px;\r\n	font-weight: bold;\r\n	color: #7C1D09;\r\n	text-decoration: none;\r\n	padding-top: 4px;\r\n}\r\n.news_cat_title a:hover {\r\n	color: #D2691E;\r\n}\r\n\r\n.news_title {\r\n	padding-right: 14px;\r\n	font-family: Arial;\r\n	font-size: 15px;\r\n	font-weight: bold;\r\n	text-align: right;\r\n	color: #8B0000;\r\n	background-image: url(themes/portal/news_icon.gif);\r\n	background-position: right;\r\n	background-repeat: no-repeat;\r\n	clear: both;\r\n}\r\n.news_title a {\r\n	font-family: Arial;\r\n	font-size: 15px;\r\n	font-weight: bold;\r\n	color: #A52A2A;\r\n	text-align: right;\r\n	text-decoration: none;\r\n}\r\n.news_title a:hover {\r\n	color: #D2691E;\r\n	text-align: right;\r\n}\r\n\r\n.article_info\r\n{\r\n	background-image: url(themes/portal/info.gif);\r\n	background-repeat: no-repeat;\r\n	background-position: right;\r\n	color: #516A93;\r\n	font-family: Tahoma;\r\n	font-size: 11px;\r\n	display: block;\r\n	padding: 2px 13px 2px 3px;\r\n	margin-bottom: 2px;\r\n}\r\n.article_info a {\r\n	color: #A0522D;\r\n	text-decoration: none;\r\n}\r\n.article_pic {\r\n	border: 1px solid #CCCCCC;\r\n	padding: 3px 3px 3px 3px;\r\n	margin: 3px 2px 1px 2px;\r\n	background-color: White;\r\n	display: inline;\r\n}\r\n.home_text {\r\n	font: 12px Tahoma;\r\n	color: #505050;\r\n	text-align: justify;\r\n}\r\n.side_menu_head{\r\n    font-family: Tahoma;\r\n    font-size: 12px;\r\n    color: #000000;\r\n    padding: 3px;\r\n}\r\n.side_menu_center{\r\n    font-family: Tahoma;\r\n    font-size: 10 pt;\r\n    text-align: right;\r\n     color: #505050\r\n}\r\n.side_menu_center a {\r\n	font-family: Tahoma;\r\n	font-size: 12px;\r\n	color: #505050;\r\n	text-align: right;\r\n	text-decoration: none;\r\n}\r\n.side_menu_center a:hover {\r\n	color: #D2691E;\r\n}', '<body background="themes/$apt->themepath/background.gif" topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0">\r\n\r\n<div align="center">\r\n	<table border="0" width="$themewidth" id="table2" cellspacing="0" cellpadding="0">\r\n		<tr>\r\n			<td width="100%">\r\n			<div align="center">\r\n				<table border="0" cellpadding="0" style="border-collapse: collapse">\r\n					<tr>\r\n						<td width="18">\r\n						<img border="0" src="themes/$apt->themepath/arabportal_06.gif"></td>\r\n						<td background="themes/$apt->themepath/arabportal_03.gif">\r\n						<map name="FPMap0">\r\n						<area href="index.php" shape="rect" coords="477, 3, 537, 29">\r\n						<area href="forum.php" shape="rect" coords="412, 3, 470, 29">\r\n						<area href="news.php" shape="rect" coords="351, 2, 406, 29">\r\n						<area href="download.php" shape="rect" coords="260, 1, 342, 29">\r\n						<area href="link.php" shape="rect" coords="165, 1, 250, 29">\r\n						<area href="guestbook.php" shape="rect" coords="83, 2, 160, 29">\r\n						<area href="mail.php" shape="rect" coords="6, 2, 75, 29">\r\n						</map>\r\n						<img border="0" src="themes/$apt->themepath/arabportal_04.gif" usemap="#FPMap0"></td>\r\n						<td background="themes/$apt->themepath/arabportal_03.gif">\r\n						</td>\r\n						<td background="themes/$apt->themepath/arabportal_03.gif" width="100%">\r\n						<a href="index.php?action=rss">\r\n						<img border="0" src="themes/$apt->themepath/arabportal_02.gif" align="left"></a></td>\r\n						<td width="16">\r\n						<img border="0" src="themes/$apt->themepath/arabportal_01.gif" width="77" height="30"></td>\r\n					</tr>\r\n\r\n				</table>\r\n			</div>\r\n			</td>\r\n		</tr>\r\n	</table>\r\n</div>\r\n<center>\r\n<table border="0" width="$themewidth" cellspacing="0" cellpadding="0">\r\n	<tr>\r\n		<td width="47">\r\n		<img border="0" src="themes/$apt->themepath/arabportal_12.gif" ></td>\r\n		<td width="284">\r\n		<img border="0" src="themes/$apt->themepath/arabportal_11.gif" ></td>\r\n		<td background="themes/$apt->themepath/arabportal_10.gif" width="100%"> </td>\r\n		<td>\r\n		<img border="0" src="themes/$apt->themepath/arabportal_08.gif" ></td>\r\n		<td>\r\n		<img border="0" src="themes/$apt->themepath/arabportal_07.gif" ></td>\r\n	</tr>\r\n</table>\r\n\r\n</center>', '<!-- Footer Start -->\r\n\r\n<div align="center">\r\n	<table border="0" cellpadding="0" style="border-collapse: collapse" width="$themewidth">\r\n		<tr>\r\n			<td width="18">\r\n			<img border="0" src="themes/$apt->themepath/arabportal_20.gif" width="18" height="20"></td>\r\n			<td width="4%" align="center" style="color: #3F81A1; font-family: Tahoma; font-size: 10pt">\r\n			<img border="0" src="themes/$apt->themepath/footer_right.gif"></td>\r\n			<td background="themes/$apt->themepath/f_midd.gif" width="100%" align="center" style="color: #3F81A1; font-family: Tahoma; font-size: 10pt">\r\n			</td>\r\n			<td background="themes/$apt->themepath/footer_03.jpg" width="2%" align="center" style="color: #3F81A1; font-family: Tahoma; font-size: 10pt">\r\n			<img border="0" src="themes/$apt->themepath/footer_left.gif"></td>\r\n			<td width="19">\r\n			<img border="0" src="themes/$apt->themepath/arabportal_16.gif" width="19" height="20"></td>\r\n		</tr>\r\n	</table>\r\n</div>\r\n<center>\r\n<table border="0" cellpadding="0" width="$themewidth" id="table2" style="border-collapse: collapse">\r\n	<tr>\r\n		<td background="themes/$apt->themepath/mm_space.gif">\r\n		<img border="0" src="themes/$apt->themepath/mm_space.gif" width="8" height="6"></td>\r\n		<td background="themes/$apt->themepath/mm_space.gif" width="100%" align="center" style="color: #3F81A1; font-family: Tahoma; font-size: 10pt">\r\n		<img border="0" src="themes/$apt->themepath/mm_space.gif" width="8" height="6"></td>\r\n		<td background="themes/$apt->themepath/mm_space.gif">\r\n		<img border="0" src="themes/$apt->themepath/mm_space.gif" width="8" height="6"></td>\r\n	</tr>\r\n	<tr>\r\n		<td background="themes/$apt->themepath/arabportal_20.gif">\r\n		<img border="0" src="themes/$apt->themepath/arabportal_20.gif" width="18" height="20"></td>\r\n		<td width="100%" align="center" style="color: #3F81A1; font-family: Tahoma; font-size: 10pt">\r\n		<div align="center">\r\n			<table border="0" cellpadding="0" style="border-collapse: collapse">\r\n				<tr>\r\n					<td width="20" background="themes/$apt->themepath/ft_bt_02.gif">\r\n					<img border="0" src="themes/$apt->themepath/ft_bt_04.gif"></td>\r\n					<td width="4" background="themes/$apt->themepath/ft_bt_02.gif"> \r\n					<img border="0" src="themes/$apt->themepath/verline.gif" width="1" height="50"></td>\r\n					<td width="9" background="themes/$apt->themepath/ft_bt_02.gif">\r\n					<a target="_blank" href="http://www.rowafid.com">\r\n					<img border="0" src="themes/$apt->themepath/rowafid.gif" width="29" height="68"></a></td>\r\n					<td width="20" background="themes/$apt->themepath/ft_bt_02.gif">\r\n					<img border="0" src="themes/$apt->themepath/ft_bt_02.gif" width="32" height="68"></td>\r\n					<td width="20" background="themes/$apt->themepath/ft_bt_02.gif">\r\n$chs_theme\r\n</td>\r\n					<td background="themes/$apt->themepath/ft_bt_02.gif" width="100%">\r\n				<div align="center">\r\n						<table border="0" style="border-collapse: collapse" cellspacing="3">\r\n							<tr>\r\n								<td>\r\n								<p align="center">	\r\n								<font face="Tahoma" style="font-size: ta" size="1" color="#800000">\r\n								<span lang="ar-iq"><a href="index.php">\r\n								<span style="text-decoration: none">\r\n								<font color="#000055">������ ������</font></span></a></span></font><font face="Tahoma" style="font-size: ta" size="1" color="#000055">\r\n								</font><span lang="ar-iq">\r\n								<font face="Tahoma" style="font-size: ta" size="1" color="#000055">\r\n								| </font>\r\n								<font face="Tahoma" style="font-size: ta" size="1" color="#800000">\r\n								<a href="news.php">\r\n								<span style="text-decoration: none">\r\n								<font color="#000055">�������</font></span></a></font></span><font face="Tahoma" style="font-size: ta" size="1" color="#800000"><font face="Tahoma" style="font-size: ta" size="1" color="#000055">\r\n								</font><span lang="ar-iq">\r\n								<font face="Tahoma" style="font-size: ta" size="1" color="#000055">\r\n								| </font><a href="download.php">\r\n								<span style="text-decoration: none">\r\n								<font color="#000055">���� �������</font></span></a></span><font face="Tahoma" style="font-size: ta" size="1" color="#000055">\r\n								</font><span lang="ar-iq">\r\n								<font face="Tahoma" style="font-size: ta" size="1" color="#000055">\r\n								| </font><a href="link.php">\r\n								<span style="text-decoration: none">\r\n								<font color="#000055">���� �������</font></span></a><font face="Tahoma" style="font-size: ta" size="1" color="#000055"> \r\n								| </font><a href="forum.php">\r\n								<span style="text-decoration: none">\r\n								<font color="#000055">�������</font></span></a></span><font face="Tahoma" style="font-size: ta" size="1" color="#000055">\r\n								</font><span lang="ar-iq">\r\n								<font face="Tahoma" style="font-size: ta" size="1" color="#000055">\r\n								| </font><a href="guestbook.php">\r\n								<span style="text-decoration: none">\r\n								<font color="#000055">��� ������</font></span></a><font face="Tahoma" style="font-size: ta" size="1" color="#000055"> \r\n								| </font><a href="mail.php">\r\n								<span style="text-decoration: none">\r\n								<font color="#000055">��������</font></span></a></span></font></p>\r\n								</td>\r\n							</tr>\r\n							<tr>\r\n								<td>\r\n								<div align="center">\r\n									<table border="0" cellpadding="0" style="border-collapse: collapse" width="365" height="32">\r\n										<tr>\r\n											<td background="themes/$apt->themepath/copyright.gif">\r\n											<p align="center" dir="ltr">\r\n											<font color="#000055" face="Verdana" size="2">\r\n											Copyright� 2009</font><font face="Verdana" size="2" color="#000055">\r\n											<img border="0" src="themes/portal/logo.gif">\r\n											</font>\r\n											<font face="Verdana" size="2">\r\n											<font face="Verdana" size="2" color="#000055">\r\n											��������</font>\r\n											<a target="_blank" class="footer_link" href="http://www.arabportal.info">\r\n											<font color="#800000">������ ������� \r\n											������� </font></a>\r\n											<font color="#800000">2.2</font></font></p>\r\n											</td>\r\n										</tr>\r\n									</table>\r\n								</div>\r\n								</td>\r\n							</tr>\r\n						</table>\r\n					</div>\r\n					</td>\r\n						<td width="20" background="themes/$apt->themepath/ft_bt_02.gif">\r\n					<img border="0" src="themes/$apt->themepath/ft_bt_02.gif" width="150" height="68"></td>\r\n					\r\n					<td width="2" background="themes/$apt->themepath/ft_bt_02.gif">\r\n	\r\n				<a href="#top">\r\n					<img border="0" src="themes/$apt->themepath/top.gif" width="24" height="24"></a></td>\r\n					<td width="1" background="themes/$apt->themepath/ft_bt_02.gif">\r\n					</td>\r\n					<td width="2" background="themes/$apt->themepath/ft_bt_02.gif">\r\n					</td>\r\n					<td width="4" background="themes/$apt->themepath/ft_bt_02.gif">\r\n					</td>\r\n					<td width="9" background="themes/$apt->themepath/ft_bt_02.gif">\r\n					</td>\r\n					<td width="4" background="themes/$apt->themepath/ft_bt_02.gif">\r\n					<img border="0" src="themes/$apt->themepath/verline.gif" width="1" height="50"></td>\r\n					<td width="17" background="themes/$apt->themepath/ft_bt_02.gif">\r\n					<img border="0" src="themes/$apt->themepath/ft_bt_01.gif"></td>\r\n				</tr>\r\n			</table>\r\n		</div>\r\n		</td>\r\n		<td background="themes/$apt->themepath/arabportal_20.gif">\r\n		<img border="0" src="themes/$apt->themepath/arabportal_20.gif" width="18" height="20"></td>\r\n	</tr>\r\n</table>\r\n</center>\r\n<!-- Footer End -->\r\n</html>');

#------------------- TABLE rafia_download -------------------
DROP TABLE IF EXISTS rafia_download; 

CREATE TABLE `rafia_download` (
  `id` int(10) NOT NULL auto_increment,
  `cat_id` int(10) NOT NULL default '0',
  `title` varchar(100) NOT NULL default '',
  `date_time` int(11) NOT NULL default '0',
  `userid` int(10) NOT NULL default '0',
  `name` varchar(100) NOT NULL default '',
  `size` varchar(11) NOT NULL default '0',
  `post_head` text NOT NULL,
  `post` text NOT NULL,
  `url` varchar(100) default NULL,
  `uploadfile` int(10) NOT NULL default '0',
  `exp_show` varchar(200) default NULL,
  `formmember` char(3) NOT NULL default 'no',
  `downFrom` tinyint(1) NOT NULL default '1',
  `allow` char(3) NOT NULL default 'yes',
  `rating_total` int(10) NOT NULL default '0',
  `ratings` int(10) NOT NULL default '0',
  `c_comment` int(10) NOT NULL default '0',
  `sticky` tinyint(5) NOT NULL default '0',
  `close` tinyint(1) NOT NULL default '0',
  `clicks` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ;



#------------------- TABLE rafia_email -------------------
DROP TABLE IF EXISTS rafia_email; 

CREATE TABLE `rafia_email` (
  `id` int(10) NOT NULL auto_increment,
  `title` varchar(100) NOT NULL default '',
  `email` varchar(100) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ;



#------------------- TABLE rafia_forum -------------------
DROP TABLE IF EXISTS rafia_forum; 

CREATE TABLE `rafia_forum` (
  `id` int(10) NOT NULL auto_increment,
  `cat_id` int(10) NOT NULL default '0',
  `title` varchar(100) NOT NULL default '',
  `date_time` int(11) NOT NULL default '0',
  `userid` int(10) NOT NULL default '0',
  `name` varchar(100) NOT NULL default '',
  `post` text NOT NULL,
  `allow` char(3) NOT NULL default '',
  `usesig` tinyint(1) NOT NULL default '1',
  `iconid` int(5) NOT NULL default '0',
  `uploadfile` int(10) NOT NULL default '0',
  `reader` int(10) default '0',
  `c_comment` int(10) default '0',
  `sticky` tinyint(5) NOT NULL default '0',
  `close` tinyint(1) NOT NULL default '0',
  `lastuserid` int(10) NOT NULL default '0',
  `timestamp` int(10) NOT NULL default '0',
  `edit_by` varchar(255) NOT NULL default '0',
  `ip_address` varchar(180) default NULL,
  PRIMARY KEY  (`id`),
  KEY `post` (`post`(1))
) ;

#------------------- TABLE rafia_guestbook -------------------
DROP TABLE IF EXISTS rafia_guestbook; 

CREATE TABLE `rafia_guestbook` (
  `id` int(10) NOT NULL auto_increment,
  `date_time` int(11) NOT NULL default '0',
  `name` varchar(100) NOT NULL default '',
  `email` varchar(50) NOT NULL default '',
  `url` varchar(100) NOT NULL default '',
  `guestbook` text NOT NULL,
  `comment` text NOT NULL,
  `allow` char(3) NOT NULL default 'yes',
  `ip` varchar(15) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ;



#------------------- TABLE rafia_links -------------------
DROP TABLE IF EXISTS rafia_links; 

CREATE TABLE `rafia_links` (
  `id` int(10) NOT NULL auto_increment,
  `cat_id` int(10) NOT NULL default '0',
  `title` varchar(100) NOT NULL default '',
  `date_time` int(11) NOT NULL default '0',
  `name` varchar(100) NOT NULL default '',
  `email` varchar(100) NOT NULL default '0',
  `post` text NOT NULL,
  `url` varchar(100) NOT NULL default '0',
  `allow` char(3) NOT NULL default '',
  `rating_total` int(10) NOT NULL default '0',
  `ratings` int(10) NOT NULL default '0',
  `clicks` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ;

INSERT INTO rafia_links VALUES (1,5,'���� ��� �������',1163611446,'admin','webmaster@service4ar.com','����� ����� � ������� ����� ������ �� �������� ������ ���� ��������� � ������ � ���������� � ��� ������','http://www.arabiaone.org','yes','','','');
INSERT INTO rafia_links VALUES (2,5,'���� ������� �������',1163611446,'admin','nobody@arabportal.info','������ ��� ������ ������� ������� � �� ����� ����� 100%','http://www.arabportal.info','yes','','','');
INSERT INTO rafia_links VALUES (3, 5, '���� ����� �����', 1183321345, '����� �����', 'webmaster@service4ar.com', '���� ������ ������� �������� ������ �������', 'http://www.service4ar.com', 'yes', 0, 0, 0);

#------------------- TABLE rafia_menu -------------------
DROP TABLE IF EXISTS rafia_menu; 

CREATE TABLE `rafia_menu` (
  `menuid` int(10) NOT NULL auto_increment,
  `title` varchar(100) default NULL,
  `blockmenu` varchar(100) default NULL,
  `menutitle` varchar(100) default NULL,
  `menuhead` text,
  `menucenter` text,
  `menualign` int(1) NOT NULL default '0',
  `menushow` int(1) NOT NULL default '0',
  `menumodule` varchar(10) NOT NULL default '0',
  `menuorder` int(5) NOT NULL default '0',
  `checkuser` int(1) NOT NULL default '0',
  PRIMARY KEY  (`menuid`),
  KEY `menualign` (`menualign`),
  KEY `menushow` (`menushow`),
  KEY `menumodule` (`menumodule`)
) ;


INSERT INTO rafia_menu VALUES (1, '������� ��������', 'blockmenu', 'mainmenu', '������� ��������', '<div align="center">\r\n	<table border="0" width="100" cellpadding="0" style="border-collapse: collapse">\r\n		<tr>\r\n			<td><a href="index.php">\r\n			<img border="0" src="themes/portal/1.gif"portal></a></td>\r\n		</tr>\r\n		<tr>\r\n			<td><a href="news.php">\r\n			<img border="0" src="themes/portal/2.gif"portal></a></td>\r\n		</tr>\r\n		<tr>\r\n			<td><a href="members.php?action=signup">\r\n			<img border="0" src="themes/portal/3.gif"portal></a></td>\r\n		</tr>\r\n		<tr>\r\n			<td><a href="forum.php">\r\n			<img border="0" src="themes/portal/4.gif"portal></a></td>\r\n		</tr>\r\n		<tr>\r\n			<td><a href="archive.php">\r\n			<img border="0" src="themes/portal/5.gif"portal></a></td>\r\n		</tr>\r\n		<tr>\r\n			<td><a href="download.php">\r\n			<img border="0" src="themes/portal/6.gif"portal></a></td>\r\n		</tr>\r\n		<tr>\r\n			<td><a href="link.php">\r\n			<img border="0" src="themes/portal/7.gif"portal></a></td>\r\n		</tr>\r\n		<tr>\r\n			<td><a href="guestbook.php">\r\n			<img border="0" src="themes/portal/8.gif"portal></a></td>\r\n		</tr>\r\n		<tr>\r\n			<td><a href="guestbook.php?action=add">\r\n			<img border="0" src="themes/portal/9.gif"portal></a></td>\r\n		</tr>\r\n		<tr>\r\n			<td><a href="mail.php">\r\n			<img border="0" src="themes/portal/11.gif"portal></a></td>\r\n		</tr>\r\n	</table>\r\n</div>', 1, 1, '', 0, 0);
INSERT INTO rafia_menu VALUES (2, '������� ��������', 'blockmenu', 'modules', '������� ��������', '$menu_mods', 1, 1, '', 1, 0);
INSERT INTO rafia_menu VALUES (3, '������� ��������', 'blockmenu', 'pages', '������� ��������', '$pages_menu', 2, 1, '', 0, 0);
INSERT INTO rafia_menu VALUES (4, '����� ������', 'blockmenu', 'mainmenu', '����� ������', '<center><br>\r\n<img border=0 src=images/user_login1.gif width=64 height=64><BR>\r\n       </center><table border=0 width=100%><tr><td width=100%>\r\n <form method=post action=members.php?action=login>\r\n    <tr><td> <font face=tahoma size=2>��������</font></td></tr>\r\n    <tr><td><input type=textbox name=username size=13>\r\n    </td></tr><tr><td> <font face=tahoma size=2 >���� ������</font></td></tr>\r\n    <tr><td><input type=password name=userpass size=13>\r\n    </td></tr><tr><td><input  class=button  type=submit value=����><br>\r\n<a href=javascript:rafiawin("popup.php?action=remind",300,400)><font face=tahoma size=2>����� �������ʿ</font></a>\r\n<br>\r\n\r\n<a href=javascript:rafiawin("popup.php?action=activate",250,350)><font face=tahoma size=2>\r\n����� �������� \r\n </font></a>\r\n    </td></tr></form>\r\n</td></tr></table>', 1, 1, '', 4, 2);
INSERT INTO rafia_menu VALUES (5, '����� �������', 'blockmenu', 'member_box', '����� ��:$member_name', '$isadmin\r\n<li><a href=members.php?action=cp>����� ������</b></font></a><br>\r\n\r\n<li><a href=pm.php>������� ������ : ($pmumrows )</b></font></a><br>\r\n\r\n<li><a href=members.php?action=logout>����� ������</b></font></a><br', 1, 1, '', 3, 1);
INSERT INTO rafia_menu VALUES (6, '�����', 'blockmenu', 'mainmenu', '���� �����', '<center><br>\r\n<img border=0 src=images/search2.gif width=64 height=64><BR>\r\n        <form name=search_form  action=search.php method=post>\r\n  <select name=searchin>\r\n<option selected value="">����� �� �</option>\r\n<option value=rafia_news>�������</option>\r\n<option value=rafia_forum>�������</option>\r\n<option value=rafia_download>�������</option>\r\n<option value=rafia_links>�������</option>\r\n</select>\r\n<br>  <input type=text name=searchfor size=14><br>\r\n  <input class=button  type=submit name="submit" value=���></form>\r\n<a href="search.php?action=search">��� �����</a>\r\n  </center>', 1, 1, '', 1, 0);
INSERT INTO rafia_menu VALUES (7, '��� ���������', 'blockmenu', 'last_topics', '��� ���������', '<script language="javascript">\r\n<!--\r\n if (top.location != document.location) top.location = document.location;\r\nvar Open = ""\r\nvar Closed = ""\r\nfunction preload(){\r\nif(document.images){\r\n        Open = new Image(9,9)\r\n        Closed = new Image(9,9)\r\n        Open.src = "images/folo.gif"\r\n        Closed.src = "images/folc.gif"\r\n}}\r\nfunction showhide(what,what2){\r\nif (what.style.display=="none"){\r\nwhat.style.display="";\r\nwhat2.src=Open.src\r\n}\r\nelse{\r\nwhat.style.display="none"\r\nwhat2.src=Closed.src\r\n}\r\n}\r\n-->\r\n</script>\r\n<body onload="preload()">\r\n\r\n<!-- forum �������  -->\r\n<span id="menu1" onClick="showhide(menu1outline,menu1sign)"  style="cursor:hand">\r\n<img id="menu1sign" src="images/folc.gif" valign="bottom">\r\n<font color="#EE4811" size=2><b>\r\n ������� ������� </b></font></span>\r\n<br>\r\n<span id="menu1outline" style="display:\'none\'">\r\n     $forumtopics\r\n</span>\r\n\r\n<!-- download ���� �������   -->\r\n<span id="menu2" onClick="showhide(menu2outline,menu2sign)"  style="cursor:hand">\r\n<img id="menu2sign" src="images/folc.gif" valign="bottom">\r\n<font color="#EE4811" size=2><b>������� ���� �������</b></font></span><br>\r\n<span id="menu2outline" style="display:\'none\'">\r\n$downloadtopics\r\n</span>\r\n\r\n<!-- links ���� �������  -->\r\n<span id="menu3" onClick="showhide(menu3outline,menu3sign)"  style="cursor:hand">\r\n<img id="menu3sign" src="images/folc.gif" valign="bottom">\r\n<font color="#EE4811" size=2><b>  ���� �������</b></font></span><br>\r\n<span id="menu3outline" style="display:\'none\'">\r\n$linkstopics\r\n</span>', 2, 0, '', 3, 0);
INSERT INTO rafia_menu VALUES (8, '������� ��������', 'blockmenu', 'mainmenu', '������� ��������', '<center><table align=center border=0 cellspacing=0 cellpadding=5>\r\n<form name=mail action=mail.php?action=maillist method=post>\r\n<tr><td><select name="posttybe">\r\n<option selected value="add">��������</option>\r\n<option value="delete">�����</option>\r\n</select></td></tr>\r\n<tr><td><input type=text name=email size=12 value="�� ������ ���"></td></tr><tr>\r\n<td align=center><input class="button"  type=submit name=submit value="�����"></td>\r\n</tr></form></table></center>', 2, 1, '', 2, 2);
INSERT INTO rafia_menu VALUES (9, '����� �����', 'blockmenu', 'mainmenu', '����� �����', '<li><a target=_blank href="http://www.arabportal.info">������� �������</a>\r\n<li><a target=_blank href="http://www.arabiaone.org">���� ��� �������</a>\r\n<li><a href="http://www.service4ar.com">���� ����� �����</a>\r\n<li><a href="http://www.oophp.info">����� ������</a>\r\n<li><a href="http://www.scriptat.com/">�������</a>\r\n<li><a target=_blank href="http://myrosy.com">���� Myrosy</a>\r\n<li><a target=_blank href="http://swalif.net/softs">����� ����</a>', 2, 1, '', 4, 0);
INSERT INTO rafia_menu VALUES (10, '����� ����������', 'blockmenu', 'stat_table', '��������', '<font class="fontablt">��� �������:  $numrowsm </font>\r\n<br>    <font class="fontablt">������� �������:  $numrowsn </font>\r\n<br>    <font class="fontablt">������� �������:  $numrowsf</font>\r\n\r\n<br>    <font class=fontablt>������� ������� :  $numrowsd </font>\r\n<br>    <font class=fontablt>������� ���������:  $numrowsg  </font>\r\n<br>    <font class=fontablt>������� �������:  $numrowsl</font>\r\n\r\n<br>    <font class=fontablt>������� ������:  $numrowsc</font>', 1, 1, '', 4, 0);
INSERT INTO rafia_menu VALUES (11, '����� �������', 'blockmenu', 'topics_cat_menu', '����� �������', '<li>\r\n<a href=news.php?action=list&cat_id=$menid>\r\n                  $mentitle</a>', 1, 1, '', 1, 0);
INSERT INTO rafia_menu VALUES (12, '��� �������', 'upblock', 'archive_menu', '��� �������', '<li><a href=news.php?action=view&id=$menlistid>$menlisttitle</a><br>', 1, 1, '', 3, 0);
INSERT INTO rafia_menu VALUES (13, '�������', 'blockmenu', 'poll_menu', '', '', 2, 1, '', 0, 0);
INSERT INTO rafia_menu VALUES (14, '���� ������� �����', 'blockmenu', 'download_menu', '������ �����', '<li><a href=download.php?action=view&id=$id>$title</a><br>', 2, 1, 'download', 3, 0);
INSERT INTO rafia_menu VALUES (15, '��� �������', 'blockmenu', 'new_download_menu', '��� �������', '<li><a href=download.php?action=view&id=$id>$title</a><br>', 2, 1, 'download', 1, 0);
INSERT INTO rafia_menu VALUES (16, '���������� ������ �������', 'blockmenu', 'online_menu', '���������� ������', '<font class=fontablt> ���������� ������ :$online\r\n<br>\r\n�� ������ : $not_user\r\n<br>\r\n�� �������  :  $user_online\r\n<br>\r\n��� �������� : $totalCount\r\n<br>\r\n��� �������� ����� :  $dayCount\r\n<br>\r\n���� ��� ������ ��� :  $mostCount\r\n<br>\r\n�� ����� : $mosttime \r\n\r\n</font>', 1, 1, '', 5, 0);
INSERT INTO rafia_menu VALUES (17, '����� �����', 'blockmenu', 'menu_ads', '�������', '', 2, 1, '', 0, 0);
INSERT INTO rafia_menu VALUES (18, '������ ���������', 'blockmenu', 'mainmenu', '������ ���������', '<!--INC dir="block" file="random_wisdom.php" -->', 2, 1, '', 0, 0);
INSERT INTO rafia_menu VALUES (19, '������� ������', 'blockmenu', 'mainmenu', '������� ������', '<!--INC dir="block" file="hejri_calendar.php" -->', 2, 1, '', 0, 0);

#------------------- TABLE rafia_messages -------------------
DROP TABLE IF EXISTS rafia_messages; 

CREATE TABLE rafia_messages (
  msgid bigint(20) NOT NULL auto_increment,
  mailus tinyint(1) NOT NULL default '0',
  userbox int(10) NOT NULL default '0',
  msgbox int(10) NOT NULL default '0',
  msgdate int(11) NOT NULL default '0',
  msgisread tinyint(1) NOT NULL default '1',
  msgtitle varchar(128) default NULL,
  message text,
  ufromid int(32) NOT NULL default '0',
  fromname varchar(100) NOT NULL default '0',
  utoid int(10) NOT NULL default '0',
  toname varchar(100) NOT NULL default '',
  PRIMARY KEY  (msgid)
);

#------------------- TABLE rafia_moderate -------------------
DROP TABLE IF EXISTS rafia_moderate; 

CREATE TABLE `rafia_moderate` (
  `id` int(10) NOT NULL auto_increment,
  `moderatecatid` int(10) NOT NULL default '0',
  `modadmin` int(10) NOT NULL default '0',
  `moderateid` int(11) NOT NULL default '0',
  `moderatename` varchar(100) NOT NULL default '',
  `can_close` tinyint(1) NOT NULL default '0',
  `can_sticky` tinyint(1) NOT NULL default '0',
  `can_edit` tinyint(1) NOT NULL default '0',
  `can_delete` tinyint(1) NOT NULL default '0',
  `can_move` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ;



#------------------- TABLE rafia_mods -------------------
DROP TABLE IF EXISTS rafia_mods; 

CREATE TABLE `rafia_mods` (
  `id` tinyint(4) NOT NULL auto_increment,
  `mod_name` varchar(30) NOT NULL default '',
  `mod_title` varchar(255) NOT NULL default '',
  `mod_user` tinyint(1) NOT NULL default '0',
  `mod_sys` tinyint(1) NOT NULL default '1',
  `left_menu` int(1) NOT NULL default '0',
  `right_menu` int(1) NOT NULL default '1',
  `middle_menu` int(1) NOT NULL default '1',
  `mnueid` text NOT NULL,
  `themeid` int(10) NOT NULL default '0',
  `adsH` tinyint(1) NOT NULL default '1',
  `adsF` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`,`mod_name`)
) ;


INSERT INTO rafia_mods VALUES (1, 'Top10', '���� 10', 0, 1, 1, 1, 0, '1,2,3,4,6,7,8,9,10,11,14,15,16,17,18,19', 1, 1, 0);
INSERT INTO rafia_mods VALUES (2, 'map', '����� ������', 0, 1, 1, 1, 0, '1,2,3,4,6,7,8,9,10,11,14,15,16,17,18,19', 1, 1, 0);

#------------------- TABLE rafia_mods_settings -------------------
DROP TABLE IF EXISTS rafia_mods_settings; 

CREATE TABLE `rafia_mods_settings` (
  `set_id` int(9) NOT NULL auto_increment,
  `set_mod` varchar(30) NOT NULL default '',
  `set_text` varchar(255) NOT NULL default '',
  `set_var` varchar(255) default NULL,
  `set_val` text,
  `set_order` tinyint(4) default NULL,
  `set_type` tinyint(4) default NULL,
  PRIMARY KEY  (`set_id`)
) ;


INSERT INTO rafia_mods_settings VALUES (1, 'Top10', '��� ��������� ���� �����', 'Top_DeaDSouL', '10', 0, 3);
INSERT INTO rafia_mods_settings VALUES (2, 'map', '����� ����� ������� �� �������', 'use_news', '1', 0, 5);
INSERT INTO rafia_mods_settings VALUES (3, 'map', '����� ����� ������� �� �������', 'use_forum', '1', 0, 5);
INSERT INTO rafia_mods_settings VALUES (4, 'map', '����� ����� ���� ������� �� �������', 'use_download', '1', 0, 5);
INSERT INTO rafia_mods_settings VALUES (5, 'map', '����� ����� ���� ������� �� �������', 'use_link', '1', 0, 5);
INSERT INTO rafia_mods_settings VALUES (6, 'map', '����� ����� ������� �������� �� �������', 'use_mods', '1', 0, 5);
INSERT INTO rafia_mods_settings VALUES (7, 'map', '����� ����� ������� �������� �� �������', 'use_pages', '1', 0, 5);


#------------------- TABLE rafia_mods_templates -------------------
DROP TABLE IF EXISTS rafia_mods_templates; 

CREATE TABLE `rafia_mods_templates` (
  `id` int(10) NOT NULL auto_increment,
  `main` tinyint(1) NOT NULL default '0',
  `themeid` int(10) NOT NULL default '0',
  `sub` int(10) NOT NULL default '0',
  `modid` int(10) NOT NULL default '0',
  `modname` varchar(50) NOT NULL default '',
  `theme` varchar(30) NOT NULL default '',
  `temp_title` varchar(100) NOT NULL default '',
  `template` longtext NOT NULL,
  PRIMARY KEY  (`id`)
) ;

#------------------- TABLE rafia_news -------------------

DROP TABLE IF EXISTS rafia_news;
CREATE TABLE rafia_news (
  id int(255) NOT NULL auto_increment,
  cat_id int(255) NOT NULL default '0',
  title varchar(100) NOT NULL default '',
  date_time int(11) NOT NULL default '0',
  `date` date NOT NULL default '0000-00-00',
  userid int(11) NOT NULL default '0',
  `name` varchar(100) NOT NULL default '',
  news_head text NOT NULL,
  post longtext,
  allow char(3) NOT NULL default '',
  inindex int(1) NOT NULL default '1',
  inmenu int(1) NOT NULL default '1',
  main tinyint(1) NOT NULL default '0',
  catmig int(1) NOT NULL default '0',
  reader int(10) default '0',
  c_comment int(10) default '0',
  sticky tinyint(2) NOT NULL default '0',
  `close` int(1) NOT NULL default '0',
  rating_total int(10) NOT NULL default '0',
  ratings int(10) NOT NULL default '0',
  `datetime` datetime NOT NULL default '0000-00-00 00:00:00',
  lastuserid int(11) NOT NULL default '0',
  `timestamp` int(11) NOT NULL default '0',
  uploadfile int(10) NOT NULL default '0',
  ues_editor int(1) NOT NULL default '0',
  edit_by varchar(255) NOT NULL default '0',
  PRIMARY KEY  (id),
  KEY `timestamp` (`timestamp`),
  KEY cat_id (cat_id),
  KEY userid (userid),
  FULLTEXT KEY post (post),
  FULLTEXT KEY news_head (news_head),
  FULLTEXT KEY title (title)
);
INSERT INTO rafia_news VALUES (1, 1, '�� �� ������� ������� �', 1234370646, '0000-00-00', 1, 'admin', '<p>�� ���� ����� ���� � ���� ������� ���� ����� ������ ������ ������ ����� ���� ����� � ������ ��� ���� �������� ���� ����� ����� ����� ��� ������� � ��� ���� �� ��������� ������� �� ��� ������� ������� �������� � � ���� ������ ����� ������.</p>', '<p><br />����� ������ ��� ������ ������ �� ������� �������� ��� ������ (������� ������ ������ ����� ����� ������� ����� ������� , ����� ������ , ��� ���� , ������ ������� , ����� ������ ����� , ���� ���) ��� ���� �������� ����� �� ����� ������ ����� . <br /><br />� ���� ���� ������ ������� �� ���� ��� ������ � ��� �� ���� ������� ���� ������� ��� ���� ��� �������� ��� ����� ���� ������� ������ ��� ������ �� ���� �� ���� HTML .</p>\r\n<p align="center"><span style="font-size: medium; color: #cc3300;">�������� ���������</span></p>\r\n<p style="TEXT-ALIGN: right">����� ������ ��� ���� ����� �������� MYSQL � � �� �� ���� ��� ����� �������� ������� ������ � � ����� �� ����� ������� �������� ����� � ����� ��� PHP �������� ����� �� ��� ������ �� ���� ������ ������� � �������. <br /><br />��� ����� ������ ������� ��� ������ ������� ������� ������ �� ��� ������� �������� �������� � � ��� �� ���� ������ �� ����� � ��� ���� ����� ������� � ������� ��� ��� ������� �������� �� ���� ������� �������� �� ������. <br /><br />����� ������� ����� ��������� ������� � ���� �� ����� �������� � ����� �� ��� ��� ������� ������� ����������� ���� ������� � ������� �� ������� ���� � ��� �� ������� ���� ������� Templete ����� ��� ����� ������� CSS � ��� ���� ���� ���� � ���� �� ������ �������� ��� ����� �������. <br /><br />������ �� ������ ���� ������� ����������(���� &ndash; ����� &ndash; ������ ... ���) ����� ���� ������� ���� �� ���� ������� ������ ����� ����� ������� ����� ����� ��� ������ ��� 36 ����� �� ������ � ��� ���� ������ ��� �������� ��� ������� ��� ���� � �� ���� ������ ������ ������ ���� ����� �������� �������� . <br /><br />���� ������� ���� ������ ������ ������� � � ��� ����� ���� ������� ����� �� ���� ������� ���� ����� ����� GD ������� ���� php . <br /><br />������� ������� ������� ����� �� ������(������� ������ ������ ����� ����� ������� ����� ������� , ����� ������ , ��� ���� , ������ ������� , ����� ������ ����� , ���� ���)� � ���� ����� ������ ��� ������ ������� ��� ���� ����� ������ ����� �� ���������� �������� ���� �� ��� ������ ������� � ��� ����� ��� �������� ����� �� ������ ��� ������. <br /><br />�� ������ ����� ������ �� ����� ������ � ��� ������ �������� ����� ������ � �� ����� ��� � ����� ��������� �������� � ����� �� ����� ������ �� ������. <br /><br />����� �� ������ ������ ����� ����� � �� ������ ������ ������ � ���� �������� ������ ������� ���� HTML � � ���� ����� ���� ������ �� ����� ���� ���� �� ����� ���� ����� ���� ����� �� ������ ������� �� ��� ��� ����� �� ���� ������� � � ���� ����� �� ���� ���� ������ ��� ������ �������� ����� ������� ��� ����� ��� �������� ������ ���� ������� �������� ��� ����� ���� �� ������ �� ���� ������� � �� ��� ��� � ��� ���� ��� ������ ���� ������� ���� ����� �������� ��� ����� ������ ������ ����� � ������ �� ������ ����� �����. <br /><br />������ �� ������ ����� ������� ������� � � �� ��� ������� ����� ������� ����� ��� �� ����� �� ��� ������� ������ � ���� �� ����� ����� ��� ������� ������ <br /><br />�� �������� �������� ���� � ���� �� ��� ����� ������� ����� ��� ������ � ������� �������. <br /><br />���� ����� ������� ��� ������� ������� �� ������ � ���� ���� ������ �� ����� ����� ����� �� ����� ����� ����������� �� ��� ������� ������ �������� ������ �� ���� �� ��� ���� �������� ������� ������. <br /><br />������ ����� �� ������ �� ������ ���� ���� �������� �� ������ �� ����� �� ���� ����� ������ ��� ����� ��� ���� ��� ��� �� ����� ��� ����� ��� � ���� ( ���� ����� ����� ������ ����� ������� ������ �� �� ����) ��� ����� ������ ������ ���� ������� . � �� ����� �� ������ �� ����� �� ���� �� ����� ����� ��� ����� �������� ��� ����� ����� ����� � ��� �� ���� �������� ���� ����� �� ����� ����� ��� ����� ���� 24 ���� �������.�� ���� ���� �� ������� � ����� ����� ��� �������.</p>', 'yes', 1, 1, 1, 0, 5, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 1, 1234370646, 1, 1, 'admin@edit');

#------------------- TABLE rafia_online -------------------
DROP TABLE IF EXISTS rafia_online; 

CREATE TABLE rafia_online (
  id int(10) NOT NULL auto_increment,
  `timestamp` int(15) NOT NULL default '0',
  onlineip varchar(40) NOT NULL default '',
  onlinefile varchar(100) NOT NULL default '',
  onlinepage varchar(100) NOT NULL default '',
  onlineSID varchar(32) NOT NULL default '',
  user_online varchar(100) NOT NULL default '0',
  useronlineid int(11) NOT NULL default '0',
  user_agent varchar(255) NOT NULL default '',
  PRIMARY KEY  (onlineSID),
  KEY `timestamp` (`timestamp`),
  KEY user_online (user_online),
  KEY id (id),
  KEY onlineip (onlineip)
);


#------------------- TABLE rafia_pages -------------------
DROP TABLE IF EXISTS rafia_pages; 

CREATE TABLE rafia_pages (
  id int(10) unsigned NOT NULL auto_increment,
  name varchar(30) NOT NULL default '',
  popup int(1) NOT NULL default '0',
  checkuser int(1) NOT NULL default '0',
  active int(1) default '0',
  pagetext longtext NOT NULL,
  ishtml int(1) NOT NULL default '0',
  count int(10) NOT NULL default '0',
  showcount tinyint(1) NOT NULL default '0',
  showinmenu tinyint(1) NOT NULL default '1',
  lmenu_show tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (id)
);

INSERT INTO rafia_pages VALUES (1, '���� �������', 0, 0, 1, '<br>\r\n<br>\r\n<h3>��� ������ �������� ���</h3>\r\n<br>\r\n<br>\r\n', 0, 0, 1, 1,0);

#------------------- TABLE rafia_pollanswer -------------------
DROP TABLE IF EXISTS rafia_pollanswer; 

CREATE TABLE `rafia_pollanswer` (
  `pollid` int(11) NOT NULL auto_increment,
  `quesid` int(11) NOT NULL default '0',
  `text` varchar(255) NOT NULL default '',
  `results` int(10) NOT NULL default '0',
  PRIMARY KEY  (`pollid`)
) ;



#------------------- TABLE rafia_pollques -------------------
DROP TABLE IF EXISTS rafia_pollques; 

CREATE TABLE `rafia_pollques` (
  `quesid` int(11) NOT NULL auto_increment,
  `question` varchar(255) NOT NULL default '',
  `stat` int(1) NOT NULL default '0',
  PRIMARY KEY  (`quesid`)
) ;



#------------------- TABLE rafia_search_res -------------------
DROP TABLE IF EXISTS rafia_search_res; 

CREATE TABLE `rafia_search_res` (
  `id` mediumint(9) NOT NULL auto_increment,
  `search_id` text NOT NULL,
  `search_word` varchar(100) default NULL,
  `search_in` varchar(100) default NULL,
  `search_date` int(11) NOT NULL default '0',
  `from_date` int(11) NOT NULL default '0',
  `search_order` varchar(4) NOT NULL default 'desc',
  `search_max` int(10) NOT NULL default '0',
  `user_id` mediumint(10) default '0',
  `search_ip` varchar(64) default NULL,
  PRIMARY KEY  (`id`)
) ;


#------------------- TABLE rafia_sessions -------------------
DROP TABLE IF EXISTS rafia_sessions; 

CREATE TABLE `rafia_sessions` (
  `ses_id` varchar(32) NOT NULL default '',
  `ses_time` int(11) NOT NULL default '0',
  `ses_start` int(11) NOT NULL default '0',
  `ses_value` text NOT NULL,
  PRIMARY KEY  (`ses_id`)
) ;


#------------------- TABLE rafia_settings -------------------
DROP TABLE IF EXISTS rafia_settings; 

CREATE TABLE `rafia_settings` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `modulname` varchar(20) NOT NULL default '0',
  `titletype` int(10) NOT NULL default '0',
  `settingtype` int(2) NOT NULL default '0',
  `title` varchar(200) NOT NULL default '0',
  `variable` varchar(100) NOT NULL default '',
  `value` text,
  `options` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
);

INSERT INTO rafia_settings VALUES (1,0,1,1,'_SITE_TITLE','sitetitle','������� �������',30);
INSERT INTO rafia_settings VALUES (2,0,1,1,'_EMAIL','sitemail','xxxx@mail.com',30);
INSERT INTO rafia_settings VALUES (3,0,1,1,'_SITE_URL','siteURL','http://www.xxxx.com',30);
INSERT INTO rafia_settings VALUES (4,0,2,2,'_DATE_TYPE','hijri_date','m',5);
INSERT INTO rafia_settings VALUES (5,0,2,4,'_MEMEBER_REG_STATE','newuserallow','yes',1);
INSERT INTO rafia_settings VALUES (6,'link','','','_WEBLINK_MENU','link_menuid','1,2,3,4,5,6,8,9,11,12,16','');
INSERT INTO rafia_settings VALUES (7,0,2,4,'_USE_IMAGE_IN_SIG','use_sign_images','no',3);
INSERT INTO rafia_settings VALUES (8,0,2,6,'_GUSET_CAN_POST','gballow','wit',2);
INSERT INTO rafia_settings VALUES (9,'link',3,'','_WEBLINK_PERPAGE','linkperpagelist','20',50);
INSERT INTO rafia_settings VALUES (10,'news',1,'','_MAX_LENTH_IN_NEWS_FIRST_PART','txtcount1','5000',10);
INSERT INTO rafia_settings VALUES (11,'news',1,'','_MAX_LENTH_IN_2_PART','txtcount2','30000',10);
INSERT INTO rafia_settings VALUES (12,'forum',1,'','_MAX_LENTH_IN_TOPIC_TITLE','txtcount3','30000',10);
INSERT INTO rafia_settings VALUES (13,'down',1,'','_MAX_DOWNLOAD_REVIEW','txtcount4','30000',10);
INSERT INTO rafia_settings VALUES (14,0,1,'','_MAX_DEIS_LINK_GUEST','txtcount5','1000',10);
INSERT INTO rafia_settings VALUES (15,0,1,'','_MAX_IN_POSTS','txtcount6','30000',10);
INSERT INTO rafia_settings VALUES (16,0,1,4,'_MAX_LENTH_IN_SIG','txtcount7','300',10);
INSERT INTO rafia_settings VALUES (17,0,3,6,'_GUEST_PERPAGE','gbperpagelist','25',50);
INSERT INTO rafia_settings VALUES (18,'news',3,'','_NEWS_PERPAGE','newsperpagelist','12',50);
INSERT INTO rafia_settings VALUES (19,0,3,6,'_NEWS_IN_MAIN','showmax','6',20);
INSERT INTO rafia_settings VALUES (20,'news',3,'','_NEWS_POSTS_IN_PERPAGE','newsperpagecomment','10',30);
INSERT INTO rafia_settings VALUES (21,'news',3,'','_NUMBER_OF_NEWS_IN','showmaxr','20',30);
INSERT INTO rafia_settings VALUES (22,0,1,3,'_ACTIVE_TITLE','subject_activate','����� �������� ��� ���� $apt->sitetitle',40);
INSERT INTO rafia_settings VALUES (23,0,1,'','_MAX_LENTH_IN_TOPIC_TITLE','max_title_cut','100',5);
INSERT INTO rafia_settings VALUES (24,0,1,'','_UPLOAD_PATH','upload_path','upload','');
INSERT INTO rafia_settings VALUES (25,0,4,3,'_FEEDBACK_TITLES','mailsubject','�������\r\n���\r\n������� ��� ���',6);
INSERT INTO rafia_settings VALUES (26,0,2,3,'_SENDTOME_BY','sendme_by','cp',8);
INSERT INTO rafia_settings VALUES (27,0,1,3,'_ALERT_NEW_MSG','subject_alert','��� $name ��� ��� �������� $titlepost',40);
INSERT INTO rafia_settings VALUES (28,0,1,4,'_MAX_LENTH_IN_PMSG','txtcount8','2000',10);
INSERT INTO rafia_settings VALUES (29,0,1,4,'_MAX_PMSG','maxpmuser','50',10);
INSERT INTO rafia_settings VALUES (30,'forum',3,'','_FORUM_POSTS_PERPAGE','forumperpagecomment','10',30);
INSERT INTO rafia_settings VALUES (31,'forum',3,'','_CAT_LISTTHRAEDS_PERPAGE','forumperpagelist','30',50);
INSERT INTO rafia_settings VALUES (32,'forum',1,'','_MAX_TIME_EDIT','timeallowedit','3600',10);
INSERT INTO rafia_settings VALUES (33,'forum',1,'','_EXIT_ALLOWED','forumfileupload','jpg,gif,png,php,zip,pdf','');
INSERT INTO rafia_settings VALUES (34,'forum',1,'','_MAX_SIZE_FORUM_ATTACHMENT','forumfilemxsize','300',10);
INSERT INTO rafia_settings VALUES (35,'down',3,'','_FORUM_POSTS_PERPAGE','downperpagecomment','10',50);
INSERT INTO rafia_settings VALUES (36,'down',3,'','_DOWNLOAD_PERPAGE','downperpagelist','16',50);
INSERT INTO rafia_settings VALUES (37,'news',1,'','_EXS_IMG_ALLOWED','newsfileupload','jpg,gif,png','');
INSERT INTO rafia_settings VALUES (38,'down',1,'','_EXIT_ALLOWED','downfileupload','zip,rar,tar,gz','');
INSERT INTO rafia_settings VALUES (39,'news',1,'','_MAX_ADD_IMAGE_NEWS','newsfilemxsize','100','');
INSERT INTO rafia_settings VALUES (40,0,4,'','_SEND_TO_FRINDE_CONTENT','sendpage','_SEND_TO_FRINDE_SUB',6);
INSERT INTO rafia_settings VALUES (41,'down',1,'','_MAX_DOWNLOAD_DEIS','txtcount9','300',10);
INSERT INTO rafia_settings VALUES (42,'down','','','_DOWNLOAD_MENU','down_menuid','1,2,3,4,5,6,8,10,12,14,15',10);
INSERT INTO rafia_settings VALUES (43,'news','','','_NEWS_MENUS','news_menuid','1,2,3,4,5,6,8,9,10,11,12,16,18','');
INSERT INTO rafia_settings VALUES (44,0,1,2,'_HOURS_GM','dtimehour','2',4);
INSERT INTO rafia_settings VALUES (46,'down',1,'','_MAX_DOWNLOAD_SZIE','downfilemxsize','500','');
INSERT INTO rafia_settings VALUES (47,0,1,3,'_LOGIN_TITLE','subject_remind','������ ����� �����',40);
INSERT INTO rafia_settings VALUES (48,0,1,3,'_ALERT_BROKEN_URL','subject_alertlink','����� �� ���� �����',40);
INSERT INTO rafia_settings VALUES (49,0,1,3,'_SEND_TO_FRINDE_TITLE','subject_sendpage','����� �� �����',40);
INSERT INTO rafia_settings VALUES (50,0,2,4,'_USE_LINKS_IN_SIG','use_sign_linkcode','yes',3);
INSERT INTO rafia_settings VALUES (51,0,2,4,'_USE_BBCODE_IN_SIG','use_sign_fontcode','yes',3);
INSERT INTO rafia_settings VALUES (52,'link',1,'','_MAX_WEBLINK_DEIS','txtcount10','500',10);
INSERT INTO rafia_settings VALUES (53,0,1,5,'_MAX_COMMENT_SZIE','commentfilemxsize','1000','');
INSERT INTO rafia_settings VALUES (54,0,1,5,'_EXT_COMMENT','commentfileupload','jpg,gif,zip,php,doc,txt,asx,mp3,js,ram,html,htm',40);
INSERT INTO rafia_settings VALUES (55,0,1,5,'_SHOW_COLORED','sizephpcode','10000','');
INSERT INTO rafia_settings VALUES (56,0,1,5,'_SMALL_IMAGE_IF','resizedimage','450','');
INSERT INTO rafia_settings VALUES (57,0,1,3,'_ALERT_NEW_MSG','alert_pm','����� ����� ����',40);
INSERT INTO rafia_settings VALUES (58, 'news', 4, 0, '_HTML_TAGS', 'html_tags', '<P><A><IMG><TABLE><TBODY><TR><TD><SPAN>\r\n<U><I><OL><LI><FONT><UL>\r\n<STRONG><EM><B><BR><EMBED>\r\n<DIV><DEL><INS>', 6);
INSERT INTO rafia_settings VALUES (59,'news',2,'','_USE_ADS_IN_NEWS','use_adsin_news','yes',3);
INSERT INTO rafia_settings VALUES (60,'forum',2,'','_USE_ADS_IN_FORUM','use_adsin_forum','yes',3);
INSERT INTO rafia_settings VALUES (61,'down',2,'','_USE_ADS_IN_WEBLINK','use_adsin_download','yes',3);
INSERT INTO rafia_settings VALUES (62,0,'','','','index_menuid','1,2,3,4,5,6,8,9,10,11,12,13,16,17,18,19','');
INSERT INTO rafia_settings VALUES (63,'news',1,'','_DEFULT_ALIGN_FOR_IMG_DEFULT_ALIGN_FOR_IMG','CatMagealign','right',10);
INSERT INTO rafia_settings VALUES (64,'news',5,'','_USE_HTML_EDITOR','ues_editor','','');
INSERT INTO rafia_settings VALUES (65,'news',5,'','_USE_LEFT_MENU','news_left_menu','1','');
INSERT INTO rafia_settings VALUES (66,'down',5,'','_USE_LEFT_MENU','down_left_menu','1','');
INSERT INTO rafia_settings VALUES (67,'link',5,'','_USE_LEFT_MENU','link_left_menu','1','');
INSERT INTO rafia_settings VALUES (68,0,3,6,'_NEWS_IN_MAIN_COL','indexColcount','2',3);
INSERT INTO rafia_settings VALUES (69,'news',3,'','_CAT_COL_VIEW','newsColcount','2',4);
INSERT INTO rafia_settings VALUES (70,'link',3,'','_CAT_COL_VIEW','linkColcount','2',4);
INSERT INTO rafia_settings VALUES (71,'down',3,'','_CAT_COL_VIEW','downColcount','2',4);
INSERT INTO rafia_settings VALUES (72,'hidden','','','','version','Arab Portal v2.2 stable','');
INSERT INTO rafia_settings VALUES (73,0,1,7,'_KEYWORDS','keywords','������� �������',20);
INSERT INTO rafia_settings VALUES (74,0,1,7,'_DESCRIPTION','Description','������� ������� -Powered by: Arab Portal v2.2, Copyright� 2008',40);
INSERT INTO rafia_settings VALUES (75,'news',2,'','_POST_ORDER_BY','news_order_by','date_time',6);
INSERT INTO rafia_settings VALUES (76,'forum',2,'','_POST_ORDER_BY','forum_order_by','timestamp',6);
INSERT INTO rafia_settings VALUES (77,0,2,1,'_TURN_OFF','turn_off','no',3);
INSERT INTO rafia_settings VALUES (78,0,1,1,'_TURN_OFF_MSG','turn_off_msg','������ ���� ����� ������� ... �� �����',50);
INSERT INTO rafia_settings VALUES (79,0,10,'','_THEME','theme','portal','');
INSERT INTO rafia_settings VALUES (80,0,2,6,'_MAIN_PAGE_FORM','main_form','formB',9);
INSERT INTO rafia_settings VALUES (81, 'news', 1, 0, '_TRANS_GOOGLE_IP', 'googleIP', '74.125.95.113', 20); 
INSERT INTO rafia_settings VALUES (82,'hidden','','','','mail_msg','������ ����� ����� ���� ������� \r\n','');
INSERT INTO rafia_settings VALUES (83,'hidden','','','','mail_vars','50:=:0:=:xxx@mail.com:=:','');
INSERT INTO rafia_settings VALUES (84,0,4,6,'_BAD_WORDS','bad_words','���',6);
INSERT INTO rafia_settings VALUES (85,0,4,6,'_PAN_IP','pan_ip','',6);
INSERT INTO rafia_settings VALUES (86,0,3,1,'_COUNT_MIDDLE_MENU','count_middle_menu','2',4);
INSERT INTO rafia_settings VALUES (87,0,2,5,'_USE_GD_THUMB','use_gd_thumb','yes',3);
INSERT INTO rafia_settings VALUES (88,'hidden','','','','captcha_code','1190721969:|:888850','');
INSERT INTO rafia_settings VALUES (89,'news',1,'','_DEFULT_GD_WIDTH_IMG','thumb_width','100',10);
INSERT INTO rafia_settings VALUES (90,0,2,7,'_HTML_LINKS','html_links','No',3);
INSERT INTO rafia_settings VALUES (91, '0', 1, 4, '_WT_AVATAR', 'wt_avatar', '200', 10);
INSERT INTO rafia_settings VALUES (92, '0', 1, 4, '_HT_AVATAR', 'ht_avatar', '200', 10);
INSERT INTO rafia_settings VALUES (93, '0', 4, 4, '_REG_RULES', 'reg_rules', '<li>������� ����� ����� ������ ��� �� ���\r\n<li>��� ������ �� ������ ������ ��� ������� ��� ���� ������ \r\n<li>��� �������� ���� �� ���� ���� �� �����.\r\n<li>��� �������� ��� �� ���� ���� �� ����� ����.\r\n<li>���� ������ ��� �� ���� ���� �� ����� ����.\r\n<li>����� �������� ������ ������ ���� ��� ������ �� ��� ������. \r\n<li>������ ����� ����� ������� ����� � �� ������ ������ �������� ������� ����� �� (<font color="#FF0000">*</font>)', 6);


#------------------- TABLE rafia_smileys -------------------
DROP TABLE IF EXISTS rafia_smileys; 

CREATE TABLE `rafia_smileys` (
  `id` int(11) NOT NULL auto_increment,
  `code` varchar(50) default NULL,
  `smile` varchar(100) default NULL,
  `smilename` varchar(75) default NULL,
  PRIMARY KEY  (`id`)
) ;

INSERT INTO rafia_smileys VALUES (1,':TON:','tongue.gif','TO');
INSERT INTO rafia_smileys VALUES (2,':COO:','cool.gif','cool');
INSERT INTO rafia_smileys VALUES (3,':DRY:','dry.gif','dry');
INSERT INTO rafia_smileys VALUES (4,':ARB:','Arabian.gif','����');
INSERT INTO rafia_smileys VALUES (5,':MAD:','mad.gif','mad');
INSERT INTO rafia_smileys VALUES (6,':WOW:','ohmy.gif','ohmy');
INSERT INTO rafia_smileys VALUES (7,':HuH:','huh.gif','huh');
INSERT INTO rafia_smileys VALUES (8,':SAD:','sad.gif','sad');
INSERT INTO rafia_smileys VALUES (9,':SMI:','smile.gif','smile');
INSERT INTO rafia_smileys VALUES (11,':WUB:','wub.gif','wub');


#------------------- TABLE rafia_spam -------------------
DROP TABLE IF EXISTS rafia_spam; 

CREATE TABLE `rafia_spam` (
  `spamip` varchar(32) NOT NULL default '0',
  `spamtable` varchar(30) NOT NULL default '',
  `spamtime` int(10) NOT NULL default '0',
  PRIMARY KEY  (`spamip`)
) ;


#------------------- TABLE rafia_templates -------------------

DROP TABLE IF EXISTS rafia_templates;
CREATE TABLE rafia_templates (
  id int(10) unsigned NOT NULL auto_increment,
  theme varchar(100) NOT NULL default '',
  `name` varchar(30) NOT NULL default '',
  temptype int(2) NOT NULL default '0',
  template longtext NOT NULL,
  PRIMARY KEY  (id)
);

#
# Dumping data for table `rafia_templates`
#

INSERT INTO rafia_templates VALUES (1, 'portal', 'news_topic_list', 2, '<table border="0" cellpadding="0" cellspacing="0" width="95%">\r\n	<tr>\r\n		<td height="28">\r\n		<div class="news_title">\r\n			<img border="0" src="themes/$apt->themepath/news_icon.gif" width="12" height="12">\r\n			<a href="$news_link">$title</a></div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td width="100%">\r\n		<table border="0" cellpadding="2" style="border-collapse: collapse" width="100%" id="AutoNumber1" class="article_info">\r\n			<tr>\r\n				<td align="right" width="100%">\r\n				<div class="article_info">\r\n					<img border="0" src="themes/$apt->themepath/info.gif" width="13" height="18"> \r\n					������: <a href="members.php?action=info&userid=$userid">$name</a> \r\n					������: $date </div>\r\n				</td>\r\n				<td nowrap align="left" colspan="3"></td>\r\n			</tr>\r\n		</table>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td width="100%" style="padding-top: 5; padding-bottom: 5; text-align: justify">\r\n		$newsimage <font class="home_text">$news_head </font></td>\r\n	</tr>\r\n	<tr>\r\n		<td align="right" width="100%" class="info_bar2" style="padding-top: 5; padding-bottom: 5">\r\n		<p align="right"><a href="$news_link">\r\n		<img border="0" src="themes/$apt->themepath/readmore.gif" align="right"></a>\r\n		</p>\r\n		<div class="article_info">\r\n&nbsp; ������: $reader&nbsp;&nbsp;&nbsp; ���������: $numrows </div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td width="100%">$pagenum </td>\r\n	</tr>\r\n</table>\r\n<hr color="#C0C0C0" width="95%" size="1" style="border-style: dotted; border-width: 1px">');
INSERT INTO rafia_templates VALUES (2, 'portal', 'link_cat', 5, '<table border="0" cellpadding="0" cellspacing="0" width="100%">\r\n	<tr>\r\n		<td width="100%" style="padding: 3"><font class="fonthtd">\r\n		<img border="0" src="images/b1.gif" align="middle" width="8" height="8">\r\n		<a href="$PHP_SELF?action=list&amp;cat_id=$id"><font size="4">$title</font></a></font>\r\n		<span class="fontablt">\r\n		<img border="0" src="images/topics.gif" align="middle" alt="��� ��������">\r\n		<font color="#C0C0C0">[$numrows] </font></span></td>\r\n	</tr>\r\n	<tr>\r\n		<td width="100%" class="fontablt"><font color="#808080">$dsc</font></td>\r\n	</tr>\r\n</table>');
INSERT INTO rafia_templates VALUES (3, 'portal', 'forum_topic_list', 3, '<tr>\r\n<td class="forum_alt2"><img border="0" src="themes/$apt->themepath/$imgonoff"></td>\r\n<td class="forum_alt1">$rep_icon</td>\r\n<td width="100%" class="forum_alt4">\r\n<div style="float: left; width: 13px; height:13px">$uploadimage</div>\r\n<a href="forum.php?action=view&id=$id">\r\n<font color="#34597D">$title</font> </a>$pagenum </td>\r\n<td class="forum_alt1" align="center">$numrows</td>\r\n<td class="forum_alt2" align="center">$name</td>\r\n<td class="forum_alt1" align="center">$reader</td>\r\n<td class="forum_alt2" width="200" nowrap=""><span class="small">����� ��� ������:\r\n<br>\r\n$lastdate <br>\r\n������ : $lastposter </span></td>\r\n</tr>');
INSERT INTO rafia_templates VALUES (4, 'portal', 'forum_table', 3, '<table border="0" width="95%" id="table4" cellspacing="1" cellpadding="0">\r\n	<tr>\r\n		<td width="100%" class="forum_header" style="text-align: right">$rep_icon \r\n		� $title</td>\r\n	</tr>\r\n	<tr>\r\n		<td width="100%" class="forum_alt3">\r\n		<table border="0" width="100%" id="table16" cellspacing="5" cellpadding="3">\r\n			<tr>\r\n				<td width="20%" class="forum_alt15" valign="top" bgcolor="#DFE9F4" rowspan="2">\r\n				<div align="center">\r\n					<table border="0" cellpadding="0" style="border-collapse: collapse" width="140" cellspacing="3">\r\n						<tr>\r\n							<td>\r\n							<p align="center"><font face="Tahoma">\r\n							<font size="2" color="#800000">&nbsp; ������ :\r\n							</font>\r\n							<a href="members.php?action=info&amp;userid=$userid">\r\n							<font size="2" color="#800000">$username</font></a></span></font></p>\r\n							</td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n							<div align="center">\r\n								<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%" bordercolor="#7394B6" cellspacing="4">\r\n									<tr>\r\n										<td>\r\n										<p align="center">\r\n										<font face="Tahoma" size="2">\r\n										<span class="small">$grouptitle<br>$usertitle</span></font></p>\r\n										</td>\r\n									</tr>\r\n									<tr>\r\n										<td>\r\n										<div align="center">\r\n											<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%" cellspacing="2">\r\n												<tr>\r\n													<td>\r\n													<p align="center">\r\n													<span class="small">\r\n													<font size="2" face="Tahoma">\r\n													$userimgtitle</font></span></p>\r\n													</td>\r\n												</tr>\r\n											</table>\r\n										</div>\r\n										</td>\r\n									</tr>\r\n									<tr>\r\n										<td>\r\n										<div align="center">\r\n								\r\n$avatar_pic</p>$userstatus\r\n\r\n</div>\r\n										</td>\r\n									</tr>\r\n								</table>\r\n							</div>\r\n							</td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n							<div align="center">\r\n								<table border="1" cellpadding="0" style="border-collapse: collapse" width="100%" bordercolor="#7394B6">\r\n									<tr>\r\n										<td bgcolor="#F5F5F5">\r\n										<p align="center"><span class="small">\r\n										<font size="2" face="Tahoma">��������� : \r\n										$allposts</font></span></p>\r\n										</td>\r\n									</tr>\r\n								</table>\r\n							</div>\r\n							</td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n							<div align="center">\r\n								<table border="1" cellpadding="0" style="border-collapse: collapse" width="100%" bordercolor="#7394B6">\r\n									<tr>\r\n										<td bgcolor="#F5F5F5">\r\n										<p align="center">\r\n										<font face="Tahoma" size="2">\r\n										<span class="small"><span lang="ar-iq">�����</span> \r\n										�������<br>\r\n&nbsp;$datetime</span></font></p>\r\n										</td>\r\n									</tr>\r\n								</table>\r\n							</div>\r\n							</td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n							<p align="center">&nbsp;</p>\r\n							</td>\r\n						</tr>\r\n					</table>\r\n				</div>\r\n				<p align="center"><span class="small">\r\n				<a href="mail.php?action=sendtousers&amp;userid=$userid">\r\n				<img border="0" src="themes/$apt->themepath/email.gif" alt="������">\r\n				</a><a href="$homepage" target="_blank">\r\n				<img border="0" src="themes/$apt->themepath/home.gif" alt="������ ������"></a>\r\n<br>\r\n<a href="mail.php?action=report&id=$id" title="���� �� ��� ��������"><img border="0" src="images/report.gif"></a>\r\n				</span></p>\r\n</td>\r\n<td width="80%" valign="top" class="normal" colspan="2">\r\n				<p align="right"><span class="small"><font color="#808080">&nbsp;��� \r\n				�� $date - ������ : $reader - ���� : $c_comment </font></span>\r\n				</p>\r\n				<hr color="#7394B6" size="1">\r\n				<p align="right">$post <br><br>\r\n\r\n	$upload_file\r\n&nbsp;</p>\r\n				<div align="center">\r\n					<table border="0" cellpadding="0" style="border-collapse: collapse" width="90%">\r\n						<tr>\r\n							<td><fieldset style="padding: 2">\r\n							<legend>����� ( <span class="small">\r\n							<a href="members.php?action=info&amp;userid=$userid">\r\n							$username</a></span> )</legend>\r\n							<div align="center">\r\n								<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%" cellspacing="3">\r\n									<tr>\r\n										<td><center>$signature</center></td>\r\n									</tr>\r\n								</table>\r\n							</div>\r\n							</fieldset></td>\r\n						</tr>\r\n					</table>\r\n				</div>\r\n				</td>\r\n			</tr>\r\n			<tr>\r\n				<td width="40%" valign="top" class="small">$adminJump </td>\r\n				<td width="40%" valign="top" align="left">\r\n				<a href="pm.php?action=sendmsg&amp;id=$userid">\r\n				<img border="0" src="themes/$apt->themepath/pm.gif"> </a>\r\n\r\n$edit_post\r\n				<a href="forum.php?action=addcomment&amp;id=$id&amp;qp=1">\r\n<img border="0" src="themes/$apt->themepath/quote.gif"></a> \r\n</td>\r\n			</tr>\r\n		</table>\r\n		</td>\r\n	</tr>\r\n</table>\r\n<!--INC dir="block" file="ads.php" -->');
INSERT INTO rafia_templates VALUES (5, 'portal', 'members_pm_link', 6, '<center>\r\n<table border="0" width="304">\r\n	<tr>\r\n		<td width="76" bgcolor="$bgcolor5">\r\n		<p align="center"><a href="pm.php?box=1">\r\n		<img border="0" src="themes/$apt->themepath/pr_inbox.jpg" width="76" height="56"></a></p>\r\n		</td>\r\n		<td width="76" bgcolor="$bgcolor5">\r\n		<p align="center"><a href="pm.php?box=2">\r\n		<img border="0" src="themes/$apt->themepath/pr_outbox.jpg" width="76" height="56"></a></p>\r\n		</td>\r\n		<td width="76" bgcolor="$bgcolor5">\r\n		<p align="center"><a href="pm.php?box=3">\r\n		<img border="0" src="themes/$apt->themepath/pr_save.jpg" width="76" height="56"></a></p>\r\n		</td>\r\n		<td width="76" bgcolor="$bgcolor5">\r\n		<p align="center"><a href="members.php?action=edit">\r\n		<img border="0" src="themes/$apt->themepath/setting.jpg" width="76" height="56"></a></p>\r\n		</td>\r\n	</tr>\r\n</table>\r\n</center>');
INSERT INTO rafia_templates VALUES (6, 'portal', 'link_list', 5, '<div align="center">\r\n	<table border="0" cellpadding="0" cellspacing="0" width="95%">\r\n		<tr>\r\n			<td width="17" bgcolor="#516A93"></td>\r\n			<td class="info_barff" width="100%" bgcolor="#516A93">\r\n			<p align="right">&nbsp;\r\n			<img border="0" src="themes/$apt->themepath/weblinkenter.gif">&nbsp;\r\n			<a target="_blank" href="$PHP_SELF?action=goto&amp;id=$id">\r\n			<font color="#FFFFFF" size="4">$title </font></a></p>\r\n			</td>\r\n		</tr>\r\n	</table>\r\n</div>\r\n<div align="center">\r\n	<table border="0" width="95%" bgcolor="#ffffff" cellspacing="0" cellpadding="0">\r\n		<tr>\r\n			<td width="32%" valign="top" bgcolor="#F1F9FE">\r\n			<div align="center">\r\n				<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%" cellspacing="5">\r\n					<tr>\r\n						<td>\r\n						<p align="right"><font face="Tahoma" color="#800000">\r\n						<font class="fontablt"><font size="2">�������� : $clicks\r\n						</font></font><font size="2"><br>\r\n						�������: $rating_avg&nbsp;&nbsp; <br>\r\n						<font class="fontablt">�������: $ratings</font> <br>\r\n						</font><font class="fontablt"><font size="2">������ : $name\r\n						</font></font></font></p>\r\n						</td>\r\n					</tr>\r\n				</table>\r\n			</div>\r\n			</td>\r\n			<td height="100%" valign="top">\r\n			<table border="0" cellpadding="0" cellspacing="0" width="100%">\r\n				<tr>\r\n					<td valign="top">\r\n					<div align="center">\r\n						<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%" cellspacing="5">\r\n							<tr>\r\n								<td>\r\n								<p align="right"><font class="fontablt">$post</font>\r\n								</p>\r\n								</td>\r\n							</tr>\r\n						</table>\r\n					</div>\r\n					</td>\r\n				</tr>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td width="32%" valign="top" bgcolor="#F1F9FE">&nbsp;</td>\r\n			<td height="100%" valign="top" bgcolor="#F8F8F8">\r\n			<font face="Tahoma" size="2" color="#800000">&nbsp;\r\n			<img border="0" src="themes/$apt->themepath/world.png" width="12" height="12"><span lang="ar-iq"><font color="#800000">\r\n			<span style="text-decoration: none">\r\n			<a target="_blank" href="$PHP_SELF?action=goto&amp;id=$id">\r\n			<font color="#800000"><span style="text-decoration: none">������ ������</span></font></a></span></font>&nbsp; \r\n			|&nbsp;\r\n			<img border="0" src="themes/$apt->themepath/chart_bar.png" width="12" height="12"></span><font color="#800000">\r\n			<span lang="ar-iq" style="text-decoration: none">\r\n			<a href="javascript:rafiawin(\'popup.php?action=ratek&id=$id\',200,400)">\r\n			<font color="#800000"><span style="text-decoration: none">����� ������</span></font></a></span></font><span lang="ar-iq">&nbsp; \r\n			|&nbsp;\r\n			<img border="0" src="themes/$apt->themepath/link_break.png" width="12" height="12"></span><font color="#800000">\r\n			<span lang="ar-iq" style="text-decoration: none">\r\n			<a href="javascript:rafiawin(\'popup.php?action=alertl&id=$id\',200,400)">\r\n			<font color="#800000"><span style="text-decoration: none">���� ����</span></font></a></span></font><span lang="ar-iq">&nbsp; \r\n			|&nbsp;\r\n			<img border="0" src="themes/$apt->themepath/page_white_edit.png" width="12" height="12"></span><font color="#800000">\r\n			<span style="text-decoration: none">\r\n			<a href="$PHP_SELF?action=edit&amp;id=$id"><span lang="ar-iq">\r\n			<font color="#800000"><span style="text-decoration: none">�����</span></font></span></a></span></font></font></td>\r\n		</tr>\r\n	</table>\r\n</div>\r\n<hr color="#C0C0C0" width="95%" size="1">');
INSERT INTO rafia_templates VALUES (7, 'portal', 'show_members', 6, '<br>\r\n<div align="center">\r\n<table border="0" width="90%" cellspacing="5" cellpadding="5"><tr><td>\r\n<table class="letter_table" dir="ltr" width="100%" height="30"><tr>$english_letters</tr></table></td></tr>\r\n<tr><td>\r\n<table class="letter_table" width="100%" height="30"><tr>$arabic_letters</tr></table></td></tr>\r\n<tr><td>\r\n<table width="100%"><tr><td  width="15%"><b><font class=articles_info>\r\n���� �� ���: </font></td><td>\r\n<form method="post" action="members.php?action=msearch">\r\n<input type="text" name="membername" size="30">\r\n<input type="submit" value="����" class="button">\r\n</form>\r\n</td></tr></table>\r\n\r\n</td></tr></table>\r\n\r\n\r\n<table table border="1" width="90%" cellspacing="0" cellpadding="0" width="70%" style="border-collapse: collapse"><tr>\r\n<td class="forum_header" width="5%" bgcolor="$color"><font class=articles_info>  �����</font></td>\r\n      <td class="forum_header" width="40%" bgcolor="$color"><font class=articles_info>  \r\n��� ������</font></td>\r\n      <td class="forum_header" width="20%" bgcolor="$color"><font class=articles_info>  ��� ���������</font></td>\r\n<td class="forum_header" width="25%" bgcolor="$color"><font class=articles_info>  ����� �������</font></td>\r\n      <td class="forum_header"  width="10%" bgcolor="$color" align="center"><font class=articles_info>  \r\n������\r\n  </font></td></tr>\r\n$show_members_list\r\n<tr>\r\n<td class="forum_header" colspan="5" style="text-align: left">\r\n\r\n\r\n<form method="get" action="members.php">\r\n<span class=small>\r\n����� ������� ���� <select name="morder" size="1">\r\n<option value="userid" selected>����� �������</option>\r\n<option value="username">�����</option>\r\n<option value="usergroup">��������</option>\r\n<option value="topics">��� ���������</option>\r\n<option value="regdate">����� �������</option>\r\n</select><select name="msort" size="1">\r\n<option value="DESC" selected>��������</option>\r\n<option value="ASC">��������</option>\r\n\r\n</select> \r\n<input type="submit" value="�� ��������" class="button">\r\n</span>\r\n\r\n</td>\r\n</tr>\r\n</table>\r\n</div>');
INSERT INTO rafia_templates VALUES (8, 'portal', 'download_cat', 4, '<table border="0" cellpadding="0" cellspacing="0" width="100%">\r\n	<tr>\r\n		<td width="100%" style="padding: 3">\r\n		<img border="0" src="images/b1.gif" align="middle" width="8" height="8">\r\n		<span dir="RTL" class="fonthtww">\r\n		<a href="download.php?action=list&amp;cat_id=$id"><font size="4">$title</font></a></font></span>\r\n		<span class="fontablt">\r\n		<img border="0" src="images/topics.gif" align="middle" alt="��� �������">\r\n		<font color="#C0C0C0">[$numrows] </font></span></td>\r\n	</tr>\r\n	<tr>\r\n		<td width="100%" class="fontablt">\r\n		<blockquote>\r\n			<font color="#808080">$dsc</font></blockquote>\r\n		</td>\r\n	</tr>\r\n</table>\r\n<hr color="#000000" size="1" width="90%">');
INSERT INTO rafia_templates VALUES (9, 'portal', 'download_table', 4, '<div align="center">\r\n	<table border="0" width="98%" id="table3" cellspacing="0" cellpadding="0">\r\n		<tr>\r\n			<td class="forum_header">������� �� ��������</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<table border="1" width="100%" id="table4" cellpadding="4" class="fontablt" style="border-collapse: collapse" bordercolor="#D0DFF0" cellspacing="3">\r\n				<tr>\r\n					<td nowrap="" class="info_bar" bgcolor="#F4FCFF" align="right">\r\n					��� ��������:</td>\r\n					<td width="100%" bgcolor="#F4FCFF" align="right">$title</td>\r\n				</tr>\r\n				<tr>\r\n					<td nowrap="" class="info_bar" bgcolor="#F8F8F8" align="right">\r\n					�����:</td>\r\n					<td width="100%" bgcolor="#F8F8F8" align="right">$size</td>\r\n				</tr>\r\n				<tr>\r\n					<td nowrap="" class="info_bar" bgcolor="#F4FCFF" align="right">\r\n					���� �������:</td>\r\n					<td width="100%" bgcolor="#F4FCFF" align="right">$clicks</td>\r\n				</tr>\r\n				<tr>\r\n					<td nowrap="" class="info_bar" bgcolor="#F8F8F8" align="right">\r\n					�������:</td>\r\n					<td width="100%" bgcolor="#F8F8F8" align="right">$ratings</td>\r\n				</tr>\r\n				<tr>\r\n					<td nowrap="" class="info_bar" bgcolor="#F4FCFF" align="right">\r\n					�������:</td>\r\n					<td width="100%" bgcolor="#F4FCFF" align="right">\r\n					<font class="fontablt">$rating_avg</font></td>\r\n				</tr>\r\n				<tr>\r\n					<td nowrap="" class="info_bar" bgcolor="#F8F8F8" align="right">\r\n					����� �������:</td>\r\n					<td width="100%" bgcolor="#F8F8F8" align="right">$date</td>\r\n				</tr>\r\n				<tr>\r\n					<td nowrap="" class="info_bar" bgcolor="#F4FCFF" align="right">\r\n					������ �������</td>\r\n					<td width="100%" bgcolor="#F4FCFF" align="right">$formmember</td>\r\n				</tr>\r\n				<tr>\r\n					<td nowrap="" class="info_bar" bgcolor="#F8F8F8" align="right">\r\n					�����:</td>\r\n					<td width="100%" align="right">$post_head <hr>$post </td>\r\n				</tr>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td width="100%">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td align="left">\r\n			<p align="right">$action <font class="fontablt">\r\n			<img border="0" src="themes/$apt->themepath/download.gif"> </font></a>\r\n			<a href="javascript:rafiawin(\'popup.php?action=alert&id=$id\',200,400)">\r\n			<img border="0" src="themes/$apt->themepath/hidlink.gif"></a>\r\n			<a href="javascript:rafiawin(\'popup.php?action=rated&id=$id\',200,400)">\r\n			<img border="0" src="themes/$apt->themepath/rank.gif"></a>\r\n			<a href="download.php?action=edit&amp;id=$id">\r\n			<img border="0" src="themes/$apt->themepath/edit.gif"></a> </p>\r\n			</td>\r\n		</tr>\r\n	</table>\r\n</div>');
INSERT INTO rafia_templates VALUES (10, 'portal', 'forum_main', 3, '$pagehd\r\n<div align="center">\r\n	<table border="0" cellpadding="0" style="border-collapse: collapse" width="$themewidth">\r\n		<tr>\r\n			<td width="30">\r\n			<img border="0" src="themes/$apt->themepath/last_teat_04.gif"></td>\r\n			<td width="100%" background="themes/$apt->themepath/last_teat_02.gif">\r\n			<!--INC dir="block" file="last_10_forum.php" --></td>\r\n			<td width="25">\r\n			<img border="0" src="themes/$apt->themepath/last_teat_01.gif"></td>\r\n		</tr>\r\n	</table>\r\n</div>\r\n<div align="center">\r\n	<table border="0" cellpadding="0" style="border-collapse: collapse" width="$themewidth">\r\n		<tr>\r\n			<td bgcolor="#516A93" width="18">&nbsp;</td>\r\n			<td>\r\n			<html dir="rtl">\r\n\r\n			<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0">\r\n\r\n			<center>\r\n			<table border="0" cellpadding="0" cellspacing="0" width="100%" height="100%" bgcolor="#FFFFFF">\r\n				<tr>\r\n					<td width="100%" valign="top" style="padding: 5px" class="forum_control_bar">\r\n					<div style="float: right">\r\n						$users_tools</div>\r\n					<div style="float: left; width: 234px; height: 27px">\r\n						<form name="search_form" action="search.php" method="post" style="margin: 0px; padding: 0px">\r\n							<input type="text" name="searchfor" size="14"><input type="hidden" name="searchin" value="rafia_forum">\r\n							<input class="button" type="submit" name="submit" value="���">\r\n							<a href="search.php?action=search">��� �����</a>&nbsp;&nbsp;\r\n						</form>\r\n					</div>\r\n					</td>\r\n				</tr>\r\n				<tr>\r\n					<td width="100%" valign="top" align="center" style="padding: 5px" height="100%">\r\n					<center>$ads_head </center>\r\n\r\n$forum_middle </td>\r\n				</tr>\r\n			</table>\r\n			</center><center>$ads_foot</center></td>\r\n			<td bgcolor="#516A93" width="19">&nbsp;</td>\r\n			</tr>\r\n		</table>\r\n		</div>\r\n		$pageft');
INSERT INTO rafia_templates VALUES (11, 'portal', 'forum_cat', 3, '<tr>\r\n<td class="forum_alt2"><img border="0" src="themes/$apt->themepath/$cat_icon"></td>\r\n<td align="right" width="100%" class="forum_alt4">\r\n<a href="forum.php?action=list&amp;cat_id=$id"><font color="#800000">$title\r\n</font></a>\r\n<div class="small">\r\n	$dsc</div>\r\n<div class="small">\r\n	������� ������ :<b> $moderatename</b> </div>\r\n</td>\r\n<td width="200" class="forum_alt1"><span class="small">\r\n<a href="forum.php?action=view&amp;id=$lastpostid">$lasttitle </a><br>\r\n$lastpostd <br>\r\n������ : <a href="members.php?action=info&amp;userid=$lastposterid">$username</a>\r\n</span></td>\r\n<td class="forum_alt2" align="center">$numrows</td>\r\n<td class="forum_alt1" align="center">$numcomment</td>\r\n</tr>');
INSERT INTO rafia_templates VALUES (12, 'portal', 's_view_topic_comment', 1, '<center>\r\n<table border="0" width="90%" cellpadding="1" bordercolorlight="cellspacing=0">\r\n	<tr>\r\n		<td width="50%" valign="top" bgcolor="F4F4F4" align="right"><b>\r\n		<font class="fontht">������ : $name || ������ : $date </font></b></td>\r\n	</tr>\r\n	<tr>\r\n		<td width="50%" valign="top" bgcolor="F4F4F4" align="right">\r\n		<font class="fontablt"><b>$title</b><br>\r\n		$comment </font></b></td>\r\n	</tr>\r\n</table>\r\n<hr noshade="" color="#000000" size="0" width="90%"></center>');
INSERT INTO rafia_templates VALUES (13, 'portal', 'forum_main_table', 3, '<table border="0" cellpadding="0" style="border-collapse: collapse" bordercolor="#E6F0FB" width="95%">\r\n	<tr>\r\n		<td width="33%">&nbsp;</td>\r\n		<td width="33%">&nbsp;</td>\r\n		<td width="34%">&nbsp;$last_topics</td>\r\n	</tr>\r\n</table>\r\n<table border="1" width="95%" id="table4" cellspacing="3" cellpadding="2" style="border-collapse: collapse" bordercolor="#D1E3F8">\r\n	<tr>\r\n		<td class="forum_header">&nbsp;</td>\r\n		<td width="100%" class="forum_header">�������</td>\r\n		<td width="200" class="forum_header" nowrap="">��� ������</td>\r\n		<td class="forum_header">��������</td>\r\n		<td class="forum_header">������</td>\r\n	</tr>\r\n	$forum_cat_table\r\n</table>\r\n<br>');
INSERT INTO rafia_templates VALUES (14, 'portal', 'member_cp', 6, '<div align="center">\r\n	<center>\r\n	<table border="0" width="90%" cellspacing="0" cellpadding="0">\r\n		<tr>\r\n			<td width="100%">\r\n			<div align="center">\r\n				<table border="0" width="100%">\r\n					<tr>\r\n						<td width="50%" bgcolor="$bgcolor2"></td>\r\n					</tr>\r\n				</table>\r\n			</div>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td width="100%">\r\n			<div align="center">\r\n				<table border="0" width="100%" cellspacing="4">\r\n					<tr>\r\n						<td width="88%" align="right" colspan="2" background="themes/$apt->themepath/catbg2.gif" height="27">\r\n						<p align="center"><b>\r\n						<font face="Times New Roman" color="#FFFFFF">\r\n						<span lang="ar-sa">����� ������</span></font></b></p>\r\n						</td>\r\n					</tr>\r\n					<tr>\r\n						<td width="15%" align="right" bgcolor="#E7F1FE">\r\n						<font class="fontablt">��� ��������</font></td>\r\n						<td width="73%" align="right" bgcolor="#EFEFEF">\r\n						<font class="fontablt">\r\n						<a href="members.php?action=info&amp;userid=$userid">$username</a>\r\n						</font></td>\r\n					</tr>\r\n					<tr>\r\n						<td width="15%" align="right" bgcolor="#E7F1FE">\r\n						<font class="fontablt">����� �������</font></td>\r\n						<td width="73%" align="right" bgcolor="#EFEFEF">\r\n						<font class="fontablt">$date</font></td>\r\n					</tr>\r\n					<tr>\r\n						<td width="15%" align="right" bgcolor="#E7F1FE">\r\n						<font class="fontablt">�����</font></td>\r\n						<td width="73%" align="right" bgcolor="#EFEFEF">\r\n						<font class="fontablt">$usertitle</font></td>\r\n					</tr>\r\n					<tr>\r\n						<td width="15%" align="right" bgcolor="#E7F1FE">\r\n						<font class="fontablt">������</font></td>\r\n						<td width="73%" align="right" bgcolor="#EFEFEF">\r\n						<font class="fontablt"><a href="mailto:$email">$email</a>\r\n						</font></td>\r\n					</tr>\r\n					<tr>\r\n						<td width="15%" align="right" bgcolor="#E7F1FE">\r\n						<font class="fontablt">������</font></td>\r\n						<td width="73%" align="right" bgcolor="#EFEFEF">\r\n						<font class="fontablt"><a href="$homepage">$homepage</a>\r\n						</font></td>\r\n					</tr>\r\n					<tr>\r\n						<td width="15%" align="right" bgcolor="#E7F1FE">\r\n						<font class="fontablt">���� ������</font></td>\r\n						<td width="73%" align="right" bgcolor="#EFEFEF">\r\n						<font class="fontablt">$showemail </font></td>\r\n					</tr>\r\n					<tr>\r\n						<td width="15%" align="right" bgcolor="#E7F1FE">\r\n						<font class="fontablt">��� ���� ���������</font></td>\r\n						<td width="73%" align="right" bgcolor="#EFEFEF">\r\n						<font class="fontablt">$allposts </font></td>\r\n					</tr>\r\n					<tr>\r\n						<td width="15%" align="right" bgcolor="#E7F1FE">\r\n						<font class="fontablt">������ �������</font></td>\r\n						<td width="73%" align="right" bgcolor="#EFEFEF">\r\n						<font class="fontablt">$avatar_pic</font></td>\r\n					</tr>\r\n				</table>\r\n			</div>\r\n			</td>\r\n		</tr>\r\n	</table>\r\n	</center></div>');
INSERT INTO rafia_templates VALUES (15, 'portal', 'Index_main', 1, '$pagehd\r\n<div align="center">\r\n	<table border="0" cellpadding="0" style="border-collapse: collapse" width="$themewidth">\r\n		<tr>\r\n			<td width="30">\r\n			<img border="0" src="themes/$apt->themepath/last_teat_04.gif"></td>\r\n			<td width="100%" background="themes/$apt->themepath/last_teat_02.gif">\r\n			<!--INC dir="block" file="last_10_news.php" --></td>\r\n			<td width="25">\r\n			<img border="0" src="themes/$apt->themepath/last_teat_01.gif"></td>\r\n		</tr>\r\n	</table>\r\n</div>\r\n<div align="center">\r\n	<table border="0" width="$themewidth" cellpadding="0" style="border-collapse: collapse" height="100%">\r\n		<tr>\r\n			<td nowrap bgcolor="#516A93" width="18">&nbsp;</td>\r\n			<td align="center" width="176" valign="top" background="themes/$apt->themepath/arabportal_19.gif" bgcolor="#F4F9FB">$right_menu<br>\r\n			</td>\r\n			<td width="100%" valign="top" align="center" style="padding: 5px" bgcolor="#FFFFFF">\r\n			<table border="0" width="100%" cellpadding="0" style="border-collapse: collapse">\r\n				<tr>\r\n					<td width="9">\r\n					<img border="0" src="themes/$apt->themepath/frame_index_03.gif" width="14" height="14"></td>\r\n					<td background="themes/$apt->themepath/frame_index_02.gif">\r\n					<img border="0" src="themes/$apt->themepath/frame_index_02.gif" width="61" height="14"></td>\r\n					<td width="8">\r\n					<img border="0" src="themes/$apt->themepath/frame_index_01.gif" width="15" height="14"></td>\r\n				</tr>\r\n				<tr>\r\n					<td width="9" background="themes/$apt->themepath/frame_index_06.gif">\r\n					<img border="0" src="themes/$apt->themepath/frame_index_06.gif" width="14" height="56"></td>\r\n					<td>\r\n					<p align="center">$ads_head $index_middle <br>\r\n					$middle_menu <br>\r\n					$ads_foot</td>\r\n					<td width="8" background="themes/$apt->themepath/frame_index_04.gif">\r\n					<img border="0" src="themes/$apt->themepath/frame_index_04.gif" width="15" height="56"></td>\r\n				</tr>\r\n				<tr>\r\n					<td width="9">\r\n					<img border="0" src="themes/$apt->themepath/frame_index_09.gif" width="14" height="14"></td>\r\n					<td background="themes/$apt->themepath/frame_index_08.gif">\r\n					<img border="0" src="themes/$apt->themepath/frame_index_08.gif" width="61" height="14"></td>\r\n					<td width="8">\r\n					<img border="0" src="themes/$apt->themepath/frame_index_07.gif" width="15" height="14"></td>\r\n				</tr>\r\n			</table>\r\n			<td align="center" width="176" valign="top" background="themes/$apt->themepath/arabportal_17.gif" bgcolor="#F4F9FB">$left_menu \r\n			</td>\r\n			<td nowrap bgcolor="#516A93" width="19">&nbsp;</td>\r\n		</tr>\r\n	</table>\r\n</div>\r\n$pageft');
INSERT INTO rafia_templates VALUES (16, 'portal', 'news_show', 2, '<table border="0" width="98%" cellspacing="0" cellpadding="0">\r\n	<tr>\r\n		<td align="right" class="forum_header">��� ����� </td>\r\n	</tr>\r\n	<tr>\r\n		<td class="normal">$pre_post</td>\r\n	</tr>\r\n</table>\r\n\r\n<script language="javascript">\r\nfunction checkForm(){\r\n	if (!document.rafia.title.value) {\r\n		alert(\'���� ... ��� �� ��� ������ ����� �����\'); \r\n		return false;\r\n	} \r\n	if (document.rafia.post_head.value.length >= $counthead) {\r\n		alert("���� ... ��� ���� ��� ����� ���� �� $counthead"); \r\n		return false;\r\n	} \r\n	if (!document.rafia.post.value) {\r\n		alert(\'���� ... ��� �� ��� ������ �� �����\'); \r\n		return false;\r\n\r\n	}\r\ndocument.rafia.spam.value =\'newsnotspam_$cap\';\r\n}\r\n</script>\r\n<form onsubmit="return checkForm(this)" action="news.php?action=insert" method="post" name="rafia" enctype="multipart/form-data">\r\n	<table border="0" width="98%" cellspacing="0" cellpadding="0">\r\n		<tr>\r\n			<td align="right" class="forum_header">����� ��� </td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<table border="0" width="100%" id="table13" cellpadding="2" class="fontablt">\r\n				$usernamef$useridf$selectform<tr>\r\n					<td align="right" nowrap="" class="info_bar">������� :\r\n					<font color="#FF0000">*</font> </td>\r\n					<td align="right" width="100%">\r\n					<input type="text" name="title" value="$title" size="35" class="text_box">\r\n					</td>\r\n				</tr>\r\n				$txtcounth<tr>\r\n					<td align="right" nowrap="" class="info_bar" valign="top">��� \r\n					����� : <br>�������</td>\r\n					<td align="right" width="100%">\r\n					<textarea name="post_head" rows="8" cols="60" onkeypress="return countIt();">$post_head</textarea></td>\r\n				</tr>\r\n				$editor$txtcount<tr>\r\n					<td align="right" nowrap="" class="info_bar" valign="top">��\r\n					����� : <font color="#FF0000">*</font> <br>\r\n					��� ���� ��� �� ���� <br>\r\n					��� �� : $countpost ���<br>\r\n					<center><a href="#" onmouseover="return proces()">������ �����</a><br>\r\n					���� �� :\r\n					<input size="5" name="remain" type="text" value="$countpost">\r\n					<center></center></center></td>\r\n					<td align="right" width="100%">$form_code<br>\r\n					<textarea onmouseover="return proces()" onbeforeeditfocus="return proces()" onmouseout="return proces()" name="post" rows="15" cols="60" id="post" wrap="virtual">$post</textarea><input type="hidden" name="left" value="$countpost" size="7" class="text_box"></td>\r\n				</tr>\r\n				<tr>\r\n					<td align="right" nowrap="" class="info_bar">������� ������� \r\n					���������� </td>\r\n					<td align="right" width="100%">\r\n					<input type="radio" name="H" value="1"> ���\r\n					<input type="radio" name="H" value="0" checked> �� </td>\r\n				</tr>\r\n				<tr>\r\n					<td align="right" nowrap="" class="info_bar">��� ������� �� \r\n					���� ������ɿ </td>\r\n					<td align="right" width="100%">\r\n					<input type="radio" name="inindex" value="1" checked=""> ���&nbsp;\r\n					<input type="radio" name="inindex" value="0"> ��</td>\r\n				</tr>\r\n				<tr>\r\n					<td align="right" nowrap="" class="info_bar">��� ������� �� \r\n					����� ��� ������ѿ </td>\r\n					<td align="right" width="100%">\r\n					<input type="radio" name="inmenu" value="1"> ���&nbsp;\r\n					<input type="radio" name="inmenu" value="0" checked=""> ��</td>\r\n				</tr>\r\n				$main_n<tr>\r\n					<td align="right" nowrap="" class="info_bar">������� ������ \r\n					���������� ����� </td>\r\n					<td align="right" width="100%">\r\n					<input type="radio" name="catmig" value="1"> ���&nbsp;\r\n					<input type="radio" name="catmig" value="0" checked=""> ��</td>\r\n				</tr>\r\n\r\n\r\n				$fileupload $imgupload\r\n<tr><td align="right" nowrap="" class="info_bar">��� ������� :</td>\r\n<td align="right" width="100%">\r\n<input type="radio" name="doshow" value="0" checked=""> ��� ������� &nbsp;\r\n<input type="radio" name="doshow" value="1"> ��� �������\r\n</td></tr>\r\n				<input type="hidden" name="spam" value="spam">\r\n				<input type="hidden" name="action" value="insert">\r\n						</table>\r\n						</td>\r\n					</tr>\r\n					<tr>\r\n						<td align="center">\r\n<input border="0" src="themes/$apt->themepath/newnews.gif" name="dosubmit" width="98" height="24" type="image">\r\n</td>\r\n					</tr>\r\n				</table> </form>');
INSERT INTO rafia_templates VALUES (17, 'portal', 'forum_cat_table', 3, '<tr>\r\n<td colspan="5">\r\n<table border="0" width="100%" id="table6" cellspacing="0" cellpadding="0">\r\n	<tr>\r\n		<td class="forum_header2">\r\n		<a href="forum.php?action=list&amp;cat_id=$id"><font color="#FFFFFF">$title\r\n		</font></a></td>\r\n	</tr>\r\n</table>\r\n</td>\r\n</tr>\r\n$forum_cat');
INSERT INTO rafia_templates VALUES (18, 'portal', 'form_code', 1, '<table cellpadding="0" cellspacing="0" border="0">\r\n	<tr valign="bottom">\r\n		<td colspan="2">\r\n		<!-- start control bar -->\r\n		<div id="controlbar">\r\n			<!-- / start control bar -->\r\n			<!-- first control row -->\r\n			<div class="controlholder">\r\n				<!-- MagicToolBox 2.5 by Alawi BaAqeel, software@rayaheen.net -->\r\n				<script language="Javascript" src="html/toolbox/toolbox.js"></script>\r\n				<script language="Javascript">\r\ntoolbox_backcolor = "#ECE9D8";\r\nbtn_bordercolor = "black";\r\nbtn_backcolor_over = "cornsilk";\r\nbtn_backcolor_down = "white";\r\nstatusColor = "black";\r\ntipColor = "maroon";\r\n</script>\r\n				<style type="text/css">\r\n.cbtn {\r\n	width: 20px;\r\n	height: 18px;\r\n	cursor: hand;\r\n}\r\n</style>\r\n				<table dir="ltr" border="0" cellpadding="0" cellspacing="0" width="100%">\r\n					<tr>\r\n						<td align="center" oncontextmenu="return false" onselectstart="return false" onmousedown="Capture(1)" onmouseup="Capture(0)" onmousemove="Capture(0)">\r\n						<script language="javascript" h="">\r\nshowButtons();\r\nshowKeyboard();\r\n</script>\r\n						</td>\r\n					</tr>\r\n				</table>\r\n				<!-- end of MagicToolBox 2.5 for vB3 --></div>\r\n			<!-- end control bar --></div>\r\n		<!-- / end control bar --></td>\r\n	</tr>\r\n	<tr valign="top">\r\n		<td class="controlbar"></td>\r\n	</tr>\r\n</table>');
INSERT INTO rafia_templates VALUES (19, 'portal', 'link_cat_tools', 5, '<table border="0" width="90%" cellspacing="1">\r\n	<tr>\r\n		<td width="100%" align="right">\r\n		<div align="center">\r\n			<table border="0" width="100%" cellspacing="0" cellpadding="0">\r\n				<tr>\r\n					<td width="50%" align="right">$Jump</td>\r\n					<center>\r\n					<td width="50%" align="right">\r\n					<a href="$PHP_SELF?action=add&amp;cat_id=$cat_id">\r\n					<img border="0" src="themes/$apt->themepath/$cat_img" align="left"></a></td>\r\n				</tr>\r\n			</table>\r\n			</center></div>\r\n		</td>\r\n	</tr>\r\n</table>');
INSERT INTO rafia_templates VALUES (20, 'portal', 'guestbook_table', 1, '<!-- guestbook_table START -->\r\n<table border="0" width="100%" id="side_menu" cellspacing="0" cellpadding="0">\r\n	<tr>\r\n		<td bgcolor="#F1F1F1" style="padding-right: 5px" class="fontablt" colspan="3" align="right">\r\n		<a href="$PHP_SELF?action=edit&amp;id=$id">\r\n		<img border="0" src="themes/$apt->themepath/g_edit.gif" width="16" height="16"></a>\r\n		<a href="$url" target="_blank">\r\n		<img border="0" src="themes/$apt->themepath/home.gif" width="16" height="16"></a>\r\n		<a href="mailto:$email">\r\n		<img border="0" src="themes/$apt->themepath/email.gif" width="16" height="16"></a>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td bgcolor="#F9F9F9" style="padding-right: 5px" class="fontablt" colspan="3" align="right">\r\n		<font class="fontablt">$guestbook <br>\r\n		<br>\r\n		</font></td>\r\n	</tr>\r\n	<tr>\r\n		<td bgcolor="#F1F1F1" style="padding-right: 5px" align="right" class="fontht2" colspan="3">\r\n		<font class="fontht2">����� : $name</font> </td>\r\n	</tr>\r\n</table>\r\n<br>\r\n<!-- guestbook_table END -->');
INSERT INTO rafia_templates VALUES (21, 'portal', 'forum_list_bottom', 3, '<table border="0" id="table10" cellspacing="3" cellpadding="3" class="small" width="95%">\r\n	<tr>\r\n		<td nowrap="">\r\n		<img border="0" src="themes/$apt->themepath/posticon.gif" width="12" height="16"></td>\r\n		<td nowrap="">������ �����</td>\r\n		<td nowrap="">\r\n		<img border="0" src="themes/$apt->themepath/postnew.gif" width="12" height="16"></td>\r\n		<td nowrap="">������ �����</td>\r\n		<td width="100%">&nbsp;</td>\r\n	</tr>\r\n	<tr>\r\n		<td nowrap="">\r\n		<img border="0" src="themes/$apt->themepath/posthot.gif" width="12" height="16"></td>\r\n		<td nowrap="">������ �����</td>\r\n		<td nowrap="">\r\n		<img border="0" src="themes/$apt->themepath/Sticky.gif" width="12" height="16"></td>\r\n		<td nowrap="">������ ������</td>\r\n		<td width="100%">&nbsp;</td>\r\n	</tr>\r\n	<tr>\r\n		<td nowrap="">\r\n		<img border="0" src="themes/$apt->themepath/postlock.gif" width="12" height="16"></td>\r\n		<td nowrap="">������ �����</td>\r\n		<td nowrap="">&nbsp;</td>\r\n		<td nowrap="">&nbsp;</td>\r\n		<td width="100%">&nbsp;</td>\r\n	</tr>\r\n</table>');
INSERT INTO rafia_templates VALUES (22, 'portal', 'pm_msg_list', 6, '<!-- pm_msg_list -->\r\n<tr>\r\n<td width="29" bgcolor="#D8E3F1">\r\n<p align="center">$msgisread</td>\r\n<td width="41%" bgcolor="#ECF2F9"><b>\r\n<a href="/pm.php?action=view&amp;msgid=$id" style="text-decoration: none">\r\n<font color="#34597D">&nbsp;</a><a href="$PHP_SELF?action=view&amp;msgid=$msgid&amp;box=$box">$msgtitle</a></font></a></b></td>\r\n<td id="m4" width="12%" align="center" bgcolor="#D8E3F1">\r\n<font color="#34597D" face="Arial"><b><span lang="en-us">$fromusername</span></b></font></td>\r\n<td id="m4" width="263" bgcolor="#ECF2F9"></p>\r\n<div class="">\r\n	<p align="center"><font color="#34597D" face="Tahoma" size="2">\r\n	<strong style="font-weight: 400">$msgdate</strong> </font></p>\r\n</div>\r\n</td>\r\n<td align="center" style="padding: 0px" width="2%" bgcolor="#DFE9F4">\r\n<input type="checkbox" name="msgsid[]" value="$msgid" /></td>\r\n</tr>\r\n<!-- // pm_msg_list -->');
INSERT INTO rafia_templates VALUES (23, 'portal', 'pm_msg_table', 6, '<table border="0" width="96%" cellspacing="0">\r\n	<tr>\r\n		<td width="100%" valign="bottom">\r\n		<p align="right" class="forum_alt2">\r\n		<img height="21" src="themes/$apt->themepath/navbits_start.gif" width="21" align="absMiddle" border="0">\r\n		<a href="pm.php">������� ������</a> <br>\r\n		<img height="15" src="themes/$apt->themepath/icon_bar.gif" width="15" align="absMiddle" border="0">\r\n		<img height="21" src="themes/$apt->themepath/navbits_finallink.gif" width="21" align="absMiddle" border="0"><a href="pm.php?box=1">����� \r\n		������</a> � $msgtitle</p>\r\n		</td>\r\n	</tr>\r\n</table>\r\n<br />\r\n<table border="0" width="95%" id="table4" cellspacing="1" cellpadding="0">\r\n	<tr>\r\n		<td width="100%" class="forum_header" style="text-align: right">$rep_icon \r\n		� $msgtitle</td>\r\n	</tr>\r\n	<tr>\r\n		<td width="100%" class="forum_alt3">\r\n		<table border="0" width="100%" id="table16">\r\n			<tr>\r\n			</tr>\r\n			<tr>\r\n				<td width="100%" class="forum_alt3">\r\n				<table border="0" width="100%" id="table16">\r\n					<tr>\r\n						<td width="20%" class="forum_alt1" valign="top">\r\n						<span class="small">������:\r\n						<a href="members.php?action=info&amp;userid=$userid">$username</a>\r\n						<br>\r\n						$userimgtitle<br>\r\n						������� : $date<br>\r\n						��������� : $allpost<br>\r\n						<a href="mail.php?action=sendtousers&amp;userid=$userid">\r\n						<img border="0" src="themes/$apt->themepath/email.gif" alt="������">\r\n						</a><a href="$homepage" target="_blank">\r\n						<img border="0" src="themes/$apt->themepath/home.gif" alt="������ ������"></a>\r\n						<br>\r\n						</span></td>\r\n						<td width="80%" valign="top" class="forum_alt2" colspan="2">\r\n						<span class="small"></a>��� �� $msgdate</font> </span>\r\n						<hr color="#7394B6" size="1"><b>$msgtitle</b> $message\r\n						<br>\r\n						$upload_file<br>\r\n						<hr color="#7394B6" size="1"><center>$signature</center>\r\n						</td>\r\n					</tr>\r\n					<tr>\r\n						<td width="20%" class="small" valign="top" align="center">\r\n						</td>\r\n						<td width="40%" valign="top" class="small"></td>\r\n						<td width="60%" valign="top" align="left">\r\n						<a href="pm.php?action=reply&amp;id=$msgid&amp;box=$box">\r\n						<img border="0" src="themes/$apt->themepath/sendpm.gif"></a>\r\n						<a href="pm.php?action=manag&amp;case=del&amp;id=$msgid&amp;box=$box">\r\n						<img border="0" src="themes/$apt->themepath/del.gif"></a>\r\n						<a href="pm.php?action=manag&amp;case=save&amp;id=$msgid&amp;box=$box">\r\n						<img border="0" src="themes/$apt->themepath/save.gif"></a>\r\n						</td>\r\n					</tr>\r\n				</table>\r\n				</td>\r\n			</tr>\r\n		</table>\r\n		</td>\r\n	</tr>\r\n</table>');
INSERT INTO rafia_templates VALUES (24, 'portal', 'body_msg', 1, '<script>\r\n\r\nvar redirecturl="$url"\r\nvar pausefor=5\r\n\r\n//DONE EDITING\r\n\r\nfunction postaction(){\r\nif (window.timer){\r\nclearInterval(timer)\r\nclearInterval(timer_2)\r\n}\r\nwindow.location=redirecturl\r\n}\r\nsetTimeout("postaction()",pausefor*1000)\r\n\r\n</script>\r\n<div align="center">\r\n	<br>\r\n	<br>\r\n	<br>\r\n	<br>\r\n	<br>\r\n	<br>\r\n	<br>\r\n	<table width="60%" border="0" cellpadding="0" cellspacing="0">\r\n		<tr>\r\n			<td height="24" background="themes/$themepath/cat_bg.jpg">\r\n			<p align="center"><font size="4">����� ������ </font></p>\r\n			</td>\r\n		</tr>\r\n		</tr>\r\n		<tr>\r\n			<td align="center" height="85" bgcolor="#EFF9FC">\r\n			<font class="fontabltee"><font size="4">$msg</font></font><font size="4"><br>\r\n			<img border="0" src="themes/$themepath/loading.gif"><br>\r\n			<font color="#454545">���� ������� ���� �������� �� </font>\r\n			<a title="���� ���" href="$url"><font color="#800000">\r\n			<span style="text-decoration: none">���� ���</span></font></a></font><font size="4" color="#454545"> \r\n			��� ��� ������ �� ���� �������� �������� </font></td>\r\n		</tr>\r\n	</table>\r\n</div>');
INSERT INTO rafia_templates VALUES (25, 'portal', 'uploadfile', 1, '<div align="center">\r\n	<table border="1" cellpadding="3" style="border-collapse: collapse;" bordercolor="#C0C0C0" width="90%" id="AutoNumber7">\r\n		<tr>\r\n			<td width="100%" colspan="2">\r\n			<p align="center"><font size="1" face="Windows UI"><b>&nbsp;��� ����&nbsp; \r\n			$download</b></font></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td width="32%"><b><font size="1" face="Windows UI">��� ���� �������</font></b></td>\r\n			<td width="68%"><b><font size="1" face="Windows UI">$upclicks</font></b></td>\r\n		</tr>\r\n		<tr>\r\n			<td width="32%"><b><font size="1" face="Windows UI">��� �����</font></b></td>\r\n			<td width="68%"><font size="1" face="Windows UI"><b>$upsize</b></font><font class="fontablt">\r\n			<font size="1" face="Windows UI"><b>����</b></font></font></td>\r\n		</tr>\r\n		<tr>\r\n			<td width="32%"><b><font size="1" face="Windows UI">��� �����</font></b></td>\r\n			<td width="68%"><b><font size="1" face="Windows UI">$upname</font></b></td>\r\n		</tr>\r\n	</table>\r\n</div>');
INSERT INTO rafia_templates VALUES (26, 'portal', 'blockmenu', 7, '<!-- BLOCK START -->\r\n<table width="171" border="0" cellpadding="0" style="border-collapse: collapse">\r\n	<tr>\r\n		<td height="26" background="themes/$apt->themepath/menu_head.gif">\r\n		<p align="right"><font class="side_menu_head">&nbsp;&nbsp;&nbsp;&nbsp; {block_head}</font></p>\r\n		</td>\r\n	</tr>\r\n	</tr>\r\n	<tr>\r\n		<td style="padding-right: 0px" class="side_menu_center">{block_center}</td>\r\n	</tr>\r\n	<tr>\r\n		<td style="padding-right: 0px" class="side_menu_center">&nbsp;</td>\r\n	</tr>\r\n	<tr>\r\n		<td style="padding-right: 0px" class="side_menu_center">\r\n		<img border="0" src="themes/$apt->themepath/menu_but.gif"></td>\r\n	</tr>\r\n</table>\r\n<!-- BLOCK END -->\r\n<div align="center">\r\n	<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%">\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n	</table>\r\n</div>');
INSERT INTO rafia_templates VALUES (27, 'portal', 'error_msg', 1, '<body bgcolor="#FFFFFF">\r\n\r\n<br>\r\n<br>\r\n<br>\r\n<br>\r\n<br>\r\n<br>\r\n<br>\r\n<br>\r\n<div align="center">\r\n	<center>\r\n	<table border="0" width="80%" bgcolor="#EBEBEB">\r\n		<tr>\r\n			<td width="100%" align="center"><br>\r\n			<font class="fontablt">$msg<br>\r\n			<br>\r\n			<center>[ <a href="javascript:history.go(-1);">������ �����</a> ]</center>\r\n			<br>\r\n			</font></td>\r\n		</tr>\r\n	</table>\r\n	</center></div>');
INSERT INTO rafia_templates VALUES (28, 'portal', 'pm_list_table', 6, '<br />\r\n<form method="POST" action="$PHP_SELF?action=manag" name="admin">\r\n	<div align="center">\r\n		<table cellpadding="6" cellspacing="1" border="1" width="100%" style="border-collapse: collapse">\r\n			<thead>\r\n				<tr>\r\n					<td colspan="5" style="padding: 6px 0 6px 6px" bgcolor="#F2F0EE">\r\n					<p align="center"><b><font color="#34597D">$nummsg ����� �� \r\n					��� $total ����� ��� ����</font></b></p>\r\n					<div align="center">\r\n						<table border="1" width="400" id="table5" style="border-collapse: collapse">\r\n							<tr>\r\n								<td width="100%" align="center"><center>\r\n								<table border="1" width="100%" id="table6" style="border-collapse: collapse">\r\n									<tr>\r\n										<td width="100%" background="themes/$apt->themepath/pm_cell.gif">\r\n										<font class="fontablt" color="#FFFFFF">\r\n										<p align="center"><b>$box_title ����� ����� \r\n										$width % </b></p>\r\n										</font></td>\r\n									</tr>\r\n								</table>\r\n								<table border="0" width="400" cellspacing="0" cellpadding="0" id="table7">\r\n									<tr>\r\n										<td width="100%" height="3"></td>\r\n									</tr>\r\n									<tr>\r\n										<td width="100%">\r\n										<img border="0" src="images/msg.gif" width="$width%" height="10"></td>\r\n									</tr>\r\n								</table>\r\n								</center></td>\r\n							</tr>\r\n							<tr>\r\n								<td width="100%" align="center">\r\n								<table border="0" width="400" id="table8">\r\n									<tr>\r\n										<td width="50%" align="right">\r\n										<font size="1"><b>0 %</b></font></td>\r\n										<td width="50%" align="left">\r\n										<font size="1"><b>100 %</b></font></td>\r\n									</tr>\r\n								</table>\r\n								</td>\r\n							</tr>\r\n						</table>\r\n					</div>\r\n					</td>\r\n				</tr>\r\n			</thead>\r\n			<tr>\r\n				<td class="" colspan="5" style="padding-top: 3px; padding-bottom: 3px; border-bottom: 1px outset;" width="102%" background="themes/$apt->themepath/catbg2.gif">\r\n				<p align="center"><font color="#FFFFFF"><b>$box_title</b></font>\r\n				</p>\r\n				</td>\r\n			</tr>\r\n			<tbody id="collapseobj_pmf0_select" style="">\r\n				<tr>\r\n					<td width="29" bgcolor="#D8E3F1" align="center">&nbsp;</td>\r\n					<td width="41%" align="center" bgcolor="#ECF2F9">\r\n					<font color="#34597D"><b>����� �������</b></font></td>\r\n					<td id="m4" width="12%" align="center" bgcolor="#D8E3F1">\r\n					<font color="#34597D"><b>$tofrom</b></font></td>\r\n					<td id="m4" width="263" align="center" bgcolor="#ECF2F9">\r\n					<font color="#34597D"><b>����� �������</b></font></td>\r\n					<td align="center" style="padding: 0px" width="2%" bgcolor="#D8E3F1">\r\n					</td>\r\n				</tr>\r\n				<tr>\r\n					<td bgcolor="#E6E3DF" height="3" colspan="5"></td>\r\n				</tr>\r\n				$pm_msg_list\r\n			<tr>\r\n				<td align="right" colspan="5" background="themes/$apt->themepath/catbg2.gif">\r\n				<div class="">\r\n					<font color="#FFFFFF"><b>������ �������:</b></font>\r\n					<select name="do">\r\n					<option value="">���� �� �������</option>\r\n					<option value="save">���</option>\r\n					<option value="del">���</option>\r\n					<option value="export">�����</option>\r\n					<option value="read">������ ������</option>\r\n					<option value="unread">������ ��� ������</option>\r\n					</select> <input type="submit" class="" value="�����" />\r\n					<input type="button" name="CheckAll" value="����� ����" onclick="checkAll(document.admin)">\r\n					<input type="button" name="UnCheckAll" value="����� �������" onclick="uncheckAll(document.admin)">\r\n					<input type="hidden" name="box" value="$box"></div>\r\n				</td>\r\n			</tr>\r\n		</table>\r\n	</div>\r\n	<br>\r\n</form>\r\n<a href="pm.php?action=sendmsg">\r\n<img border="0" src="themes/$apt->themepath/newpm.gif"></a><br />\r\n<!-- forumjump -->\r\n<table cellpadding="0" cellspacing="0" border="0" width="100%" align="center">\r\n	<tr valign="top">\r\n		<td width="100%" rowspan="2">\r\n		<table cellpadding="2" border="0" style="border-collapse: collapse" width="40%">\r\n			<tr>\r\n				<td>\r\n				<p align="center">\r\n				<img border="0" src="themes/$apt->themepath/pm_unread.gif" width="18" height="12"></p>\r\n				</td>\r\n				<td><font color="#34597D"><b>&nbsp; ����� ��� ������</b></font></td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n				<p align="center">\r\n				<img border="0" src="themes/$apt->themepath/pm_read.gif" width="18" height="17"></p>\r\n				</td>\r\n				<td><font color="#34597D"><b>&nbsp; ����� ������</b></font></td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n				<p align="center">\r\n				<img border="0" src="themes/$apt->themepath/pm_reply.gif" width="18" height="17"></p>\r\n				</td>\r\n				<td><font color="#34597D"><b>&nbsp; ����� �� ���� ����� </b>\r\n				</font></td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n				<p align="center">\r\n				<img border="0" src="themes/$apt->themepath/pm_forward.gif" width="18" height="17"></p>\r\n				</td>\r\n				<td><font color="#34597D"><b>&nbsp; ����� �����</b></font></td>\r\n			</tr>\r\n		</table>\r\n		</td>\r\n		<td class="" nowrap="nowrap">&nbsp;</td>\r\n	</tr>\r\n	<tr>\r\n		<td valign="bottom">\r\n		<div class="" style="text-align: left; white-space: nowrap">\r\n			<form action="pm.php" method="get">\r\n				<strong>�������� ���:</strong><br />\r\n				<select name="box" onchange="this.form.submit();">\r\n				<option value="index" selected="selected">���� �� �������\r\n				</option>\r\n				<option value="1">����� ������</option>\r\n				<option value="2">����� ������</option>\r\n				<option value="3">����� �����</option>\r\n				</select> <input type="submit" class="" value="����" />\r\n			</form>\r\n		</div>\r\n		</td>\r\n	</tr>\r\n</table>');
INSERT INTO rafia_templates VALUES (29, 'portal', 'member_info', 6, '<div align="center">\r\n	<center>\r\n	<table border="0" width="90%" cellspacing="0" cellpadding="0">\r\n		<tr>\r\n			<td width="100%">\r\n			<div align="center">\r\n				<table border="0" width="100%">\r\n					<tr>\r\n						<td width="50%" align="center" background="themes/$apt->themepath/catbg2.gif">\r\n						<font class="fontht">������� ����� �������� : <b>$username\r\n						</font></b></td>\r\n					</tr>\r\n				</table>\r\n			</div>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td width="100%">\r\n			<div align="center">\r\n				<table border="0" width="100%" cellspacing="4">\r\n					<tr>\r\n						<td width="27%" align="right" bgcolor="#E7F1FE">\r\n						<font class="fontablt">����� �������</font></td>\r\n						<td width="73%" align="right" bgcolor="#EFEFEF">\r\n						<font class="fontablt">$date</font></td>\r\n					</tr>\r\n					<tr>\r\n						<td width="27%" align="right" bgcolor="#E7F1FE">\r\n						<font class="fontablt">�����</font></td>\r\n						<td width="73%" align="right" bgcolor="#EFEFEF">\r\n						<font class="fontablt">$usertitle</font></td>\r\n					</tr>\r\n					<tr>\r\n						<td width="27%" align="right" bgcolor="#E7F1FE">\r\n						<font class="fontablt">������</font></td>\r\n						<td width="73%" align="right" bgcolor="#EFEFEF">\r\n						<font class="fontablt">$email </font></td>\r\n					</tr>\r\n					<tr>\r\n						<td width="27%" align="right" bgcolor="#E7F1FE">\r\n						<font class="fontablt">������</font></td>\r\n						<td width="73%" align="right" bgcolor="#EFEFEF">\r\n						<font class="fontablt">$homepage </font></td>\r\n					</tr>\r\n					<tr>\r\n						<td width="27%" align="right" bgcolor="#E7F1FE">\r\n						<font class="fontablt">���� ������</font></td>\r\n						<td width="73%" align="right" bgcolor="#EFEFEF">\r\n						<font class="fontablt">$showemail </font></td>\r\n					</tr>\r\n					<tr>\r\n						<td width="27%" align="right" bgcolor="#E7F1FE">\r\n						<font class="fontablt">��� ���� ���������</font></td>\r\n						<td width="73%" align="right" bgcolor="#EFEFEF">\r\n						<font class="fontablt">$allposts ( $newsPosts $forumPosts \r\n						)</font></td>\r\n					</tr>\r\n					<tr>\r\n						<td width="27%" align="right" bgcolor="#E7F1FE">\r\n						<font class="fontablt">������ �������</font></td>\r\n						<td width="73%" align="right" bgcolor="#EFEFEF">\r\n						<font class="fontablt">$avatar_pic</font></td>\r\n					</tr>\r\n				</table>\r\n			</div>\r\n			</td>\r\n		</tr>\r\n	</table>\r\n	</center></div>');
INSERT INTO rafia_templates VALUES (30, 'portal', 'del_msg', 1, '<body bgcolor="#F1F1F1">\r\n\r\n<br>\r\n<br>\r\n<br>\r\n<br>\r\n<br>\r\n<br>\r\n<br>\r\n<br>\r\n<div align="center">\r\n	<center>\r\n	<table border="0" width="80%" bgcolor="#FFFFFF">\r\n		<tr>\r\n			<form method="POST" action="?action=del">\r\n				<input type="hidden" name="cat_id" value="$cat_id">\r\n				<input type="hidden" name="idp" value="$idp">\r\n				<input type="hidden" name="idc" value="$idc">\r\n				<td width="100%" align="center"><br>\r\n				<b><font class="fontablt">�� ��� ����� �� ����� �� ��� �������� \r\n				�</font></b><br>\r\n				<input class="button" type="submit" value="���" name="yes">\r\n				<input class="button" type="button" value="����� �����" name="B2" dir="rtl" onclick="javascript:history.go(-1);">\r\n				<br>\r\n				</td>\r\n			</form>\r\n		</tr>\r\n	</table>\r\n	</center></div>');
INSERT INTO rafia_templates VALUES (31, 'portal', 'users_Login', 3, '<form method="post" action="members.php?action=login">\r\n	<font face="tahoma" size="2">���� ����� � ���� ���� :</font>\r\n	<input type="textbox" name="username" size="13">\r\n	<input type="password" name="userpass" size="13">\r\n	<input class="button" type="submit" value="����">\r\n	<a href="javascript:rafiawin(\'popup.php?action=remind\',250,350)">����� ��������</a>\r\n</form>');
INSERT INTO rafia_templates VALUES (32, 'portal', 'forum_cat_tools', 3, '<table border="0" width="96%" cellspacing="1">\r\n	<tr>\r\n		<td width="100%" align="right">\r\n		<div align="center">\r\n			<table border="0" width="100%" cellspacing="0" cellpadding="0">\r\n				<tr>\r\n					<td width="50%" align="right">$Jump</td>\r\n					<center>\r\n					<td width="50%" align="right">\r\n					<a href="$PHP_SELF?action=add&amp;cat_id=$cat_id">\r\n					<img border="0" src="themes/$apt->themepath/$cat_img" align="left"></a></td>\r\n				</tr>\r\n			</table>\r\n			</center></div>\r\n		</td>\r\n	</tr>\r\n</table>');
INSERT INTO rafia_templates VALUES (33, 'portal', 'guestbook_tools', 1, '<table border="0" width="90%" cellspacing="1">\r\n	<tr>\r\n		<td width="100%" align="right">\r\n		<div align="center">\r\n			<table border="0" width="100%" cellspacing="0" cellpadding="0">\r\n				<tr>\r\n					<td width="50%" align="right">$pagenum</td>\r\n					<center>\r\n					<td width="50%" align="right">\r\n					<a href="$PHP_SELF?action=add">\r\n					<img border="0" src="themes/$apt->themepath/sign.gif" align="left"></a></td>\r\n				</tr>\r\n			</table>\r\n			</center></div>\r\n		</td>\r\n	</tr>\r\n</table>\r\n<br>');
INSERT INTO rafia_templates VALUES (34, 'portal', 'download_comment_table', 4, '<table border="1" cellpadding="3" cellspacing="0" style="border-collapse: collapse" width="95%" bordercolor="#C0C0C0">\r\n	<tr>\r\n		<td valign="top" bgcolor="#F1F1F1" nowrap=""><span class="fontablt">������:\r\n		<a href="members.php?action=info&amp;userid=$userid">$username</a> <br>\r\n		$usertitle <a name="comment$id"></a><br>\r\n		$userimgtitle <br>\r\n		������� : $datetime <br>\r\n		�������� : $allposts <br>\r\n		<a href="mail.php?action=sendtousers&amp;userid=$userid">\r\n		<img border="0" src="themes/$apt->themepath/email.gif" alt="������" width="16" height="16"></a>\r\n		<a href="$homepage" target="_blank">\r\n		<img border="0" src="themes/$apt->themepath/home.gif" alt="����" width="16" height="16">\r\n		</a></span><br>\r\n		</td>\r\n		<td width="100%" valign="top">\r\n		<p dir="rtl"><span class="normal">$title </span><font class="fontablt">\r\n		<font color="#808080">[����� �������� : $date ]<br>\r\n		</font>$comment </font></p>\r\n		<p><br>\r\n		$upload_file <br>\r\n		<font color="#C0C0C0">------------------</font><br>\r\n		<b><font class="fontablt">$signature</font></b> <br>\r\n		</p>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td valign="top" bgcolor="#FFFFFF" nowrap=""></td>\r\n		<td width="100%" valign="top">\r\n		<a href="$PHP_SELF?action=addcomment&amp;id=$postid" ec="$id&quot;">\r\n		<img border="0" src="themes/$apt->themepath/quote.gif" align="left"></a><a href="$PHP_SELF?action=editcomment&amp;id=$id"><img border="0" src="themes/$apt->themepath/edit.gif" align="left"></a><a href="pm.php?action=sendmsg&amp;id=$userid"><img border="0" src="themes/$apt->themepath/pm.gif"></a></td>\r\n	</tr>\r\n</table>\r\n<br>');
INSERT INTO rafia_templates VALUES (35, 'portal', 'news_comment_table', 2, '<table border="1" cellpadding="3" cellspacing="0" style="border-collapse: collapse" width="95%" bordercolor="#E4E4E4">\r\n	<tr>\r\n		<td valign="top" bgcolor="#F1F1F1" nowrap><span class="fontablt">������:\r\n		<a href="members.php?action=info&userid=$userid">$username</a><br>\r\n		&nbsp;<a href="mail.php?action=sendtousers&userid=$userid"><img border="0" src="images/mail.gif" alt="������"></a>\r\n		<a href="members.php?action=homepage&userid=$userid" target="_blank">\r\n		<img border="0" src="images/home.gif" alt="����"></a>\r\n		<a href="pm.php?action=sendmsg&id=$userid">\r\n		<img border="0" src="images/pmid.gif" alt="����� ����"></a>\r\n		</span>\r\n		</td>\r\n		<td width="100%" valign="top"><span class="normal">$title </span>\r\n		<font class="fontablt"><font color="#808080">[������ : $date ]</font></font><span class="fontablt"><a name="comment$id"></a></span></td>\r\n	</tr>\r\n	<tr>\r\n		<td valign="top" nowrap colspan="2">\r\n		<div align="center">\r\n			<table border="0" cellpadding="2" style="border-collapse: collapse" width="100%" cellspacing="4">\r\n				<tr>\r\n					<td>\r\n					<p dir="rtl" align="right"><font class="fontablt">$comment\r\n					</font><br>\r\n					$upload_file </p>\r\n<br>-------------------------------------<br>$signature\r\n					</td>\r\n				</tr>\r\n			</table>\r\n		</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td valign="top" bgcolor="#FFFFFF" nowrap colspan="2">\r\n		<a href="$PHP_SELF?action=addcomment&id=$postid&qc=$id"><img border="0" src="themes/$apt->themepath/quote.gif" align="left"></a>\r\n$Cedit_link\r\n</td>\r\n	</tr>\r\n</table>\r\n<br>');
INSERT INTO rafia_templates VALUES (36, 'portal', 'news_addcomment', 2, '<script language="javascript">function checkForm(){document.rafia.spam.value= \'commenttnotspam\';}</script>\r\n<form action="news.php?action=insertcomment" onsubmit="return checkForm(this);" method="post" name="rafia" enctype="multipart/form-data">\r\n	<table border="0" width="90%" cellspacing="0" cellpadding="0">\r\n		<tr>\r\n			<td align="right" class="forum_header">����� ����� </td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<table border="0" width="100%" id="table13" cellpadding="2" class="fontablt">\r\n				<script language="JavaScript">\r\n\r\n        function proces()\r\n        {\r\n            value = document.rafia.post.value;\r\n            len = $countpost - value.length;\r\n            if (len < 0 )\r\n            {\r\n                document.rafia.post.value = document.rafia.post.value.substring(0,$countpost);\r\n                document.rafia.left.value = 0;\r\n            }\r\n            else\r\n            {\r\n                document.rafia.left.value = len\r\n            }\r\n            document.rafia.remain.value = len;\r\n            //alert(\'���� �� : \' + len  );\r\n        }\r\n        </script>\r\n				<tr>\r\n					$namef\r\n				</tr>\r\n				<tr>\r\n					<td align="right" nowrap class="info_bar">������� : </td>\r\n					<td align="right" width="100%">\r\n					<input type="text" name="title" value size="30" class="text_box">\r\n					</td>\r\n				</tr>\r\n				<tr>\r\n					<td align="right" nowrap class="info_bar" valign="top">���� \r\n					: <font color="#FF0000">*</font> <br>\r\n&nbsp;<div align="center">\r\n$smiles\r\n					</div>\r\n					<br>\r\n					��� ���� ��� �� ���� <br>\r\n					��� �� : $countpost ���<br>\r\n					<center><a href="#count" onmouseover="return proces()">������ \r\n					�����</a><a neme="count"><br>\r\n					���� �� :\r\n					<input size="5" name="remain" type="text" value="$countpost">\r\n					<center></center></a></center></td>\r\n					<td align="right" width="100%">\r\n					<table cellpadding="0" cellspacing="0" border="0">\r\n						<tr valign="bottom">\r\n							<td colspan="2">\r\n\r\n</td>\r\n						</tr>\r\n						<tr valign="top">\r\n							<td class="controlbar"></td>\r\n						</tr>\r\n					</table>\r\n					$form_code<br>\r\n					<textarea onmouseover="return proces()" onbeforeeditfocus="return proces()" onmouseout="return proces()" name="post" rows="15" cols="70" id="post" wrap="virtual">$post_text</textarea><input type="hidden" name="left" value="$countpost" size="7" class="text_box"></td>\r\n				</tr>\r\n				<tr>\r\n					<td align="right" nowrap class="info_bar">������� ������� ����������\r\n					</td>\r\n					<td align="right" width="100%">\r\n					<input type="radio" name="H" value="1"> ���\r\n					<input type="radio" name="H" value="0" checked> �� </td>\r\n				</tr>\r\n				<tr>\r\n					<td align="right" nowrap class="info_bar">����� ������ ������\r\n					</td>\r\n					<td align="right" width="100%">\r\n					<input type="radio" name="usesig" value="1" checked> ���&nbsp;\r\n					<input type="radio" name="usesig" value="0"> ��</td>\r\n				</tr>\r\n$formf\r\n				\r\n<input type="hidden" name="cat_id" value="$cat_id">\r\n<input type="hidden" name="post_id" value="$id"> \r\n				<input type="hidden" name="action" value="insertcomment">\r\n				<input type="hidden" name="spam" value="1">\r\n			</table>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td align="center">\r\n<input border="0" src="themes/$apt->themepath/replay.gif" name="dosubmit" width="98" height="24" type="image">\r\n</td>\r\n		</tr>\r\n	</table>\r\n</form>');
INSERT INTO rafia_templates VALUES (37, 'portal', 'forum_list_pagenum', 3, '<table border="0" cellspacing="0" style="border-collapse: collapse; border-width: 0" bordercolor="#111111" width="96%" id="AutoNumber7">\r\n	<tr>\r\n		<td width="100%" valign="bottom">$pagenum </td>\r\n	</tr>\r\n</table>');
INSERT INTO rafia_templates VALUES (38, 'portal', 'forum_list_top', 3, '<table border="0" width="95%" id="table11" cellpadding="2">\r\n	<tr>\r\n		<td class="small">$dscin</td>\r\n		<td align="left"><a href="$PHP_SELF?action=add&amp;cat_id=$cat_id">\r\n		<img border="0" src="themes/$apt->themepath/$cat_img" width="98" height="24"></a></td>\r\n	</tr>\r\n</table>');
INSERT INTO rafia_templates VALUES (39, 'portal', 'forum_list_middle', 3, '<table border="1" width="95%" id="table4" cellspacing="0" cellpadding="0" style="border-collapse: collapse" bordercolor="#DAE9FE">\r\n	<tr>\r\n		<td class="forum_header">&nbsp;</td>\r\n		<td class="forum_header">&nbsp;</td>\r\n		<td width="100%" class="forum_header">\r\n		<img border="0" src="themes/$apt->themepath/topics.gif"></td>\r\n		<td class="forum_header" nowrap="">\r\n		<img border="0" src="themes/$apt->themepath/rep.gif"></td>\r\n		<td class="forum_header">\r\n		<img border="0" src="themes/$apt->themepath/writer.gif"></td>\r\n		<td class="forum_header">\r\n		<img border="0" src="themes/$apt->themepath/visitor.gif"></td>\r\n		<td class="forum_header" width="200">\r\n		<img border="0" src="themes/$apt->themepath/last.gif"></td>\r\n	</tr>\r\n	$forum_topic_list\r\n	<tr>\r\n		<td class="forum_header" colspan="7" style="text-align: left">\r\n		<form method="get">\r\n			<span class="small"><input type="hidden" name="action" value="list">\r\n			<input type="hidden" name="cat_id" value="$cat_id">����� ���\r\n			<select name="orderby" size="1">\r\n			<option value="date" selected="">����� �������</option>\r\n			<option value="reader">��� ������</option>\r\n			<option value="comment">��� ���������</option>\r\n			</select><select name="dir" size="1">\r\n			<option value="ASC" selected="">������</option>\r\n			<option value="DESC">������</option>\r\n			</select> <input type="submit" value="����" class="button"> </span>\r\n		</form>\r\n		</td>\r\n	</tr>\r\n	</form>\r\n</table>');
INSERT INTO rafia_templates VALUES (40, 'portal', 'news_cat_tools', 2, '<center>\r\n<table border="0" cellspacing="1" width="95%">\r\n	<tr>\r\n		<td width="100%">\r\n		<table border="0" cellspacing="0" cellpadding="0" width="100%">\r\n			<tr>\r\n				<td>$Jump</td>\r\n				<td align="left">$add_new_post</td>\r\n			</tr>\r\n		</table>\r\n		</td>\r\n	</tr>\r\n</table>\r\n</center>');
INSERT INTO rafia_templates VALUES (41, 'portal', 'download_list', 4, '<div align="center">\r\n	<table border="0" cellpadding="0" cellspacing="0" width="95%">\r\n		<tr>\r\n			<td bgcolor="#516A93">\r\n			<p align="right">&nbsp;&nbsp;\r\n			<img border="0" src="themes/$apt->themepath/weblinkenter.gif" width="17" height="16">\r\n			<font class="fontablt2d">&nbsp;<font size="4" color="#FFFFFF">$title</font></font><font size="4" color="#FFFFFF">\r\n			</font></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td width="100%">\r\n			<table border="0" cellpadding="2" style="border-collapse: collapse" width="100%" id="AutoNumber1" class="info_bar">\r\n				<tr>\r\n					<td width="100%" bgcolor="#EAF4FB">\r\n					<p align="right">\r\n					<font size="2" face="Tahoma" color="#000080">�������: $ratings&nbsp;\r\n					</font></p>\r\n					</td>\r\n					<td nowrap="" align="left" colspan="3">$rating_avg</td>\r\n				</tr>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n	</table>\r\n</div>\r\n<div align="center">\r\n	<table border="0" width="95%" bgcolor="#ffffff" cellspacing="0" cellpadding="0">\r\n		<tr>\r\n			<td width="32%" valign="top" bgcolor="#F7FBFD">\r\n			<div align="center">\r\n				<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%" cellspacing="5">\r\n					<tr>\r\n						<td>\r\n						<p align="right">\r\n						<font color="#800000" size="2" face="Tahoma">\r\n						<font class="fontablt">���� ������� : $clicks</font> <br>\r\n						<font class="fontablt">����� : $size</font><br>\r\n						<font class="fontablt">������ : $c_comment </font><br>\r\n						<font class="fontablt">������ : $name </font></font></p>\r\n						</td>\r\n					</tr>\r\n				</table>\r\n			</div>\r\n			</td>\r\n			<td height="100%" valign="top">\r\n			<div align="center">\r\n				<table border="0" cellpadding="0" cellspacing="0" width="100%">\r\n					<tr>\r\n						<td valign="top">\r\n						<div align="center">\r\n							<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%" cellspacing="5">\r\n								<tr>\r\n									<td>\r\n									<p align="right"><font face="Tahoma">\r\n									<font class="fontablt"><font size="2">$post_head</font></font><font size="2">\r\n									</font></font></p>\r\n									</td>\r\n								</tr>\r\n							</table>\r\n						</div>\r\n						</td>\r\n					</tr>\r\n					<tr>\r\n						<td valign="top"><br>\r\n						<p align="left">$download_images<br>\r\n						$exp_show</p>\r\n						</td>\r\n					</tr>\r\n				</table>\r\n			</div>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td width="32%" valign="top" bgcolor="#F7FBFD">&nbsp;</td>\r\n			<td height="100%" valign="top" bgcolor="#F7F7F7">\r\n			<div align="center">\r\n				<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%">\r\n					<tr>\r\n						<td>\r\n						<p align="right"><font face="Tahoma">\r\n						<font size="2" color="#800000">&nbsp;</font><span lang="ar-iq"><font size="2"><font color="#800000">\r\n						<img border="0" src="themes/$apt->themepath/link_break.png" width="12" height="12">\r\n						</font>\r\n						<a href="javascript:rafiawin(\'popup.php?action=alert&id=$id\',200,400)">\r\n						<font color="#800000">\r\n						<span style="text-decoration: none">���� ����</span></font></a><font color="#800000">&nbsp; \r\n						|&nbsp;\r\n						<img border="0" src="themes/$apt->themepath/chart_bar.png" width="12" height="12">\r\n						</font>\r\n						<a href="javascript:rafiawin(\'popup.php?action=rated&id=$id\',200,400)">\r\n						<font color="#800000">\r\n						<span style="text-decoration: none">�����</span></font></a><font color="#800000">&nbsp; \r\n						|&nbsp;\r\n						<img border="0" src="themes/$apt->themepath/page_white_edit.png" width="12" height="12">\r\n						</font></font>\r\n						<a href="$PHP_SELF?action=edit&amp;id=$id">\r\n						<font size="2" color="#800000">\r\n						<span style="text-decoration: none">�������</span></font></a></span></font></p>\r\n						</td>\r\n					</tr>\r\n				</table>\r\n			</div>\r\n			</td>\r\n		</tr>\r\n	</table>\r\n</div>\r\n<hr color="#C0C0C0" width="95%" size="1">');
INSERT INTO rafia_templates VALUES (42, 'portal', 'users_tools', 3, '<a href="members.php?action=cp">��������</font></a> | <a href="pm.php">������� ������ \r\n: ($pmumrows )</font></a> | <a href="members.php?action=logout">����� ������</font></a> \r\n$isadmin');
INSERT INTO rafia_templates VALUES (43, 'portal', 'blocm', 7, '<!-- BLOCK START --><hr noshade="" color="#000000" size="1">\r\n<table width="100%" bgcolor="789C70" border="0" cellpadding="1" cellspacing="0">\r\n	<tr>\r\n		<td width="100%" valign="top" align="center"><font class="fontht">{block_head}\r\n		</font></td>\r\n	</tr>\r\n</table>\r\n<hr noshade="" color="#000000" size="1">\r\n<table width="100%" border="0" cellpadding="4" cellspacing="0">\r\n	<tr>\r\n		<td width="100%" align="right">{block_center} </td>\r\n	</tr>\r\n</table>\r\n<!-- BLOCK END -->');
INSERT INTO rafia_templates VALUES (44, 'portal', 'table_cat_module', 1, '<table border="0" width="96%" cellspacing="0">\r\n	<tr>\r\n		<td width="100%" valign="bottom">\r\n		<p align="right" class="catlinkfont"><font size="4">\r\n		<img height="21" src="themes/$themepath/navbits_start.gif" width="21" align="absMiddle" border="0">\r\n		<a href="index.php">$sitetitle</a> <br>\r\n		<img height="15" src="themes/$themepath/icon_bar.gif" width="15" align="absMiddle" border="0">\r\n		<img height="21" src="themes/$themepath/navbits_finallink.gif" width="21" align="absMiddle" border="0">$modulename\r\n		</font></p>\r\n		</td>\r\n	</tr>\r\n</table>');
INSERT INTO rafia_templates VALUES (45, 'portal', 'download_cat_tools', 4, '<table border="0" width="90%" cellspacing="1">\r\n	<tr>\r\n		<td width="100%" align="right">\r\n		<div align="center">\r\n			<table border="0" width="100%" cellspacing="0" cellpadding="0">\r\n				<tr>\r\n					<td width="50%" align="right">$Jump</td>\r\n					<center>\r\n					<td width="50%" align="right">\r\n					<a href="$PHP_SELF?action=add&amp;cat_id=$cat_id">\r\n					<img border="0" src="themes/$apt->themepath/$cat_img" align="left"></a></td>\r\n				</tr>\r\n			</table>\r\n			</center></div>\r\n		</td>\r\n	</tr>\r\n</table>');
INSERT INTO rafia_templates VALUES (46, 'portal', 'table_cat_link', 1, '<br>\r\n<table border="0" width="96%" cellspacing="0">\r\n	<tr>\r\n		<td width="100%" valign="bottom">\r\n		<p align="right" class="catlinkfont"><font size="4">\r\n		<img border="0" src="themes/$themepath/navbits_start.gif" width="21" height="21" align="middle">\r\n		<a href="index.php">$sitetitle</a> � <a href="$self">$part</a> � $CatTree\r\n		</font></p>\r\n		</td>\r\n	</tr>\r\n</table>\r\n<br>');
INSERT INTO rafia_templates VALUES (47, 'portal', 'forum_main_bottom', 3, '<table border="0" width="95%" id="table8" cellspacing="1" cellpadding="0">\r\n	<tr>\r\n		<td class="forum_header" style="text-align: right" colspan="2">�������� \r\n		�������</td>\r\n	</tr>\r\n	<tr>\r\n		<td class="forum_alt1" width="30" bgcolor="#EEEEEE">\r\n		<img border="0" src="themes/$apt->themepath/stats.gif" width="30" height="30"></td>\r\n		<td align="right" class="forum_alt1" width="100%"><span class="small">��� \r\n		�������� ( $fnumrows ) - ��� ������ ( $fnumcomment )</span></td>\r\n	</tr>\r\n</table>\r\n<table border="0" width="95%" id="table8" cellspacing="1" cellpadding="0">\r\n	<tr>\r\n		<td class="forum_header" style="text-align: right" colspan="2">&nbsp;�\r\n		<a href="online.php"><font color="#FFFFFF">���������� ������</font></a>: \r\n		� $online � <span class="small">&nbsp;- �� ������: � $not_user � - �� �������: \r\n		� $user_online � </span></td>\r\n	</tr>\r\n	<tr>\r\n		<td class="forum_alt1" width="30" bgcolor="#EEEEEE">\r\n		<img border="0" src="themes/$apt->themepath/whos_online.gif" width="30" height="30"></td>\r\n		<td align="right" class="small1" width="100%"><span class="small1">&nbsp; \r\n		$users_online</span></td>\r\n	</tr>\r\n</table>\r\n<table border="0" width="95%" id="table8" cellspacing="1" cellpadding="0">\r\n	<tr>\r\n		<td class="forum_header" style="text-align: right" colspan="2">&nbsp;�\r\n		<font color="#FFFFFF">������� ����� ������� �����</font>: � $online_today \r\n		�</td>\r\n	</tr>\r\n	<tr>\r\n		<td class="forum_alt1" width="30" bgcolor="#EEEEEE">\r\n		<img border="0" src="themes/$apt->themepath/whos_online.gif" width="30" height="30"></td>\r\n		<td align="right" class="forum_alt1" width="100%"><span class="small">&nbsp; \r\n		$users_today</span></td>\r\n	</tr>\r\n</table>\r\n<br>\r\n<table border="0" id="table9" cellspacing="1" cellpadding="0" class="forum_alt2">\r\n	<tr>\r\n		<td><img border="0" src="themes/$apt->themepath/on.gif" width="21" height="19"></td>\r\n		<td class="small">������� �����&nbsp;&nbsp;&nbsp; </td>\r\n		<td><img border="0" src="themes/$apt->themepath/off.gif" width="21" height="19"></td>\r\n		<td class="small">�� ���� ������� �����&nbsp;&nbsp;&nbsp; </td>\r\n		<td><img border="0" src="themes/$apt->themepath/lock.gif" width="21" height="19"></td>\r\n		<td class="small">��� ����</td>\r\n	</tr>\r\n</table>\r\n<br>');
INSERT INTO rafia_templates VALUES (48, 'portal', 'forum_comment_table', 3, '<table border="0" width="95%" id="table4" cellspacing="1" cellpadding="0">\r\n	<tr>\r\n		<td width="100%" class="forum_alt3">\r\n		<table border="0" width="100%" id="table16" cellspacing="5" cellpadding="3">\r\n			<tr>\r\n				<td width="20%" class="forum_alt15" valign="top" bgcolor="#DFE9F4" rowspan="2">\r\n				<div align="center">\r\n					<table border="0" cellpadding="0" style="border-collapse: collapse" width="140" cellspacing="3">\r\n						<tr>\r\n							<td>\r\n							<p align="center"><font face="Tahoma">\r\n							<font size="2" color="#800000">&nbsp; ������ :\r\n							</font>\r\n							<a href="members.php?action=info&amp;userid=$userid">\r\n							<font size="2" color="#800000">$username</font></a></span></font></p>\r\n							</td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n							<div align="center">\r\n								<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%" bordercolor="#7394B6" cellspacing="4">\r\n									<tr>\r\n										<td>\r\n										<p align="center">\r\n										<font face="Tahoma" size="2">\r\n										<span class="small">$grouptitle<br>$usertitle</span></font></p>\r\n										</td>\r\n									</tr>\r\n									<tr>\r\n										<td>\r\n										<div align="center">\r\n											<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%" cellspacing="2">\r\n												<tr>\r\n													<td>\r\n													<p align="center">\r\n													<span class="small">\r\n													<font size="2" face="Tahoma">\r\n													$userimgtitle</font></span></p>\r\n													</td>\r\n												</tr>\r\n											</table>\r\n										</div>\r\n										</td>\r\n									</tr>\r\n									<tr>\r\n										<td>\r\n										<div align="center">\r\n	\r\n$avatar_pic<br>$userstatus\r\n\r\n</div>\r\n										</td>\r\n									</tr>\r\n								</table>\r\n							</div>\r\n							</td>\r\n						</tr>\r\n						<tr>\r\n							<td bgcolor="#DFE9F4">\r\n							<div align="center">\r\n								<table border="1" cellpadding="0" style="border-collapse: collapse" width="100%" bordercolor="#7394B6">\r\n									<tr>\r\n										<td bgcolor="#F5F5F5">\r\n										<p align="center"><span class="small">\r\n										<font size="2" face="Tahoma">��������� : \r\n										$allposts</font></span></p>\r\n										</td>\r\n									</tr>\r\n								</table>\r\n							</div>\r\n							</td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n							<div align="center">\r\n								<table border="1" cellpadding="0" style="border-collapse: collapse" width="100%" bordercolor="#7394B6">\r\n									<tr>\r\n										<td bgcolor="#F5F5F5">\r\n										<p align="center">\r\n										<font face="Tahoma" size="2">\r\n										<span class="small"><span lang="ar-iq">�����</span> \r\n										�������<br>\r\n&nbsp;$datetime</span></font></p>\r\n										</td>\r\n									</tr>\r\n								</table>\r\n							</div>\r\n							</td>\r\n						</tr>\r\n						<tr>\r\n							<td>\r\n							<p align="center">&nbsp;</p>\r\n							</td>\r\n						</tr>\r\n					</table>\r\n				</div>\r\n				<p align="center"><span class="small">\r\n				<a href="mail.php?action=sendtousers&amp;userid=$userid">\r\n				<img border="0" src="themes/$apt->themepath/email.gif" alt="������">\r\n				</a><a href="$homepage" target="_blank">\r\n				<img border="0" src="themes/$apt->themepath/home.gif" alt="������ ������"></a>\r\n<br>	\r\n<a href="mail.php?action=report&id=$thread_id&comment=$id" title="���� �� ��� ��������"><img border="0" src="images/report.gif"></a>				</span></p>\r\n				\r\n				</td>\r\n				<td width="80%" valign="top" class="normal" colspan="2">\r\n				<span class="small"><a name="comment$id"></a>\r\n				<font color="#808080">��� �� $date   ||   ��� �������� : <A href=#comment$id name=comment$id>$id</A>\r\n				</font></span><hr color="#7394B6" size="1">\r\n				<p align="right"> <b>$title</b><br>$comment <br>\r\n				<br>\r\n				$upload_file\r\n&nbsp;</p>\r\n				<div align="center">\r\n					<table border="0" cellpadding="0" style="border-collapse: collapse" width="90%">\r\n						<tr>\r\n							<td><fieldset style="padding: 2">\r\n							<legend>����� ( <span class="small">\r\n							<a href="members.php?action=info&amp;userid=$userid">\r\n							$username</a></span> )</legend>\r\n							<div align="center">\r\n								<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%" cellspacing="3">\r\n									<tr>\r\n										<td><center>$signature</center></td>\r\n									</tr>\r\n								</table>\r\n							</div>\r\n							</fieldset></td>\r\n						</tr>\r\n					</table>\r\n					<p>&nbsp;</p>\r\n				</div>\r\n				</td>\r\n			</tr>\r\n			<tr>\r\n				<td width="40%" valign="top" class="small"></td>\r\n				<td width="40%" valign="top" align="left">\r\n				<a href="pm.php?action=sendmsg&amp;id=$userid">\r\n				<img border="0" src="themes/$apt->themepath/pm.gif" width="93" height="24">\r\n				</a>\r\n$edit_post\r\n				<a href="$PHP_SELF?action=addcomment&amp;id=$postid&amp;qc=$id">\r\n				<img border="0" src="themes/$apt->themepath/quote.gif" width="67" height="24"></a>\r\n				<a href="#top">\r\n				<img border="0" src="themes/$apt->themepath/top.gif" width="24" height="24"></a></td>\r\n			</tr>\r\n		</table>\r\n		</td>\r\n	</tr>\r\n</table>');
INSERT INTO rafia_templates VALUES (49, 'portal', 'news_cat', 2, '<br>\r\n<table border="0" cellpadding="0" cellspacing="0" width="100%">\r\n	<tr>\r\n		<td align="center" width="100%" style="padding: 3"> \r\n<a href="news.php?action=list&cat_id=$id">$cat_image</a></td>\r\n	</tr>\r\n	<tr>\r\n		<td width="100%" style="padding: 3"> <font class="fontht">\r\n		<img border="0" src="images/b1.gif" align="middle" width="8" height="8">\r\n		<a href="news.php?action=list&amp;cat_id=$id">$title</a></font>\r\n		<span class="fontablt">\r\n		<img border="0" src="images/topics.gif" align="middle" alt="��� ��������">\r\n		<font color="#C0C0C0">[$numrows]\r\n		<img border="0" src="images/replys.gif" alt="��� ������" align="absmiddle"> \r\n		[$numcomment]</font></span></td>\r\n	</tr>\r\n	<tr>\r\n		<td width="100%" class="fontablt"><font color="#808080">$dsc</font></td>\r\n	</tr>\r\n</table>');
INSERT INTO rafia_templates VALUES (50, 'portal', 'popup_msg', 1, '<body bgcolor="#FFFFFF">\r\n\r\n<br>\r\n<div align="center">\r\n	<center>\r\n	<table border="0" width="80%" bgcolor="#F1F1F1">\r\n		<tr>\r\n			<td width="100%" align="center"><br>\r\n			<font class="fontablt">$msg<br>\r\n			<br>\r\n			</font></td>\r\n		</tr>\r\n	</table>\r\n	</center></div>');
INSERT INTO rafia_templates VALUES (51, 'portal', 'Login_main', 1, '<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0">\r\n\r\n<center>\r\n<table border="0" cellpadding="0" cellspacing="0" width="$themewidth" height="100%" bgcolor="#FFFFFF">\r\n	<tr>\r\n		<!-- RightStart -->\r\n		<!-- RightEnd -->\r\n		<td width="100%" valign="top" align="center" style="padding: 5px">\r\n		<font class="fontablt"><br>\r\n		<br>\r\n		<br>\r\n		<br>\r\n		<br>\r\n&nbsp;<table border="1" width="90%" bordercolor="#F1F1F1" bgcolor="#FFFFFF" cellpadding="4" cellspacing="0" id="table5">\r\n			<tr>\r\n				<td width="100%" align="center">\r\n				<font class="fontablt" face="Tahoma" size="2">�� ���� �� ����� ��� \r\n				������� ���� ��� ���� ����� ������ �� �� ���� ����� ������ ������ \r\n				������� ��� �� ��� �� ������ ����� ���� </font></td>\r\n			</tr>\r\n		</table>\r\n		<br>\r\n		<!-- BLOCK START -->\r\n		<table width="350" border="0" cellspacing="0" id="table6">\r\n			<tr>\r\n				<td width="100%" bgcolor="#34597D" style="padding-top: 3; padding-bottom: 3" class="forum_header">\r\n				<p align="center"><font face="Tahoma" size="2" color="#FFFFFF">����� \r\n				������ </font></p>\r\n				</td>\r\n			</tr>\r\n		</table>\r\n		<table width="100%" border="0" cellpadding="4" cellspacing="0" id="table7">\r\n			<tr>\r\n				<td width="100%"><center>\r\n				<table border="0" width="350" id="table8" cellpadding="0" cellspacing="0">\r\n					<tr>\r\n						<td width="100%">\r\n						<form method="post" action="members.php?action=login">\r\n						</td>\r\n						</tr>\r\n						<tr>\r\n							<td bgcolor="#F2F2F2" align="center">\r\n							<font face="tahoma" size="2">��������</font></td>\r\n						</tr>\r\n						<tr>\r\n							<td bgcolor="#F2F2F2" align="center">\r\n							<input type="textbox" name="username" size="13">\r\n							</td>\r\n						</tr>\r\n						<tr>\r\n							<td bgcolor="#F2F2F2" align="center">\r\n							<font face="tahoma" size="2">���� ������</font></td>\r\n						</tr>\r\n						<tr>\r\n							<td bgcolor="#F2F2F2" align="center">\r\n							<input type="password" name="userpass" size="13">\r\n							</td>\r\n						</tr>\r\n						<tr>\r\n							<td bgcolor="#F2F2F2" align="center">\r\n							<input type="submit" value="     ����     ">&nbsp;&nbsp;&nbsp;&nbsp;\r\n							<a href="javascript:rafiawin(\'popup.php?action=remind\',250,350)">\r\n							<font face="tahoma" size="2">����� ������ʿ</font></a>\r\n							</td>\r\n						</tr>\r\n					</form>\r\n					</td>\r\n					</tr>\r\n				</table>\r\n				</center></td>\r\n			</tr>\r\n		</table>\r\n		</font></td>\r\n		<!-- LeftStart -->\r\n		<!-- LeftEnd -->\r\n	</tr>\r\n</table>\r\n</center>');
INSERT INTO rafia_templates VALUES (52, 'portal', 'post_tools', 1, '<table border="0" width="95%" id="table11" cellpadding="2">\r\n	<tr>\r\n		<td class="small">$pagenum</td>\r\n		<td align="left">$add_new_post $add_new_reply </td>\r\n	</tr>\r\n</table>');
INSERT INTO rafia_templates VALUES (53, 'portal', 'download_topic', 4, '<body bgcolor="#DEE9ED" topmargin="0" leftmargin="0">\r\n\r\n$pagehd\r\n<table border="1" cellpadding="4" cellspacing="0" style="border-collapse: collapse; border-width: 0" bordercolor="111111" width="100%" id="AutoNumber7" bgcolor="$bgcolor2">\r\n	<tr>\r\n		<td width="20%" valign="top" align="center" bgcolor="$bgcolor1">$right_menu\r\n		<br>\r\n		</td>\r\n		<td width="60%" valign="top" align="center"><br>\r\n		$next_old $next_new <br>\r\n		$table_cat_link $download_table <br>\r\n		$post_tools $admin_Jump $comment_table <br>\r\n		$post_tools2 $list_Jump <br>\r\n		</td>\r\n		<td width="20%" valign="top" align="center" bgcolor="$bgcolor1">$left_menu\r\n		</td>\r\n	</tr>\r\n</table>\r\n</center></div>\r\n$pageft');
INSERT INTO rafia_templates VALUES (54, 'portal', 'news_list_pagenum', 2, '<br>\r\n<table border="0" cellpadding="4" cellspacing="0" width="95%">\r\n	<tr>\r\n		<td width="50%" valign="bottom">$pagenum </td>\r\n		<td width="50%" align="right">$add_new_post</td>\r\n	</tr>\r\n</table>');
INSERT INTO rafia_templates VALUES (55, 'portal', 'search_form', 1, '<script language="JavaScript">\r\nfunction showop(elem) {\r\n  var val = elem.options[elem.selectedIndex].value;\r\ndocument.getElementById(\'rnews\').style.display=\'none\';\r\ndocument.getElementById(\'rforum\').style.display=\'none\';  document.getElementById(\'rlinks\').style.display=\'none\';\r\ndocument.getElementById(\'rdownload\').style.display=\'none\';\r\ndocument.getElementById("rforumuser").style.display="none";\r\n  if (val == \'rafia_news\')\r\n    { \r\n    document.getElementById(\'rnews\').style.display="block";\r\ndocument.getElementById("rforumuser").style.display="inline";\r\n}\r\n    if (val == \'rafia_forum\')\r\n    { \r\n    document.getElementById(\'rforum\').style.display="block";\r\n    document.getElementById("rforumuser").style.display="inline";\r\n  }\r\n    if (val == \'rafia_links\')\r\n    { \r\n    document.getElementById(\'rlinks\').style.display="block";\r\n  }\r\n    if (val == \'rafia_download\')\r\n    { \r\n    document.getElementById(\'rdownload\').style.display="block";\r\n  }\r\n}\r\n</script>\r\n<br>\r\n\r\n\r\n\r\n<form name="search_form" action="search.php" method="post">\r\n	<center>\r\n	<table cellpadding="0" cellspacing="0" width="90%" id="table1">\r\n		<tr>\r\n			<td width="2%"  class="forum_header2">\r\n</td>\r\n			<td width="100%" class="forum_header2">\r\n			<p align="center"><font size="4">���� �����\r\n			</font></p>\r\n			</td>\r\n			<td width="1%" height="31" bgcolor="#F3F9FC">&nbsp;</td>\r\n		</tr>\r\n	</table>\r\n	<table cellpadding="0" cellspacing="0" width="90%">\r\n		<tr>\r\n			<td class="row1" valign="top" bgcolor="#F1F1F1">\r\n			<div align="center">\r\n<table cellspacing="4" cellpadding="0" width="100%" align="center" border="0">\r\n                        <tr>\r\n                        <td valign="top" width="15">\r\n                            </td>\r\n                            <td valign="top" height="0">\r\n\r\n  <b> <span lang="ar-sa">���� ����� </span></b>\r\n\r\n  <select name="searchin" style="font-weight: 700" onchange="showop(this)">\r\n<option selected value="rafia_news">�������</option>\r\n<option value="rafia_forum">�������</option>\r\n<option value="rafia_links">�������</option>\r\n<option value="rafia_download">�������</option>\r\n\r\n</select><b>\r\n\r\n<br>  <span lang="ar-sa"> ���� �����</span></b><input name=searchfor size=25 style="font-weight: 700"></td>\r\n                            <td valign="top" height="0" >\r\n\r\n  <span lang="ar-sa">&nbsp;<input type="radio" name="spell" value="1"><b> �����\r\n������� ����� ����� ������</span>\r\n\r\n<br>\r\n  <span lang="ar-sa">&nbsp;<input type="radio" name="spell" value="0" checked><b> ������ ������</span>\r\n</td>\r\n                            </tr>\r\n                            </table>				\r\n			</div>\r\n			</td>\r\n		</tr>\r\n	</table>\r\n<br>\r\n	<table cellpadding="0" style="border-collapse: collapse;" width="89%">\r\n		<tr>\r\n			<td width="2%" class="forum_header2">\r\n</td>\r\n			<td width="96%" class="forum_header2">\r\n			<p align="center"><font class="fontabfflt2" size="4">����� �����\r\n			</font></p>\r\n			</td>\r\n			<td width="1%" background="themes/$apt->themepath/table_02.jpg" height="31" bgcolor="#F3F9FC">&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td class="row1" valign="top" colspan="3" bgcolor="#F1F1F1">\r\n			<div align="center">\r\n				<table cellspacing="4" cellpadding="0" width="100%" align="center" border="0">\r\n<tr id="rforumuser" style="display:inline"><td><b>����� ���� ����� (�������)\r\n</td>\r\n<td>\r\n<input name=membername size=25 style="font-weight: 700">\r\n</td></tr>\r\n\r\n<tr><td><b>����� �� ������� (�������)\r\n</td><td>\r\n\r\n<div id="rnews" >\r\n$catnews\r\n</div>\r\n<div id="rforum" style="display:none">\r\n$catforum\r\n</div>\r\n\r\n<div id="rlinks" style="display:none">\r\n$catlinks\r\n</div>\r\n\r\n<div id="rdownload" style="display:none">\r\n$catdownload\r\n</div>\r\n</td></tr>\r\n\r\n                        <tr>\r\n                        <td valign="middle"  width="200">\r\n                        <b>����� ��..</b></td>\r\n<td>\r\n<select name="from_date" class="forminput">\r\n<option value="1">��� �����</option>\r\n<option value="7">��� �����</option>\r\n<option value="30" selected>��� ���</option>\r\n<option value="91">��� 3 ����</option>\r\n<option value="182">��� ��� ����</option>\r\n<option value="365">��� ���</option>\r\n<option value="0">��� �������</option>\r\n</select>\r\n</td></tr>\r\n<tr>\r\n                            <td valign="middle">\r\n<b>��� ��������� �� ���� �������</b><br></td>\r\n  <td valign="top">\r\n<select name="search_max">\r\n<option value="10">10</option>\r\n<option value="20">20</option>\r\n<option value="30" selected>30</option>\r\n<option value="40">40</option>\r\n<option value="50">50</option> </select>\r\n</td></tr>\r\n<tr>\r\n<td valign="top">\r\n<b>����� ������� ����</b><br></td>\r\n  <td valign="top">\r\n<select name="search_orderby">\r\n<option value="timestamp">����� ��������</option>\r\n<option value="c_comment">��� ������</option>\r\n<option value="reader">��� ��������</option>\r\n<option value="name">��� ������</option>\r\n</select>\r\n</td>\r\n                            </tr>\r\n<tr><td><b>����� ����� �������</td>\r\n<td>\r\n<input type="radio" name="search_order" value="DESC" checked>&nbsp;&nbsp;<b>��������\r\n<br><input type="radio" name="search_order" value="ASC">&nbsp;&nbsp;<b>��������\r\n</tr></tr>\r\n                            </table>\r\n			</div>\r\n			</td>\r\n		</tr>\r\n	</table>\r\n	<p align="center">&nbsp;</p>\r\n	<p align="center">\r\n	<input type="submit" name="submit" value="���" style="border-style: solid; border-width: 1; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1"></p>\r\n	</center>\r\n</form>');
INSERT INTO rafia_templates VALUES (56, 'portal', 'news_table', 2, '<table border="0" cellpadding="3" cellspacing="3" width="100%">\r\n	<tr>\r\n		<td valign="top" colspan="2">\r\n		<div class="news_title">\r\n			<img border="0" src="themes/$apt->themepath/news_icon.gif" width="12" height="12"> \r\n			$title</div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td align="right" valign="top">\r\n		<div class="article_info">\r\n			<img border="0" src="themes/$apt->themepath/info.gif" width="13" height="18"> \r\n			������: <a href="members.php?action=info&amp;userid=$userid">$username</a><br>\r\n			������ : $date </div>\r\n		</td>\r\n		<td valign="top">\r\n		<p align="left">\r\n		<a href="javascript:rafiawin(\'popup.php?action=printnews&id=$id\',500,600)">\r\n		<img border="0" src="themes/$apt->themepath/print_page.gif" width="70" height="24"></a><a href="mail.php?action=sendpage"><img border="0" src="themes/$apt->themepath/send_f.gif" width="70" height="24"></a><a href="pdf.php?id=$id"><img border="0" src="themes/$apt->themepath/pdf.gif" width="70" height="24"></a><br>\r\n		<a href="translate.php">\r\n		<img border="0" src="themes/$apt->themepath/t.gif" width="70" height="24"></a><a href="filemanager.php?action=save&id=$id"><img border="0" src="themes/$apt->themepath/save.gif" width="70" height="24"></a><a href="$PHP_SELF?action=addcomment&amp;id=$postid"><img border="0" src="themes/$apt->themepath/add_comment.gif" width="70" height="24"></a></p>\r\n		</td>\r\n		</td>\r\n	</tr>\r\n</table>\r\n<table border="0" cellpadding="3" cellspacing="3" width="100%">\r\n	<tr>\r\n		<td align="right" width="100%" class="normal">\r\n		<div class="article_pic">\r\n			$newsimage</div>\r\n		$news_head<br>\r\n		$post </td>\r\n	</tr>\r\n	<tr>\r\n		<td width="100%">\r\n		<div class="article_info">\r\n			<img border="0" src="themes/$apt->themepath/info.gif" width="13" height="18"> \r\n			���� �������: $reader - ���������: $c_comment</div>\r\n		</td>\r\n	</tr>\r\n</table>\r\n<hr color="#C0C0C0" width="95%" size="1" style="border-style: dotted; border-width: 1px">\r\n<br>\r\n<b><center>$topic_nav</center></b>');
INSERT INTO rafia_templates VALUES (57, 'portal', 'register_policy', 6, '<table border="0" width="98%" id="table1" cellspacing="0" cellpadding="0" bgcolor="#EDF7FA">\r\n	<tr>\r\n		<td width="9" height="31">&nbsp;</td>\r\n		<td width="100%">\r\n		<p align="right"><font class="fontablt2" color="#800000" size="4">������� \r\n		������ �������</font></p>\r\n		</td>\r\n	</tr>\r\n</table>\r\n$reg_rules');
INSERT INTO rafia_templates VALUES (58, 'portal', 'index_table', 1, '<table border="0" cellpadding="0" cellspacing="0" width="100%">\r\n	<tr>\r\n		<td height="28">\r\n		<div class="news_title">\r\n			<img border="0" src="themes/$apt->themepath/news_icon.gif" width="12" height="12">\r\n			<a href="$news_link">$title</a></div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td width="100%">\r\n		<table border="0" style="border-collapse: collapse" width="100%" id="AutoNumber1" class="article_info">\r\n			<tr>\r\n				<td width="100%">\r\n				<div class="article_info">\r\n					<img border="0" src="themes/$apt->themepath/info.gif" width="13" height="18"> \r\n					������: <a href="members.php?action=info&amp;userid=$userid">\r\n					$name</a> ������: $date </div>\r\n				</td>\r\n				<td nowrap="" align="left" colspan="3"></td>\r\n			</tr>\r\n		</table>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td width="100%" style="padding-top: 5; padding-bottom: 5; text-align: justify">\r\n		$newsimage <font class="home_text">$news_head </font></td>\r\n	</tr>\r\n	<tr>\r\n		<td width="100%" class="info_bar2" style="padding-top: 5; padding-bottom: 5">\r\n		<p align="right"><a href="$news_link">\r\n		<img border="0" src="themes/$apt->themepath/readmore.gif" align="left"></a>\r\n		</p>\r\n		<div class="article_info">\r\n&nbsp; ������: $reader&nbsp;&nbsp;&nbsp; ���������: $numrows </div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td width="100%">$pagenum </td>\r\n	</tr>\r\n</table>\r\n<hr style="border: 1px dotted #516A93" size="1">');
INSERT INTO rafia_templates VALUES (59, 'portal', 'announcement', 1, '');
INSERT INTO rafia_templates VALUES (60, 'portal', 'members_link', 6, '<center>\r\n<table border="0" width="304">\r\n	<tr>\r\n		<td width="76" bgcolor="$bgcolor5">\r\n		<p align="center"><a href="members.php?action=cp">\r\n		<img border="0" src="themes/$apt->themepath/personal.jpg" width="76" height="56"></a></p>\r\n		</td>\r\n		<td width="76" bgcolor="$bgcolor5">\r\n		<p align="center"><a href="pm.php">\r\n		<img border="0" src="themes/$apt->themepath/pr_msg.jpg" width="76" height="56"></a></p>\r\n		</td>\r\n		<td width="76" bgcolor="$bgcolor5">\r\n		<p align="center"><a href="members.php?action=edit">\r\n		<img border="0" src="themes/$apt->themepath/setting.jpg" width="76" height="56"></a></p>\r\n		</td>\r\n		<td width="76" bgcolor="$bgcolor5">\r\n		<p align="center"><a href="members.php?action=changepass">\r\n		<img border="0" src="themes/$apt->themepath/change_pass.jpg" width="76" height="56"></a></p>\r\n		</td>\r\n	</tr>\r\n</table>\r\n</center>');
INSERT INTO rafia_templates VALUES (61, 'portal', 'upblock', 7, '<!-- BLOCK START -->\r\n<table width="171" border="0" cellpadding="0" style="border-collapse: collapse">\r\n	<tr>\r\n		<td height="26" background="themes/$apt->themepath/menu_head.gif">\r\n		<p align="right"><font class="side_menu_head">&nbsp;&nbsp;&nbsp;&nbsp; {block_head}</font></p>\r\n		</td>\r\n	</tr>\r\n	</tr>\r\n	<tr>\r\n		<td style="padding-right: 0px" class="side_menu_center">\r\n		<p align="center">\r\n		<marquee style="FONT-SIZE: 12pt; COLOR: #000000; FONT-FAMILY: Times New Roman; TAHOMA: 150%" scrollamount="2" scrolldelay="50" direction="up" width="165" height="161">{block_center}</marquee></p>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td style="padding-right: 0px" class="side_menu_center">&nbsp;</td>\r\n	</tr>\r\n	<tr>\r\n		<td style="padding-right: 0px" class="side_menu_center">\r\n		<img border="0" src="themes/$apt->themepath/menu_but.gif"></td>\r\n	</tr>\r\n</table>\r\n<table border="0" cellpadding="0" style="border-collapse: collapse" width="171">\r\n	<tr>\r\n		<td>&nbsp;</td>\r\n	</tr>\r\n</table>\r\n<!-- BLOCK END -->');
INSERT INTO rafia_templates VALUES (62, 'portal', 'index_table_cat_title', 1, '<table border="0" cellpadding="0" cellspacing="0" width="95%">\r\n	<tr>\r\n		<td width="8" height="28">\r\n		<img border="0" src="themes/$apt->themepath/cat_right.gif" width="8" height="28"></td>\r\n		<td background="themes/$apt->themepath/cat_bg.gif" width="100%">\r\n		<div class="news_cat_title">\r\n			<a title="$ctitle" href="news.php?action=list&amp;cat_id=$cid">$ctitle</a></div>\r\n		</td>\r\n		<td width="7" height="28">\r\n		<img border="0" src="themes/$apt->themepath/cat_left.gif" width="7" height="28"></td>\r\n	</tr>\r\n</table>');
INSERT INTO rafia_templates VALUES (63, 'portal', 'index_block', 1, '<!--INC dir="block" file="index_download.php" -->\r\n<!--INC dir="block" file="links.php" -->');
INSERT INTO rafia_templates VALUES (64, 'portal', 'show_members_list', 6, '<tr>\r\n<td bgcolor="$color"><font class=fontablt> $userid</font></td>\r\n      <td bgcolor="$color"><font class=fontablt>  \r\n<a href="members.php?action=info&userid=$userid">$username</a></font></td>\r\n      <td bgcolor="$color"><font class=fontablt>$allposts </font></td>\r\n<td bgcolor="$color"><font class=fontablt> $regdate</font></td>\r\n      <td bgcolor="$color" align="center"><font class=fontablt>\r\n    <a href=\'mail.php?action=sendtousers&userid=$userid\' ><img border=\'0\' src=\'themes/apt/email.gif\' alt=\'������ ��������\' width=\'16\' height=\'16\'></a>  \r\n    <a href=\'$homepage\' target=_blank><img border=\'0\' src=\'themes/apt/home.gif\' alt=\'������\' width=\'16\' height=\'16\'> </a>\r\n  </font></td>\r\n    </tr>');
INSERT INTO rafia_templates VALUES (65, 'portal', 'turn_off_site', 1, '<body bgcolor="#FFFFFF">\r\n\r\n<br>\r\n<br>\r\n<br>\r\n<br>\r\n<br>\r\n<br>\r\n<br>\r\n<br>\r\n<div align="center">\r\n	<center>\r\n	<table border="0" width="80%" bgcolor="#EBEBEB">\r\n		<tr>\r\n			<td width="100%" align="center"><font class="fontablt"><b>$turn_off_msg</font></b><br>\r\n			<br>\r\n			<table width="100%" border="0" cellpadding="4" cellspacing="0" id="table7">\r\n				<tr>\r\n					<td width="100%"><center>\r\n					<table border="0" width="350" id="table8" cellpadding="0" cellspacing="0">\r\n						<tr>\r\n							<td width="100%">\r\n							<form method="post" action="members.php?action=login">\r\n							</form>\r\n							</td>\r\n						</tr>\r\n						<tr>\r\n							<td bgcolor="#F2F2F2" align="center">\r\n							<span lang="ar-om"><b>���� ������ ����� ���</b></span></td>\r\n						</tr>\r\n						<tr>\r\n							<td bgcolor="#F2F2F2" align="center">\r\n							<font face="tahoma" size="2">�������� : </font>\r\n							<input type="textbox" name="username" size="13">\r\n							</td>\r\n						</tr>\r\n						<tr>\r\n							<td bgcolor="#F2F2F2" align="center">\r\n							<font face="tahoma" size="2">���� ������ : </font>\r\n							<input type="password" name="userpass" size="13">\r\n							</td>\r\n						</tr>\r\n						<tr>\r\n							<td bgcolor="#F2F2F2" align="center">\r\n							<input type="submit" value="���� ������ �����"></td>\r\n						</tr>\r\n						</form>\r\n					</table>\r\n					<br>\r\n					</center></td>\r\n				</tr>\r\n			</table>\r\n			</center></div>\r\n\r\n			</body>\r\n\r\n		</html>\r\n		</td>\r\n	</tr>\r\n</table>\r\n</center></div>');
INSERT INTO rafia_templates VALUES (66, 'portal', 'download_list_pagenum', 4, '<br>\r\n<table border="0" cellpadding="4" cellspacing="0" width="95%">\r\n	<tr>\r\n		<td width="50%" valign="bottom">$pagenum </td>\r\n		<td width="50%" align="right">\r\n		<a href="$PHP_SELF?action=add&amp;cat_id=$cat_id">\r\n		<img border="0" src="themes/$apt->themepath/$cat_img" align="left"></a></td>\r\n	</tr>\r\n</table>');
INSERT INTO rafia_templates VALUES (67, 'portal', 'news_add', 2, '<script language="javascript">\r\nfunction checkForm(){\r\ndocument.rafia.spam.value =\'newsnotspam_$cap\';\r\n}\r\n</script>\r\n<form onsubmit="return checkForm(this)" action="news.php?action=insert" method="post" name="rafia" enctype="multipart/form-data">\r\n	<table border="0" width="90%" cellspacing="0" cellpadding="0">\r\n		<tr>\r\n			<td align="right" class="forum_header">����� ��� </td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<table border="0" width="100%" id="table13" cellpadding="2" class="fontablt">\r\n				$usernamef$useridf$selectform<tr>\r\n					<td align="right" nowrap="" class="info_bar">������� :\r\n					<font color="#FF0000">*</font> </td>\r\n					<td align="right" width="100%">\r\n					<input type="text" name="title" value="" size="35" class="text_box">\r\n					</td>\r\n				</tr>\r\n				$txtcounth<tr>\r\n					<td align="right" nowrap="" class="info_bar" valign="top">��� \r\n					����� : <br>�������</td>\r\n					<td align="right" width="100%">\r\n					<textarea name="post_head" rows="8" cols="60" onkeypress="return countIt();"></textarea></td>\r\n				</tr>\r\n				$editor$txtcount<tr>\r\n					<td align="right" nowrap="" class="info_bar" valign="top">��\r\n					����� : <font color="#FF0000">*</font> <br>\r\n					��� ���� ��� �� ���� <br>\r\n					��� �� : $countpost ���<br>\r\n					<center><a href="#" onmouseover="return proces()">������ �����</a><br>\r\n					���� �� :\r\n					<input size="5" name="remain" type="text" value="$countpost">\r\n					<center></center></center></td>\r\n					<td align="right" width="100%">$form_code<br>\r\n					<textarea onmouseover="return proces()" onbeforeeditfocus="return proces()" onmouseout="return proces()" name="post" rows="15" cols="60" id="post" wrap="virtual"></textarea><input type="hidden" name="left" value="$countpost" size="7" class="text_box"></td>\r\n				</tr>\r\n				<tr>\r\n					<td align="right" nowrap="" class="info_bar">������� ������� \r\n					���������� </td>\r\n					<td align="right" width="100%">\r\n					<input type="radio" name="H" value="1"> ���\r\n					<input type="radio" name="H" value="0" checked> �� </td>\r\n				</tr>\r\n				<tr>\r\n					<td align="right" nowrap="" class="info_bar">��� ������� �� \r\n					���� ������ɿ </td>\r\n					<td align="right" width="100%">\r\n					<input type="radio" name="inindex" value="1" checked=""> ���&nbsp;\r\n					<input type="radio" name="inindex" value="0"> ��</td>\r\n				</tr>\r\n				<tr>\r\n					<td align="right" nowrap="" class="info_bar">��� ������� �� \r\n					����� ��� ������ѿ </td>\r\n					<td align="right" width="100%">\r\n					<input type="radio" name="inmenu" value="1"> ���&nbsp;\r\n					<input type="radio" name="inmenu" value="0" checked=""> ��</td>\r\n				</tr>\r\n				$main_n<tr>\r\n					<td align="right" nowrap="" class="info_bar">������� ������ \r\n					���������� ����� </td>\r\n					<td align="right" width="100%">\r\n					<input type="radio" name="catmig" value="1"> ���&nbsp;\r\n					<input type="radio" name="catmig" value="0" checked=""> ��</td>\r\n				</tr>\r\n\r\n\r\n				$fileupload $imgupload\r\n$chose_func\r\n			<input type="hidden" name="spam" value="spam">\r\n				<input type="hidden" name="action" value="insert">\r\n						</table>\r\n						</td>\r\n					</tr>\r\n					<tr>\r\n						<td align="center">\r\n<input border="0" src="themes/$apt->themepath/newnews.gif" name="dosubmit" type="image">\r\n</td>\r\n					</tr>\r\n				</table> </form>');
INSERT INTO rafia_templates VALUES (68, 'portal', 'link_add', 5, '<script language="javascript">\r\nfunction checkForm(){\r\n	if (!document.rafia.title.value) {\r\n		alert(\'���� ... ��� �� ��� ������ ��� ������\'); \r\n		return false;\r\n	} \r\n	if (document.rafia.url.value==\'http://\') {\r\n		alert(\'���� ... ��� �� ��� ������ ����� ������\'); \r\n		return false;\r\n	} \r\n	if (!document.rafia.post.value) {\r\n		alert(\'���� ... ��� �� ��� ������ ��� ������\'); \r\n		return false;\r\n	} \r\ndocument.rafia.spam.value =\'linknotspam_$cap\';\r\n}\r\n</script>\r\n<form onsubmit="return checkForm(this)" action="link.php?action=insert" method="post" name="rafia" enctype="multipart/form-data">\r\n	<table border="0" width="90%" cellspacing="0" cellpadding="0">\r\n		<tr>\r\n			<td align="right" class="forum_header">����� ���� </td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<table border="0" width="100%" id="table13" cellpadding="2" class="fontablt">\r\n				$cat<tr>\r\n					<td align="right" nowrap="" class="info_bar">��� ������ :\r\n					<font color="#FF0000">*</font> </td>\r\n					<td align="right" width="100%">\r\n					<input type="text" name="title" value="" size="35" class="text_box">\r\n					</td>\r\n				</tr>\r\n				<tr>\r\n					<td align="right" nowrap="" class="info_bar">����� ������ :\r\n					<font color="#FF0000">*</font> </td>\r\n					<td align="right" width="100%">\r\n					<input type="text" name="url" value="http://" size="50" class="text_box">\r\n					</td>\r\n				</tr>\r\n				$yrname $yrmail<script language="JavaScript">\r\n        function proces()\r\n        {\r\n            value = document.rafia.post.value;\r\n            len = $countpost - value.length;\r\n            if (len < 0 )\r\n            {\r\n                document.rafia.post.value = document.rafia.post.value.substring(0,$countpost);\r\n                document.rafia.left.value = 0;\r\n            }\r\n            else\r\n            {\r\n                document.rafia.left.value = len\r\n            }\r\n            document.rafia.remain.value = len;\r\n            //alert(\'���� �� : \' + len  );\r\n        }\r\n        </script>\r\n				<tr>\r\n					<td align="right" nowrap="" class="info_bar" valign="top">��� \r\n					���� : <font color="#FF0000">*</font> <br>\r\n					��� ���� ��� �� ���� <br>\r\n					��� �� : $countpost ���<br>\r\n					<center><a href="#" onmouseover="return proces()">������ �����</a><br>\r\n					���� �� :\r\n					<input size="5" name="remain" type="text" value="$countpost">\r\n					<center></center></center></td>\r\n					<td align="right" width="100%"><br>\r\n					<textarea onmouseover="return proces()" onbeforeeditfocus="return proces()" onmouseout="return proces()" name="post" rows="8" cols="60" id="post" wrap="virtual"></textarea><input type="hidden" name="left" value="$countpost" size="7" class="text_box">\r\n					<input type="hidden" name="action" value="insert"></td>\r\n				</tr>\r\n				<input type="hidden" name="spam" value="spam">\r\n			</table>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td align="right" align="center">\r\n			<input border="0" src="themes/$apt->themepath/site.gif" name="I1" type="image"></td>\r\n		</tr>\r\n	</table>\r\n</form>');
INSERT INTO rafia_templates VALUES (69, 'portal', 'middle_menu', 7, '<!-- BLOCK START -->\r\n<table width="100%" border="0" cellpadding="0" cellspacing="0">\r\n	<tr>\r\n		<td width="9" height="24" background="themes/$apt->themepath/cat_bg.jpg">&nbsp;</td>\r\n		<td background="themes/$apt->themepath/cat_bg.jpg" width="100%">\r\n		<p align="center"><font class="side_menu_head">{block_head}</font> </p>\r\n		</td>\r\n		<td width="9" height="24" background="themes/$apt->themepath/cat_bg.jpg">&nbsp;</td>\r\n	</tr>\r\n	</tr>\r\n	<tr>\r\n		<td height="120" valign="top" colspan="3" bgcolor="#F1F1F1" style="padding-right: 5px" class="side_menu_center">\r\n		{block_center} <br>\r\n		</td>\r\n	</tr>\r\n</table>\r\n<br>\r\n<!-- BLOCK END -->');
INSERT INTO rafia_templates VALUES (70, 'portal', 'index_main_table', 1, '<table border="0" cellpadding="0" cellspacing="0" width="100%">\r\n	<tr>\r\n		<td height="28">\r\n		<div class="news_title">\r\n			<img border="0" src="themes/$apt->themepath/news_icon.gif" width="12" height="12">\r\n			<a href="$news_link">$title</a></div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td width="100%">\r\n		<table border="0" style="border-collapse: collapse" width="100%" id="AutoNumber1" class="article_info">\r\n			<tr>\r\n				<td width="100%">\r\n				<div class="article_info">\r\n					<img border="0" src="themes/$apt->themepath/info.gif" width="13" height="18"> \r\n					������: <a href="members.php?action=info&amp;userid=$userid">\r\n					$name</a> ������: $date </div>\r\n				</td>\r\n				<td nowrap="" align="left" colspan="3"></td>\r\n			</tr>\r\n		</table>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td width="100%" style="padding-top: 5; padding-bottom: 5; text-align: justify">\r\n		$newsimage <font class="home_text">$news_head </font></td>\r\n	</tr>\r\n	<tr>\r\n		<td width="100%" class="info_bar2" style="padding-top: 5; padding-bottom: 5">\r\n		<p align="right"><a href="$news_link">\r\n		<img border="0" src="themes/$apt->themepath/readmore.gif" align="left"></a>\r\n		</p>\r\n		<div class="article_info">\r\n&nbsp; ������: $reader&nbsp;&nbsp;&nbsp; ���������: $numrows </div>\r\n		</td>\r\n	</tr>\r\n	<tr>\r\n		<td width="100%">$pagenum </td>\r\n	</tr>\r\n</table>\r\n<hr style="border: 1px dotted #516A93" size="1">');
INSERT INTO rafia_templates VALUES (71, 'portal', 'guestbook_add', 1, '<script language="javascript">\r\nfunction checkForm(){\r\n	if (!document.rafia.name.value) {\r\n		alert(\'���� ... ��� �� ��� ������ �����\'); \r\n		return false;\r\n	} \r\n	if (!document.rafia.email.value) {\r\n		alert(\'���� ... ��� �� ��� ������ �������\'); \r\n		return false;\r\n	} \r\n	if (!document.rafia.post.value) {\r\n		alert(\'���� ... ��� �� ��� ������ �� �������\'); \r\n		return false;\r\n	} \r\ndocument.rafia.spam.value =\'guestnotspam_$cap\';\r\n\r\n}\r\n</script>\r\n<form onsubmit="return checkForm(this)" action="guestbook.php?action=insert" method="post" name="rafia" enctype="multipart/form-data">\r\n	<table border="0" width="90%" cellspacing="0" cellpadding="0">\r\n		<tr>\r\n			<td align="right" class="forum_header">����� ����� </td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<table border="0" width="100%" id="table13" cellpadding="2" class="fontablt">\r\n				<tr>\r\n					<td align="right" nowrap="" class="info_bar">����� :\r\n					<font color="#FF0000">*</font> </td>\r\n					<td align="right" width="100%">\r\n					<input type="text" name="name" value="" size="35" class="text_box">\r\n					</td>\r\n				</tr>\r\n				<tr>\r\n					<td align="right" nowrap="" class="info_bar">������ ���������� \r\n					: <font color="#FF0000">*</font> </td>\r\n					<td align="right" width="100%">\r\n					<input type="text" name="email" value="" size="30" class="text_box">\r\n					</td>\r\n				</tr>\r\n				<tr>\r\n					<td align="right" nowrap="" class="info_bar">������ : </td>\r\n					<td align="right" width="100%">\r\n					<input type="text" name="url" value="http://" size="50" class="text_box">\r\n					</td>\r\n				</tr>\r\n				$txtcount_java<tr>\r\n					<td align="right" nowrap="" class="info_bar" valign="top">������� \r\n					: <font color="#FF0000">*</font><a neme="count"> $use_smiles\r\n					<br>\r\n					��� ���� ��� �� ���� <br>\r\n					��� �� : $txtcount_count ���<br>\r\n					<center></a><a href="#count" onmouseover="return proces()">������ \r\n					�����</a><br>\r\n					���� �� :\r\n					<input size="5" name="remain" type="text" value="$txtcount_count">\r\n					<center></center></center></td>\r\n					<td align="right" width="100%"><br>\r\n					<textarea onmouseover="return proces()" onbeforeeditfocus="return proces()" onmouseout="return proces()" name="post" rows="8" cols="60" id="post" wrap="virtual"></textarea><input type="hidden" name="left" value="$txtcount_count" size="7" class="text_box">\r\n					<input type="hidden" name="spam" value="1"></td>\r\n				</tr>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td align="right" align="center">\r\n			<input border="0" src="themes/$apt->themepath/sign.gif" name="I1" width="98" height="24" type="image"></td>\r\n		</tr>\r\n	</table>\r\n</form>');


#------------------- TABLE rafia_temptype -------------------
DROP TABLE IF EXISTS rafia_temptype; 

CREATE TABLE `rafia_temptype` (
  `tempid` int(10) unsigned NOT NULL auto_increment,
  `temptypetitle` varchar(100) NOT NULL default '',
  `tempdsc` longtext NOT NULL,
  PRIMARY KEY  (`tempid`)
) ;

INSERT INTO rafia_temptype VALUES (1,'����� ����','');
INSERT INTO rafia_temptype VALUES (2,'����� �������','');
INSERT INTO rafia_temptype VALUES (3,'����� �������','');
INSERT INTO rafia_temptype VALUES (4,'����� ���� �������','');
INSERT INTO rafia_temptype VALUES (5,'����� ���� �������','');
INSERT INTO rafia_temptype VALUES (6,'����� �������','');
INSERT INTO rafia_temptype VALUES (7,'����� �������','');


#------------------- TABLE rafia_upload -------------------
DROP TABLE IF EXISTS rafia_upload; 

CREATE TABLE `rafia_upload` (
  `upid` int(10) NOT NULL auto_increment,
  `upcatid` int(10) NOT NULL default '0',
  `uppostid` int(10) NOT NULL default '0',
  `uptypes` varchar(100) NOT NULL default '',
  `upname` varchar(100) NOT NULL default '',
  `upsize` int(10) NOT NULL default '0',
  `upstat` int(10) NOT NULL default '0',
  `upcat` varchar(10) NOT NULL default '',
  `upend` varchar(10) NOT NULL default '',
  `upuserid` int(10) NOT NULL default '0',
  `upclicks` int(10) default '0',
  `timestamp` int(11) NOT NULL default '0',
  `imagealign` varchar(5) NOT NULL default '0',
  PRIMARY KEY  (`upid`)
) ;

INSERT INTO rafia_upload VALUES (1, 1, 1, 'image/gif', 'book.gif', 14203, 1, 'news', 'gif', 1, 2, 0, 'right');

#------------------- TABLE rafia_users -------------------
DROP TABLE IF EXISTS rafia_users; 

CREATE TABLE `rafia_users` (
  `userid` smallint(5) unsigned NOT NULL auto_increment,
  `username` varchar(100) NOT NULL default '',
  `password` varchar(100) NOT NULL default '',
  `useradmin` tinyint(10) NOT NULL default '0',
  `usergroup` int(10) NOT NULL default '0',
  `grouptitle` varchar(100) NOT NULL default '',
  `email` varchar(100) NOT NULL default '',
  `allposts` int(10) NOT NULL default '0',
  `homepage` varchar(100) NOT NULL default '',
  `showemail` int(1) NOT NULL default '0',
  `signature` text NOT NULL,
  `avatar` tinyint(1) NOT NULL default '0',
  `datetime` int(11) NOT NULL default '0',
  `allowpost` char(3) NOT NULL default '',
  `activate` varchar(255) NOT NULL default '',
  `usertheme` varchar(100) NOT NULL default '0',
  `html_msg` tinyint(1) NOT NULL default '1',
  `lastadd` int(11) NOT NULL default '0',
  `viewemail` int(1) NOT NULL default '0',
  `statpm` int(1) NOT NULL default '0',
  `userip` varchar(20) NOT NULL default '0',
  `lastlogin` int(11) NOT NULL default '0',
  PRIMARY KEY  (`userid`)
) ;

INSERT INTO rafia_users VALUES (1,'admin','fe01ce2a7fbac8fafaed7c982a04e229',1,1,'','admin@site.com',7,'http://www.arabportal.info',1,'�������','','','yes','8810849','portal',1,1171307967,'','','62.231.248.120',1171576420);
INSERT INTO rafia_users VALUES (2,'����','','',5,'','',0,'','','','','','yes','5708617','portal',1,'','','','',1163753968);


#------------------- TABLE rafia_usertitles -------------------
DROP TABLE IF EXISTS rafia_usertitles; 

CREATE TABLE `rafia_usertitles` (
  `id` tinyint(3) unsigned NOT NULL auto_increment,
  `title` varchar(50) NOT NULL default '',
  `posts` int(10) unsigned NOT NULL default '0',
  `Iconrep` int(11) NOT NULL default '1',
  KEY `id` (`id`),
  KEY `Posts` (`posts`)
) ;

INSERT INTO rafia_usertitles VALUES (1, '��� ����', 1, 1);
INSERT INTO rafia_usertitles VALUES (2, '��� �����', 30, 2);
INSERT INTO rafia_usertitles VALUES (3, '��� ����', 70, 3);
INSERT INTO rafia_usertitles VALUES (4, '��� ����', 150, 4);

