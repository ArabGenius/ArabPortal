<?php
/*
+===========================================+
|      ArabPortal V2.2.x Copyright � 2008   |
|   -------------------------------------   |
|                     BY                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Info      |
|   -------------------------------------   |
|  Last Updated: 08/08/2008 Time: 06:00 AM  |
+===========================================+
*/

error_reporting  (E_ERROR | E_WARNING | E_PARSE);

@extract($_POST);
@extract($_GET);
@extract($_SERVER);

echo  "<html dir=\"rtl\"> 
<head> 
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1256\"> 
<meta http-equiv=\"Content-Language\" content=\"ar-sa\"> 
<title>����� ������ ������� �������</title> 
<link rel=\"stylesheet\" type=\"text/css\" href=\"./../html/css/portal.css\"></head>";
?>
 
<body background="./../themes/portal/background.gif" topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0">

<div align="center">
	<table border="0" width="100%" id="table2" cellspacing="0" cellpadding="0">
		<tr>
			<td width="100%">
			<div align="center">
				<table border="0" cellpadding="0" style="border-collapse: collapse">
					<tr>
						<td width="18">
						<img border="0" src="./../themes/portal/arabportal_06.gif"></td>
						<td background="./../themes/portal/arabportal_03.gif">&nbsp;</td>
						<td background="./../themes/portal/arabportal_03.gif">
						</td>
						<td background="./../themes/portal/arabportal_03.gif" width="100%">
						</td>
						<td width="16">
						<img border="0" src="./../themes/portal/arabportal_01.gif" width="77" height="30"></td>
					</tr>
				</table>
			</div>
			</td>
		</tr>
	</table>
</div>
<center>
<table border="0" width="100%" cellspacing="0" cellpadding="0">
	<tr>
		<td width="47">
		<img border="0" src="./../themes/portal/arabportal_12.gif"></td>
		<td width="284">
		<img border="0" src="./../themes/portal/arabportal_11.gif"></td>
		<td background="./../themes/portal/arabportal_10.gif" width="100%">
		</td>
		<td>
		<img border="0" src="./../themes/portal/arabportal_08.gif"></td>
		<td>
		<img border="0" src="./../themes/portal/arabportal_07.gif"></td>
	</tr>
</table>
</center>
<div align="center">
	<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%">
		<tr>
			<td width="30">
			<img border="0" src="./../themes/portal/last_teat_55.gif"></td>
			<td width="100%" background="./../themes/portal/last_teat_02.gif">&nbsp;</td>
			<td width="25">
			<img border="0" src="./../themes/portal/last_teat_01.gif"></td>
		</tr>
	</table>
</div>
<div align="center">
	<table border="0" width="100%" cellpadding="0" style="border-collapse: collapse" height="50%">
		<tr>
			<td nowrap bgcolor="#516A93" width="18">&nbsp;</td>
			<td width="100%" valign="top" align="center" style="padding: 5px" bgcolor="#FFFFFF">
			<br>
&nbsp;<table border="0" width="100%" cellpadding="0" style="border-collapse: collapse">
				<tr>
					<td width="9">
					<img border="0" src="./../themes/portal/frame_index_03.gif" width="14" height="14"></td>
					<td background="./../themes/portal/frame_index_02.gif">
					<img border="0" src="./../themes/portal/frame_index_02.gif" width="61" height="14"></td>
					<td width="8">
					<img border="0" src="./../themes/portal/frame_index_01.gif" width="15" height="14"></td>
				</tr>
				<tr>
					<td width="9" background="./../themes/portal/frame_index_06.gif" height="160">
					<img border="0" src="./../themes/portal/frame_index_06.gif" width="14" height="56"></td>
					<td height="160">									<center>
									<img border="0" src="./../themes/portal/install_welcome.gif">
									</center><br>
<?
if ((!$step) or ($step == 0)){

@unlink('../upload/test.txt');
@unlink('../html/test.txt');
@unlink('../html/css/test.txt');
@unlink('../html/Cache/test.txt');

if(! is_writeable('../admin/conf.php')){
$confState = "<li><font color=red>��� �� ���� ��� admin/conf.php ������� 666</font>";
$false = true;
}else $confState = "<li><font color=green>��� conf.php ���� ������� �������</font>";

if(!@fopen( '../upload/test.txt' , "w" )){
$uploadState = "<li><font color=red>��� �� ���� ���� upload ������� 777</font>";
$false = true;
}else $uploadState = "<li><font color=green>���� upload ���� ������� �������</font>";

if(!@fopen( '../html/test.txt' , "w" )){
$htmlState = "<li><font color=red>��� �� ���� ���� html ������� 777</font>";
$false = true;
}else $htmlState = "<li><font color=green>���� html ���� ������� �������</font>";

if(!@fopen( '../html/css/test.txt' , "w" )){
$cssState = "<li><font color=red>��� �� ���� ���� css ������� 777</font>";
$false = true;
}else $cssState = "<li><font color=green>���� css ���� ������� �������</font>";

if(!@fopen( '../html/Cache/test.txt' , "w" )){
$CacheState = "<li><font color=red>��� �� ���� ���� Cache ������� 777</font>";
$false = true;
}else $CacheState = "<li><font color=green>���� Cache ���� ������� �������</font>";

echo "<br><h3 class=\"small_dark_link\">������ ������:</h3>������� ������� � �������� :<br>
$uploadState <br> $htmlState <br> $cssState <br> $CacheState <br>$confState";

@unlink('../upload/test.txt');
@unlink('../html/test.txt');
@unlink('../html/css/test.txt');
@unlink('../html/Cache/test.txt');

if($false == true){
echo "<br><br><center><font color=red>�� ���� ��������� �������� �� <a href=index.php>���� ���</a> ������ ����� ������</font></center>";
}else{
echo "<br><br><center><a href=index.php?step=1><font color=blue>����� ��� ������ �������</font></a></center>";}

}elseif($step == 1){
$path = ereg_replace("install","",getcwd());
$uppath = ereg_replace("install","upload",getcwd());
$path = substr("$path",0,-1);
$link = 'http://'.$SERVER_NAME.$PHP_SELF;
$link = ereg_replace("/install/index.php","",$link);
$cookie = str_replace('www.','',$SERVER_NAME);
$k_site = str_replace('www.','',$SERVER_NAME);
$end = strchr($cookie,'.');
$cookie = str_replace($end,'',$cookie);

function createRandom() {
    $chars = "abcdefghijkmnopqrstuvwxyz";
    srand((double)microtime()*1000000);
    $i = 0;
    $pass = '' ;
    while ($i <= 5) {
        $num = rand() % 33;
        $tmp = substr($chars, $num, 1);
        $pass = $pass . $tmp;
        $i++;
    }
    return $pass;
}

$cookie = $cookie.createRandom();
$kpath = str_replace('install', '', dirname($HTTP_SERVER_VARS['PHP_SELF']));
echo "<br><form method=\"POST\" action=\"index.php?step=2\">
  <table border=\"0\" width=\"80%\" cellspacing=\"0\" cellpadding=\"0\">
    <tr>
      <td>
      <table border=\"0\" width=\"100%\" id=\"table13\" cellpadding=\"2\" class=\"fontablt\">
        <tr>
          <td nowrap class=\"td_top_cat\">&nbsp;������� ������� : </td>
          <td width=\"100%\"></td>
        </tr>
        <tr>
          <td nowrap class=\"info_bar\">&nbsp;��� ������� : </td>
          <td width=\"100%\">
          &nbsp;<input type=\"text\" name=\"servername\" value=\"localhost\" size=\"36\" class=\"text_box\" dir=\"ltr\">
          </td>
        </tr>
        <tr>
          <td nowrap class=\"info_bar\">&nbsp;��� ������� :</td>
          <td width=\"100%\">
          &nbsp;<input type=\"text\" name=\"server_db\" size=\"36\" class=\"text_box\" dir=\"ltr\"></td>
        </tr>
        <tr>
          <td nowrap class=\"info_bar\">&nbsp;������ �������:</td>
          <td width=\"100%\">
          &nbsp;<input type=\"text\" name=\"server_un\" size=\"36\" class=\"text_box\" dir=\"ltr\"></td>
        </tr>
        <tr>
          <td nowrap class=\"info_bar\">&nbsp;���� ���� �������:</td>
          <td width=\"100%\">
          &nbsp;<input type=\"password\" name=\"server_pass\" size=\"36\" class=\"text_box\" dir=\"ltr\"></td>
        </tr>
        <tr>
          <td nowrap class=\"td_top_cat\">&nbsp;���� �������� : </td>
          <td width=\"100%\"></td>
        </tr>
        <tr>
          <td nowrap class=\"info_bar\">&nbsp;���� ������ :</td>
          <td width=\"100%\">
          &nbsp;<input type=\"text\" name=\"sitepath\" value=\"$path\" size=\"36\" class=\"text_box\" dir=\"ltr\"></td>
        </tr>
        <tr>
          <td nowrap class=\"info_bar\">&nbsp;���� upload :</td>
          <td width=\"100%\">
          &nbsp;<input type=\"text\" name=\"uppath\" value=\"$uppath\" size=\"36\" class=\"text_box\" dir=\"ltr\"></td>
        </tr>
        <tr>
          <td nowrap class=\"info_bar\">&nbsp;���� ������:</td>
          <td width=\"100%\">
          &nbsp;<input type=\"text\" name=\"sitelink\" value=\"$link\" size=\"36\" class=\"text_box\" dir=\"ltr\"></td>
        </tr>
        <tr>
          <td nowrap class=\"td_top_cat\">&nbsp;������� ������� : </td>
          <td width=\"100%\"></td>
        </tr>
        <tr>
          <td nowrap class=\"info_bar\">&nbsp;��� ������� :</td>
          <td width=\"100%\">
          &nbsp;<input type=\"text\" name=\"cookie\" value=\"$cookie\" size=\"36\" class=\"text_box\" dir=\"ltr\"></td>
        </tr>
        <tr>
          <td nowrap class=\"info_bar\">&nbsp;���� ������� :</td>
          <td width=\"100%\">
          &nbsp;<input type=\"text\" name=\"domain\" value=\"$k_site\" size=\"36\" class=\"text_box\" dir=\"ltr\"></td>
        </tr>
        <tr>
          <td nowrap class=\"info_bar\">&nbsp;������� �������<br>�� ���� ������ :</td>
          <td width=\"100%\">
          &nbsp;<select name=use_cookies>
		<option value=\"0\" class=\"text_box\">��</option>
		<option value=\"1\" class=\"text_box\">���</option></select></td>
        </tr>
        <tr>
          <td nowrap class=\"td_top_cat\">&nbsp;������� ������ : </td>
          <td width=\"100%\"></td>
        </tr>
        <tr>
          <td nowrap class=\"info_bar\">&nbsp;����� ������ :</td>
          <td width=\"100%\">
          &nbsp;<input type=\"text\" name=\"sitetitle\" value=\"������� �������\" size=\"36\" class=\"text_box\" dir=\"rtl\"></td>
        </tr>
        <tr>
          <td nowrap class=\"info_bar\">&nbsp;����� ������ :</td>
          <td width=\"100%\">
          &nbsp;<input type=\"text\" name=\"sitemail\" value=\"webmaster@domain.com\" size=\"36\" class=\"text_box\" dir=\"ltr\"></td>
        </tr>
        <tr>
          <td nowrap class=\"info_bar\">&nbsp;����� ����� ������ :</td>
          <td width=\"100%\">
          &nbsp;<select name=Theme_From_File>
		<option value=\"0\" class=\"text_box\">�� ����� ��������</option>
		<option value=\"1\" class=\"text_box\">�� ������� ��������</option></select></td>
        </tr>
        <tr>
          <td nowrap class=\"td_top_cat\">&nbsp;������� ������ ����� : </td>
          <td width=\"100%\"></td>
        </tr>
        <tr>
        <tr>
          <td nowrap class=\"info_bar\">&nbsp;��� ������ �����:</td>
          <td width=\"100%\">
          &nbsp;<input type=\"text\" name=\"username\" value=\"\" size=\"36\" class=\"text_box\" dir=\"rtl\"></td>
        </tr>
        <tr>
          <td nowrap class=\"info_bar\">&nbsp;���� ������ ������ �����:</td>
          <td width=\"100%\">
          &nbsp;<input type=\"password\" name=\"password\" value=\"\" size=\"36\" class=\"text_box\" dir=\"ltr\"></td>
        </tr>
      </table>
      </td>
    </tr>
    <tr>
      <td align=\"center\">
      <input border=\"0\" src=\"./../themes/portal/do.gif\" name=\"I1\" width=\"98\" height=\"24\" type=\"image\"></td>
    </tr>
  </table>
  <p><br>
  </p>
</form>";

}elseif($step == 2){

$sercon = @mysql_connect($servername,$server_un,$server_pass);
$dbcon = @mysql_select_db($server_db,$sercon);

if(!$sercon){
echo "<br><br><center><font color=red><h3>���� �� ��� ������� �������� ����� ������� �������</h3></font></center>";
}elseif(!$dbcon){
echo "<br><br><center><font color=red><h3>���� �� ��� ������� �������� ����� ������� �������</h3></font></center>";
}elseif(empty($username) || empty($password)){
echo "<br><br><center><font color=red><h3>���� .. ��� ����� ��� � ���� ���� ������ �����</h3></font></center>";
}else{
$filename = "install.sql";
@set_time_limit(900);
$w = 1;

	$cur_sql = '';

	if(function_exists('file')){
	$sql_file = file($filename);}else{
	$open = fopen($filename,'r');
	$fdata = fread($open,filesize($filename));
	$sql_file = explode("\n",$fdata);}

	foreach($sql_file as $v) {

		$sql = trim($v);

		if($sql[0] == '#') {
			continue;
		}

		if(!$sql) {
			continue;
		}

		$cur_sql .= $sql . ' ';
		if(substr($sql, -1, 1) == ';') {
			$sql_statements[] = substr(trim($cur_sql), 0, -1);
			$cur_sql = '';
		}
	}
	if(count($sql_statements)) {
		foreach($sql_statements as $k=>$v) {
			if(!mysql_query($v)) {
$wrong = mysql_error();
$ww = $w++;
$xxx .= "$ww => $wrong in [$v]\n\n";

}
}
}
$password = md5($password);
$timenow = time();
@mysql_query("update rafia_users set username='$username',password='$password',datetime='$timenow' where userid='1'");
@mysql_query("update rafia_users set datetime='$timenow' where userid='2'");
@mysql_query("update rafia_settings set value='$sitetitle' where variable='sitetitle'");
@mysql_query("update rafia_settings set value='$sitemail' where variable='sitemail'");
@mysql_query("update rafia_settings set value='$sitelink' where variable='siteURL'");

if($wrong){
echo "<br><h3 class=\"small_dark_link\">������ �������:</h3>���� .. ���� ����� �� ����� ����� ������� � ��";
echo "<br><center><textarea dir=ltr cols=100 rows=10>";
echo $xxx;
echo "</textarea></center>";
}else{
echo "<br><h3 class=\"small_dark_link\">������ �������:</h3>�� ����� ����� SQL ������� �����";
}


echo "<br>";
echo "<h3 class=\"small_dark_link\">������ �������:</h3>";
$op = @fopen('conf.php' , "r");
$sz = @filesize('conf.php');
$tx = @fread($op,$sz);

$tx = str_replace("{path}","$sitepath",$tx);
$tx = str_replace("{uppath}","$uppath",$tx);
$tx = str_replace("{sitetitle}","$sitetitle",$tx);
$tx = str_replace("{guest}","2",$tx);
$tx = str_replace("{sitemail}","$sitemail",$tx);
$tx = str_replace("{sitelink}","$sitelink",$tx);
$tx = str_replace("{kpath}","$kpath",$tx);
$tx = str_replace("{domain}","$domain",$tx);
$tx = str_replace("{cookie}","$cookie",$tx);
$tx = str_replace("{use_cookies}","$use_cookies",$tx);
$tx = str_replace("{Theme_From_File}","$Theme_From_File",$tx);
$tx = str_replace("{db_conntype}","0",$tx);
$tx = str_replace("{server_name}","$servername",$tx);
$tx = str_replace("{server_db}","$server_db",$tx);
$tx = str_replace("{server_un}","$server_un",$tx);
$tx = str_replace("{server_pass}","$server_pass",$tx);
$conf_open = @fopen("./../admin/conf.php",w);
@fwrite($conf_open,$tx);
@fclose($conf_open);
if($conf_open){
echo "����� ����� ������� ������� 2.2<br>���� ��� conf.php ������� 444 �� 644 � ��� �������<br>�� ���� ���� ������� install ������ ������ �� <a href=./../index.php>���� ���</a><br>";
}else{
echo "�� ���� ����� ��� �� ��� conf.php , �� �� ����� � ���� ���� install<br>";
echo "<textarea dir=ltr cols=100 rows=30>";
echo $tx;
echo "</textarea>";
}

}

}
?>

					</td>
					<td width="8" background="./../themes/portal/frame_index_04.gif" height="160">
					<img border="0" src="./../themes/portal/frame_index_04.gif" width="15" height="56"></td>
				</tr>
				<tr>
					<td width="9">
					<img border="0" src="./../themes/portal/frame_index_09.gif" width="14" height="14"></td>
					<td background="./../themes/portal/frame_index_08.gif">
					<img border="0" src="./../themes/portal/frame_index_08.gif" width="61" height="14"></td>
					<td width="8">
					<img border="0" src="./../themes/portal/frame_index_07.gif" width="15" height="14"></td>
				</tr>
			</table>
			</td>
			<td nowrap bgcolor="#516A93" width="19">&nbsp;</td>
		</tr>
	</table>
</div>
<!-- Footer Start -->
<div align="center">
	<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%">
		<tr>
			<td width="18">
			<img border="0" src="./../themes/portal/arabportal_20.gif" width="18" height="20"></td>
			<td width="4%" align="center" style="color: #3F81A1; font-family: Tahoma; font-size: 10pt">
			<img border="0" src="./../themes/portal/footer_right.gif"></td>
			<td background="./../themes/portal/f_midd.gif" width="100%" align="center" style="color: #3F81A1; font-family: Tahoma; font-size: 10pt">
			</td>
			<td background="./../themes/portal/footer_03.jpg" width="2%" align="center" style="color: #3F81A1; font-family: Tahoma; font-size: 10pt">
			<img border="0" src="./../themes/portal/footer_left.gif"></td>
			<td width="19">
			<img border="0" src="./../themes/portal/arabportal_16.gif" width="19" height="20"></td>
		</tr>
	</table>
</div>
<center>
<table border="0" cellpadding="0" width="100%" id="table2" style="border-collapse: collapse">
	<tr>
		<td background="./../themes/portal/mm_space.gif">
		<img border="0" src="./../themes/portal/mm_space.gif" width="8" height="6"></td>
		<td background="./../themes/portal/mm_space.gif" width="100%" align="center" style="color: #3F81A1; font-family: Tahoma; font-size: 10pt">
		<img border="0" src="./../themes/portal/mm_space.gif" width="8" height="6"></td>
		<td background="./../themes/portal/mm_space.gif">
		<img border="0" src="./../themes/portal/mm_space.gif" width="8" height="6"></td>
	</tr>
	<tr>
		<td background="./../themes/portal/arabportal_20.gif">
		<img border="0" src="./../themes/portal/arabportal_20.gif" width="18" height="20"></td>
		<td width="100%" align="center" style="color: #3F81A1; font-family: Tahoma; font-size: 10pt">
		<div align="center">
			<table border="0" cellpadding="0" style="border-collapse: collapse">
				<tr>
					<td width="20" background="./../themes/portal/ft_bt_02.gif">
					<img border="0" src="./../themes/portal/ft_bt_04.gif"></td>
					<td width="4" background="./../themes/portal/ft_bt_02.gif">
					<img border="0" src="./../themes/portal/verline.gif" width="1" height="50"></td>
					<td width="9" background="./../themes/portal/ft_bt_02.gif">
					<a target="_blank" href="http://www.rowafid.com">
					<img border="0" src="./../themes/portal/rowafid.gif" width="29" height="68"></a></td>
					<td width="20" background="./../themes/portal/ft_bt_02.gif">
					<img border="0" src="./../themes/portal/ft_bt_02.gif" width="32" height="68"></td>
					<td width="20" background="./../themes/portal/ft_bt_02.gif">
					<form action="members.php">
						<input type="hidden" name="action" value="chngthem">
						<span lang="en-us">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						</span>
					</form>
					</td>
					<td background="./../themes/portal/ft_bt_02.gif" width="100%">
					<div align="center">
						<table border="0" style="border-collapse: collapse" cellspacing="3">
							<tr>
								<td>
								<div align="center">
									<table border="0" cellpadding="0" style="border-collapse: collapse" width="365" height="32">
										<tr>
											<td background="./../themes/portal/copyright.gif">
											<p align="center" dir="ltr">
											<font color="#000055" face="Verdana" size="2">
											Copyright� 2009</font><font face="Verdana" size="2" color="#000055">
											<img border="0" src="./../themes/portal/logo.gif">
											</font>
											<font face="Verdana" size="2">
											<font face="Verdana" size="2" color="#000055">
											&#1576;&#1573;&#1587;&#1578;&#1582;&#1583;&#1575;&#1605;</font>
											<a target="_blank" class="footer_link" href="http://www.arabportal.info">
											<font color="#800000">&#1576;&#1585;&#1606;&#1575;&#1605;&#1580; &#1575;&#1604;&#1576;&#1608;&#1575;&#1576;&#1577; 
											&#1575;&#1604;&#1593;&#1585;&#1576;&#1610;&#1577; </font></a>
											<font color="#800000">2.2</font></font></p>
											</td>
										</tr>
									</table>
								</div>
								</td>
							</tr>
						</table>
					</div>
					</td>
					<td width="20" background="./../themes/portal/ft_bt_02.gif">
					<img border="0" src="./../themes/portal/ft_bt_02.gif" width="150" height="68"></td>
					<td width="2" background="./../themes/portal/ft_bt_02.gif">
					<a href="#top">
					<img border="0" src="./../themes/portal/top.gif" width="24" height="24"></a></td>
					<td width="1" background="./../themes/portal/ft_bt_02.gif">
					</td>
					<td width="2" background="./../themes/portal/ft_bt_02.gif">
					</td>
					<td width="4" background="./../themes/portal/ft_bt_02.gif">
					</td>
					<td width="9" background="./../themes/portal/ft_bt_02.gif">
					</td>
					<td width="4" background="./../themes/portal/ft_bt_02.gif">
					<img border="0" src="./../themes/portal/verline.gif" width="1" height="50"></td>
					<td width="17" background="./../themes/portal/ft_bt_02.gif">
					<img border="0" src="./../themes/portal/ft_bt_01.gif"></td>
				</tr>
			</table>
		</div>
		</td>
		<td background="./../themes/portal/arabportal_20.gif">
		<img border="0" src="./../themes/portal/arabportal_20.gif" width="18" height="20"></td>
	</tr>
</table>
</center>
<!-- Footer End -->

</body>

</html>