<?php
/***************************************************************************
			   ������ ���� ����� ����� ������� �������
			   ����� ����� ����� || ���� ��� �������
			www.arabiaone.org (arabgenius@hotmail.com)
***************************************************************************/

if (RUN_MODULE !== true)
{
    die ("<center><h3>���� ��� ������� ��� ������</h3></center>");
}

$mod_theme = $mod->modInfo[themeid];
$mod_name = $mod->modInfo[mod_name];
$mod_title = $mod->modInfo[mod_title];
$modid = $mod->modInfo[id];

function jumper(){
global $apt;
$result = $apt->query("SELECT gid,gtitle FROM  rafia_gallery_cat");
$jumptext = "
<form method=get name='jumpbox' action='mod.php'>
<input type=hidden name=mod value=gallery>
<input type=hidden name=modfile value=category>
<select size=1 name=cat>
<option selected value='-1'>���� ������</option>";
while(@extract($apt->dbarray($result))){
$jumptext .= "<option value=$gid>$gtitle</option>";
}
$jumptext .= "</select>
<input type=submit value=����></p>
</form>";
return $jumptext;
}
$jumptext = jumper();

//=========================================
//---------------------------------------------------
//                  ���� ����� ���� �����           /
//---------------------------------------------------
function highlight_words($r){
global $apt;
	if(isset($apt->get['highlight'])){
		$highlight = $apt->format_data(urldecode($apt->get['highlight']));
		$highlight = $apt->spelling_ar_words( intval($apt->get['spell']) , $highlight );
			$r = @ereg_replace($highlight , "<font color=\"#FF0000\"><i><u>\\0</u></i></font>",$r);
	}
	return ($r);
}
//=========================================
    function pre_img($query,$next_link=''){
        global $apt;
        $result = $apt->query($query);
        if ($apt->dbnumrows($result) > 0){
            $row = $apt->dbarray($result);
            if($next_link==''){
                $next_link = "mod.php?mod=gallery&modfile=picshow&imgid=$row[0]";
            }
            return " <img border=\"0\" src=\"images/next.gif\" width=\"6\" height=\"9\"> <a href=\"$next_link\">".LANG_MSG_PREVIOUS."</a> ";
        }
    }
//=========================================
    function next_img($query,$next_link=''){
        global $apt;
        $result = $apt->query($query);
        if ($apt->dbnumrows($result) > 0){
            $row = $apt->dbarray($result);
            if($next_link==''){
                $next_link = "mod.php?mod=gallery&modfile=picshow&imgid=$row[0]";
            }
            return ": <a href=\"$next_link\">".LANG_MSG_NEXT."</a> <img border=\"0\" src=\"images/prev.gif\" width=\"6\" height=\"9\">";
        }
    }
//---------------------------------------------------

?>