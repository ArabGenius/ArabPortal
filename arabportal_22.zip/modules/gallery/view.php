<?php
/***************************************************************************
			   ������ ���� ����� ����� ������� �������
			   ����� ����� ����� || ���� ��� �������
			www.arabiaone.org (arabgenius@hotmail.com)
***************************************************************************/

if (RUN_MODULE !== true){
	die ("<center><h3>���� ��� ������� ��� ������</h3></center>");
}

$imgid = $apt->setid('imgid');
$thumb = intval($apt->get[thumb]);

$result = $apt->query("SELECT * FROM rafia_gallery_image where imgid='$imgid' and allow=1");
if(!$apt->dbnumrows($result)== 0){
	$row = $apt->dbarray($result);
	@extract($row);
	if($thumb == 1){
	$dir = "thumb";
	}else{
	$dir = "photos";
	}
	if(file_exists("modules/gallery/$dir/$imglink")){
		$file_name = basename("modules/gallery/$dir/$imglink");
		$ext = strrchr($file_name,'.');
		$ext = str_replace('.','',$ext);
		$filesize = @filesize("modules/gallery/$dir/$imglink");
		header( "Content-Type: image/$ext");
		header("Content-disposition: inline; filename=$file_name");
		header("Content-Length: $filesize");
		header("Pragma: no-cache");
		header("Expires: 0");
            $open = @fopen("modules/gallery/$dir/$imglink",r);
            $data = @fread($open,@filesize("modules/gallery/$dir/$imglink"));
            @fclose($open);
            print($data);

	if($thumb == 0){
			$update = $apt->query("Update rafia_gallery_image set imgview=imgview+1 where imgid='$imgid'");
	}
		exit;
	}else{
		if($thumb == 1){$file_name = "thumb_404.gif";}else{$file_name = "404.gif";}
		$filesize = @filesize("modules/gallery/themes/images/$file_name");
		header("Content-Type: image/gif");
		header("Content-disposition: inline; filename=$file_name");
		header("Content-Length: $filesize");
		header("Pragma: no-cache");
		header("Expires: 0");
            $open = @fopen("modules/gallery/themes/images/$file_name",r);
            $data = @fread($open,@filesize("modules/gallery/themes/images/$file_name"));
            @fclose($open);
            print($data);

		exit;
	}
}else{
		$file_name = "404.gif";
		$filesize = @filesize("modules/gallery/themes/images/404.gif");
		header("Content-Type: image/gif");
		header("Content-disposition: inline; filename=404.gif");
		header("Content-Length: $filesize");
		header("Pragma: no-cache");
		header("Expires: 0");
            $open = @fopen("modules/gallery/themes/images/404.gif",r);
            $data = @fread($open,@filesize("modules/gallery/themes/images/404.gif"));
            @fclose($open);
            print($data);

		exit;
}

?>