<?php

		include("zip.php");
		$zipfile = new zipfile();
		$zipfile->add_file($file_data, $file_name);
		$zipfile->add_file($file_data2, 'thumb_'.$file_name);
		$zipfile->send("ahmed.zip");
 		exit;


?>