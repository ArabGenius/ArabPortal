<?php


	function getfeed($feed,$count){
	include_once("modules/rss/ConvertCharset.class.php");
	$FromCharset = 'utf-8'; 
	$ToCharset = 'windows-1256'; 
	$convert  = new ConvertCharset();

	$feed = @explode("<item>",$feed);
	foreach($feed as $items){ $i++;
	$item = @explode("\n",$items);
	foreach($item as $line){
		if (strpos($line, '<title>') !== false){
		$tmp_title = str_replace(array('<title>','</title>'), '', trim($line));
		$title = addslashes($tmp_title);
		}
		if (strpos($line, '<url>') !== false || strpos($line, '<link>') !== false){
		$url = str_replace(array('<url>', '</url>', '<link>', '</link>'), '', trim($line));
		}
	}
	if((trim($title) !== '') and (trim($url) !== ''))$text.= "	<img src=modules/rss/images/zoom-headline.gif>&nbsp;&nbsp;<a href=$url target=_blank>$title</a><br>\n";
	if($i == $count)break;
	}
	$text = $convert->Convert($text, $FromCharset, $ToCharset); 
	return $text;
	}

?>