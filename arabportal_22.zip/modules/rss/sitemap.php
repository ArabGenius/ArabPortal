<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|                                           |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 22/10/2006 Time: 10:00 PM  |
+===========================================+
*/

$url = $apt->getsettings("siteURL");
$site= $apt->getsettings("sitetitle");
if(substr($url,-1) != '/'){
$url = $url . '/';
}

header("Content-Type: text/xml");
echo '<?xml version="1.0" encoding="UTF-8"?>
<urlset
      xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
      xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
            http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
';
echo "<url>\n";
echo "<loc>$url</loc>\n";
echo "<priority>1.0</priority>\n";
echo "<changefreq>hourly</changefreq>\n";
echo "</url>\n";

echo "<url>\n";
echo "<loc>".$url."news.php</loc>\n";
echo "<priority>1.0</priority>\n";
echo "<changefreq>hourly</changefreq>\n";
echo "</url>\n";

echo "<url>\n";
echo "<loc>".$url."forum.php</loc>\n";
echo "<priority>1.0</priority>\n";
echo "<changefreq>hourly</changefreq>\n";
echo "</url>\n";

echo "<url>\n";
echo "<loc>".$url."download.php</loc>\n";
echo "<priority>1.0</priority>\n";
echo "<changefreq>hourly</changefreq>\n";
echo "</url>\n";

echo "<url>\n";
echo "<loc>".$url."link.php</loc>\n";
echo "<priority>1.0</priority>\n";
echo "<changefreq>hourly</changefreq>\n";
echo "</url>\n";


$resultm = mysql_query ("SELECT mod_name FROM rafia_mods WHERE mod_sys!='0' ORDER BY mod_name ASC");
while ($row = mysql_fetch_array($resultm)) {
$mod_name = $row['mod_name']; 

echo "<url>\n";
echo "<loc>".$url."mod.php?mod=$mod_name</loc>\n";
echo "<priority>0.9</priority>\n";
echo "<changefreq>hourly</changefreq>\n";
echo "</url>\n";
}

$result = mysql_query ("SELECT id FROM rafia_news
                                 WHERE allow='yes'
                                 ORDER BY id ASC");
while ($row = mysql_fetch_array($result)) {
$id = $row['id']; 

echo "<url>\n";
echo "<loc>".$url."news.php?action=view&amp;id=$id</loc>\n";
echo "<priority>0.8</priority>\n";
echo "<changefreq>daily</changefreq>\n";
echo "</url>\n";

}

$results = mysql_query ("SELECT id FROM rafia_forum
                                 WHERE allow='yes'
                                 ORDER BY id ASC");

while ($row = mysql_fetch_array($results)) {
$id = $row['id']; 
echo "<url>\n";
echo "<loc>".$url."forum.php?action=view&amp;id=$id</loc>\n";
echo "<priority>0.8</priority>\n";
echo "<changefreq>daily</changefreq>\n";
echo "</url>\n";

}

$results = mysql_query ("SELECT id FROM rafia_download
                                 WHERE allow='yes'
                                 ORDER BY id ASC");

while ($row = mysql_fetch_array($results)) {
$id = $row['id']; 
echo "<url>\n";
echo "<loc>".$url."download.php?action=view&amp;id=$id</loc>\n";
echo "<priority>0.7</priority>\n";
echo "<changefreq>weekly</changefreq>\n";
echo "</url>\n";

}

echo "</urlset>";
exit();
?>