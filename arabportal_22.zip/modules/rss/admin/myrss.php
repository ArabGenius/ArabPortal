<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|                                           |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 22/10/2006 Time: 10:00 PM  |
+===========================================+
*/
if (!eregi("mod.php", $PHP_SELF)) { die ("���� ��� ������� ��� ������"); }

$admin->head();
echo "<table border=0 width=80% cellspacing=3 cellpadding=6>
  <tr>
    <td align=center class=datacell><a href=mod.php?act=edit&mod=rss&modid=$modid&$session><b>������ ��������</b></a></td>
    <td align=center class=datacell><a href=mod.php?act=edit&mod=rss&modid=$modid&op=add&$session><b>��� ���� ����</b></a></td>
    <td disabled align=center class=datacell><a href=mod.php?act=edit&mod=rss&modid=$modid&op=myrss&$session><b>������ �������</b></a></td>
  </tr>
</table>
<br>";

echo '
<table border=0 width=80% cellspacing=2 cellpadding=6><tr>
<td width=100% bgcolor=#3A789F colspan=4 align=center  background=images/td_back.gif>
<font color=#FFFFFF><b>����� �������</b></td></tr>';
$url = $apt->getsettings("siteURL");
if(substr($url,-1) != '/'){
$url = $url . '/';
}

echo "
<tr>
<td class=datacell><a target=_blank href=".$url."rss.php><b>�������</b><a/></td>
<td align=center class=datacell><input dir=ltr size=55 type=text value=".$url."rss.php></td>
</tr>
<tr>
<td class=datacell><a target=_blank href=".$url."sitemap.php><b>����� ������</b><a/></td>
<td align=center class=datacell><input dir=ltr size=55 type=text value=".$url."sitemap.php></td>
</tr>
<tr>
<td class=datacell><a target=_blank href=".$url."mod.php?mod=rss&modfile=forum><b>�������</b><a/></td>
<td align=center class=datacell><input dir=ltr size=55 type=text value=".$url."mod.php?mod=rss&modfile=forum></td>
</tr>
<tr>
<td class=datacell><a target=_blank href=".$url."mod.php?mod=rss&modfile=download><b>���� �������</b><a/></td>
<td align=center class=datacell><input dir=ltr size=55 type=text value=".$url."mod.php?mod=rss&modfile=download></td>
</tr>

";


echo '</table>';

?>