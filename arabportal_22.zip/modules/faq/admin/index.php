 <?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 22/10/2006 Time: 10:00 PM  |
+===========================================+
*/

if (!eregi("mod.php", $PHP_SELF)) { die ("���� ��� ������� ��� ������"); }

function oprations(){
global $apt, $admin, $session, $modid, $mod;
echo "<table border=0 width=80% cellspacing=2 cellpadding=6><tr>
    <td width=20% align=center class=datacell><a href=mod.php?act=edit&mod=faq&modid=$modid&$session><b>�����</b></a></td>
    <td width=40% align=center class=datacell><a href=mod.php?act=edit&mod=faq&modid=$modid&opration=addcat&$session><b>��� ����� ����</b></a></td>
    <td width=20% align=center class=datacell><a href=mod.php?act=edit&mod=faq&modid=$modid&opration=add&$session><b>��� ����</b></a></td>
  </tr></table>";
}

    function faqs ($act)
    {
        global $apt, $admin, $session, $modid, $mod;
        $act = $apt->format_data($act);
        if ($act=="")
        {
            $result = $apt->query ("SELECT * FROM rafia_faqcategories ORDER BY cat_id");
            while($row=$apt->dbarray($result))
            {
                @extract($row);
                $list  = array($category,
                               $admin->ViewHref("mod.php?act=edit&mod=faq&modid=$modid&opration=list&cat_id=$cat_id&$session"),
                               $admin->EditHref("mod.php?act=edit&mod=faq&modid=$modid&opration=editcat&cat_id=$cat_id&$session"),
                               $admin->DelHref("mod.php?act=edit&mod=faq&modid=$modid&opration=delcat&cat_id=$cat_id&$session"),
                               );
                $admin->Rows .= $admin->TableCell($list);
            }
            $cellHeader = array("�����" ,"��� ������","�����","���");
            $admin->ColWidth = array(40,20,20,20);
            $admin->head();
	  	oprations();
            echo $admin->Table($cellHeader,"����� �������");
        }
        else if ($act=="delcat")
        {
            $cat_id = $apt->setid('cat_id');
            $result = $apt->query("delete from  rafia_faqcategories where cat_id='$cat_id'");
            if ($result)
            {
                 header("Refresh: 1;url=mod.php?act=edit&mod=faq&modid=$modid&$session");
                 $admin->windowmsg("<p>��� ������� �����</p>");
            }
        }
        elseif ($act=="addcat")
        {
            $admin->head();
	  	oprations();
            $admin->opentable("����� �������");
            $admin->openform("mod.php?act=edit&mod=faq&modid=$modid&opration=insertCat&$session");
            $admin->inputtext("��� ������� ������","category",$category);
            $admin->closetable();
            $admin->submit("�����");
        }
        elseif ($act=="editcat")
        {
            $admin->head();
	  	oprations();
            $cat_id = $apt->get[cat_id];

            $result = $apt->query ("SELECT * FROM rafia_faqcategories WHERE cat_id='$cat_id'");
            $row = $apt->dbarray($result);
            @extract($row);
            $admin->opentable("����� �������");
            $admin->openform("mod.php?act=edit&mod=faq&modid=$modid&opration=updateCat&$session");
            $admin->inputtext("��� ������� ","category",$category);
            $admin->inputhidden('cat_id',$cat_id);
            $admin->closetable();
            $admin->submit("�����",'submitEdit');
        }
        elseif ($act=="insertCat")
        {
             $category      = $admin->format_data($apt->post[category]);
             $result = $apt->query("insert into rafia_faqcategories (category) values ('$category')");
             if ($result)
             {
                 header("Refresh: 1;url=mod.php?act=edit&mod=faq&modid=$modid&$session");
                 $admin->windowmsg("<p>��� ������� �����</p>");
             }
        }
        elseif ($act=="updateCat")
        {
             $category      = $admin->format_data($apt->post[category]);
             $cat_id        = $admin->format_data($apt->post[cat_id]);
             $result = $apt->query("update  rafia_faqcategories set category ='$category' where cat_id=$cat_id");
             if ($result)
             {
                 header("Refresh: 1;url=mod.php?act=edit&mod=faq&modid=$modid&$session");
                 $admin->windowmsg("<p>��� ������� �����</p>");
             }
        }
        
        elseif ($act=="list")
        {
            $cat_id        = $admin->format_data($apt->get[cat_id]);

            $result = $apt->query ("SELECT * FROM rafia_faqs where cat_id=$cat_id ORDER BY faq_id");
            
            while($row=$apt->dbarray($result))
            {
                @extract($row);
                $list  = array($question,
                               $admin->EditHref("mod.php?act=edit&mod=faq&modid=$modid&opration=edit&faq_id=$faq_id&$session"),
                               $admin->DelHref("mod.php?act=edit&mod=faq&modid=$modid&opration=del&faq_id=$faq_id&$session"),
                               );
                $admin->Rows .= $admin->TableCell($list);
            }
            $cellHeader = array("�����" ,"�����","���");
            $admin->ColWidth = array(40,20,20);
            $admin->head();
	  	oprations();
            echo $admin->Table($cellHeader,"����� �������");
        }
        else if ($act=="del")
        {
            $faq_id = $apt->setid('faq_id');
            $result = $apt->query("delete from  rafia_faqs where faq_id='$faq_id'");
            if ($result)
            {
                 header("Refresh: 1;url=mod.php?act=edit&mod=faq&modid=$modid&$session");
                 $admin->windowmsg("<p>��� ������� �����</p>");
            }
        }
        elseif ($act=="add")
        {
            $admin->head();
	  	oprations();
            $admin->opentable(_ADD_FAQS);
            $admin->openform("mod.php?act=edit&mod=faq&modid=$modid&opration=insert&$session");
            select($value);
            $admin->textarea("������","question","",'5','5');
            $admin->textarea("������","answer","",'5','5');
            $admin->closetable();
            $admin->submit("�����");
        }
        elseif ($act=="edit")
        {
            $admin->head();
	  	oprations();
            $faq_id = $apt->get[faq_id];

            $result = $apt->query ("SELECT * FROM rafia_faqs WHERE faq_id='$faq_id'");
            $row = $apt->dbarray($result);
            @extract($row);
            $admin->opentable(_FAQS);
            $admin->openform("mod.php?act=edit&mod=faq&modid=$modid&opration=update&$session");
            select($cat_id);
            $admin->textarea("������","question",$question,'5','5');
            $admin->textarea("������","answer",$answer,'5','5');
            $admin->inputhidden('faq_id',$faq_id);
            $admin->closetable();
            $admin->submit(_EDIT);
        }
        elseif ($act=="insert")
        {

             $question      = $admin->format_data($apt->post[question]);
             $answer        = $admin->format_data($apt->post[answer]);
             $cat_id        = $admin->format_data($apt->post[cat_id]);

             $result = $apt->query("insert into rafia_faqs (cat_id,question,answer) values
                                                         ('$cat_id','$question','$answer')");
             if ($result)
             {
                 header("Refresh: 1;url=mod.php?act=edit&mod=faq&modid=$modid&opration=list&cat_id=$cat_id&$session");
                 $admin->windowmsg("<p>��� ������� �����</p>");
             }
        }
        elseif ($act=="update")
        {
             $question      = $admin->format_data($apt->post[question]);
             $answer        = $admin->format_data($apt->post[answer]);
             $cat_id        = $admin->format_data($apt->post[cat_id]);
             $faq_id        = $admin->format_data($apt->post[faq_id]);
             
             $result = $apt->query("update  rafia_faqs set
                                                    cat_id ='$cat_id',
                                                    question ='$question',
                                                    answer ='$answer'
                                                    where faq_id='$faq_id'");
             if ($result)
             {
                 header("Refresh: 1;url=mod.php?act=edit&mod=faq&modid=$modid&opration=list&cat_id=$cat_id&$session");
                 $admin->windowmsg("<p>��� ������� �����</p>");
             }
        }
    }

     function select($value)
     {
         global $apt, $admin, $session, $modid, $mod;
         $result = $apt->query ("SELECT * FROM rafia_faqcategories ORDER BY cat_id");
            while($row=$apt->dbarray($result))
            {
                @extract($row);
                $arr[$cat_id] = $category;
            }
         $admin->add_select_arr($arr,10);
         $admin->input_select(_SECTION_NAME,'cat_id',$value,10);
      }
 
faqs($apt->get[opration]);

?>