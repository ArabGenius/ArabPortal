<?php
/****************************************************************************
*			����� ���� ���������				    *
*****************************************************************************
*	The Programmer		*		�������������		    *
*****************************************************************************
*				*					    *
*            DeaD SouL          *                 DeaD SouL                 *
*        Mubarak Alrashidi      *               ����� �������               *
*    Mr.DeaDSouL@hotmail.com    *          Mr.DeaDSouL@hotmail.com          *
*	http://DSQ8.com		*		www.DSQ8.com		    *
*				*					    *
*****************************************************************************
*             �������� �������� ������ ���� ���������� ��������               *
*             ��� �������� ���� ������� �������� ���� �� ����                *
*           �� ������� �������� ����� ������ ������� ���������              *
****************************************************************************/


$mod_id = $mod->modInfo[id];
$Top_DeaDSouL = $mod->getmodsettings('Top_DeaDSouL',$mod_id);


/*********************�� ��� ����� �� ��� ���� ��� �����**********************/

if (RUN_MODULE !== true)
{
    die ("<center><h3>���� ��� ������� ��� ������</h3></center>");
}

?>



<div align="center">
  <table border="0" cellpadding="5" style="border-collapse: collapse" bordercolor="#111111" width="90%" id="table13">
    <tr>
      <td>
      <p align="center"><b>���� ( <?php echo $Top_DeaDSouL ?> )</b></td>
    </tr>
    <tr>
      <td class="fontablt2">
      &nbsp;</td>
    </tr>
    <tr>
      <td class="fontablt2" align="justify">
      <fieldset style="padding:0; border:1px solid #02BBF0; ">
	<legend class="fontablt2">&#1575;&#1604;&#1571;&#1582;&#1600;&#1600;&#1576;&#1600;&#1600;&#1600;&#1600;&#1575;&#1585; &amp; &#1575;&#1604;&#1605;&#1600;&#1602;&#1600;&#1600;&#1600;&#1600;&#1575;&#1604;&#1575;&#1578;</legend>
	<div align="center">
	<table border="0" cellpadding="10" cellspacing="0" width="100%" id="table15">
		<tr>
			<td><fieldset style="padding:0; border:1px solid #02BBF0; ">
			<legend class="fontablt">&#1571;&#1601;&#1590;&#1604; &#1575;&#1604;&#1605;&#1602;&#1575;&#1604;&#1575;&#1578; &#1605;&#1606; &#1581;&#1610;&#1579; &#1593;&#1583;&#1583; &#1575;&#1604;&#1602;&#1585;&#1617;&#1575;&#1569;:</legend>
			<div align="center">
			<table border="0" cellpadding="10" cellspacing="0" width="100%" id="table20">
				<tr>
					<td class="fontablt"><?php 
$query=mysql_query("SELECT * FROM rafia_news WHERE allow='yes' ORDER BY reader DESC LIMIT $Top_DeaDSouL"); 
while($result=mysql_fetch_array($query)){ 
$result[title]        =  str_replace('$','&#36',$result[title]);

echo"<a title=\"������:  \r\n    $result[news_head] \r\n \r\n                                                      ������: $result[name]\" href=\"news.php?action=view&id=$result[id]\"><li>$result[title]</li> (�������: <b>$result[reader]</b>)</a>"; 
} 
?></td>
				</tr>
			</table>
			</div>
			</fieldset></td>
		</tr>
		<tr>
			<td><fieldset style="padding:0; border:1px solid #02BBF0; ">
			<legend class="fontablt">&#1571;&#1601;&#1590;&#1604; &#1575;&#1604;&#1605;&#1602;&#1575;&#1604;&#1575;&#1578; &#1605;&#1606; &#1581;&#1610;&#1579; &#1593;&#1583;&#1583; &#1575;&#1604;&#1578;&#1593;&#1604;&#1610;&#1602;&#1575;&#1578;:</legend>
			<div align="center">
			<table border="0" cellpadding="10" cellspacing="0" width="100%" id="table21">
				<tr>
					<td class="fontablt"><?php 
$query=mysql_query("SELECT * FROM rafia_news WHERE allow='yes' ORDER BY c_comment DESC LIMIT $Top_DeaDSouL"); 
while($result=mysql_fetch_array($query)){
$result[title]        =  str_replace('$','&#36',$result[title]);
 
echo"<a title=\"������:     $result[news_head] \r\n \r\n                                                      ������: $result[name]\" href=\"news.php?action=view&id=$result[id]\"><li>$result[title]</li> (���������: <b>$result[c_comment]</b>)</a>"; 
} 
?></td>
				</tr>
			</table>
			</div>
			</fieldset></td>
		</tr>
		</table>
		</div>
		</fieldset></td>
    </tr>
    <tr>
      <td class="fontablt2" align="center"><hr width="65%" size="1" color="#0286AF"></td>
    </tr>
    <tr>
      <td class="fontablt2" align="justify">
      <fieldset style="padding:0; border:1px solid #02BBF0; ">
	<legend class="fontablt2">&#1575;&#1604;&#1600;&#1605;&#1600;&#1600;&#1600;&#1606;&#1600;&#1600;&#1600;&#1578;&#1600;&#1600;&#1600;&#1600;&#1600;&#1600;&#1600;&#1583;&#1609;</legend>
	<div align="center">
	<table border="0" cellpadding="10" cellspacing="0" width="100%" id="table16">
		<tr>
			<td><fieldset style="padding:0; border:1px solid #02BBF0; ">
			<legend class="fontablt">&#1571;&#1601;&#1590;&#1604; &#1575;&#1604;&#1605;&#1608;&#1575;&#1590;&#1610;&#1593; &#1605;&#1606; &#1581;&#1610;&#1579; &#1593;&#1583;&#1583; &#1575;&#1604;&#1602;&#1585;&#1617;&#1575;&#1569;:</legend>
			<div align="center">
			<table border="0" cellpadding="10" cellspacing="0" width="100%" id="table22">
				<tr>
					<td class="fontablt"><?php 
$query=mysql_query("SELECT * FROM rafia_forum WHERE allow='yes' ORDER BY reader DESC LIMIT $Top_DeaDSouL"); 
while($result=mysql_fetch_array($query)){ 
$result[title]        =  str_replace('$','&#36',$result[title]);

echo"<a title=\"������: $result[name]\" href=\"forum.php?action=view&id=$result[id]\"><li>$result[title]</li> (�������: <b>$result[reader]</b>)</a>"; 
} 
?></td>
				</tr>
			</table>
			</div>
			</fieldset></td>
		</tr>
		<tr>
			<td><fieldset style="padding:0; border:1px solid #02BBF0; ">
			<legend class="fontablt">&#1571;&#1601;&#1590;&#1604; &#1575;&#1604;&#1605;&#1608;&#1575;&#1590;&#1610;&#1593; &#1605;&#1606; &#1581;&#1610;&#1579; &#1593;&#1583;&#1583; &#1575;&#1604;&#1585;&#1583;&#1608;&#1583;:</legend>
			<div align="center">
			<table border="0" cellpadding="10" cellspacing="0" width="100%" id="table23">
				<tr>
					<td class="fontablt"><?php 
$query=mysql_query("SELECT * FROM rafia_forum WHERE allow='yes' ORDER BY c_comment DESC LIMIT $Top_DeaDSouL"); 
while($result=mysql_fetch_array($query)){ 
$result[title]        =  str_replace('$','&#36',$result[title]);

echo"<a title=\"������: $result[name]\" href=\"forum.php?action=view&id=$result[id]\"><li>$result[title]</li> (������: <b>$result[c_comment]</b>)</a>"; 
} 
?></td>
				</tr>
			</table>
			</div>
			</fieldset></td>
		</tr>
		</table>
		</div>
		</fieldset></td>
    </tr>
    <tr>
      <td class="fontablt2" align="center">
      <hr width="65%" size="1" color="#0286AF"></td>
    </tr>
    <tr>
      <td class="fontablt2" align="justify">
     <fieldset style="padding:0; border:1px solid #02BBF0; ">
	<legend class="fontablt2">&#1605;&#1600;&#1585;&#1603;&#1600;&#1600;&#1600;&#1600;&#1586; &#1575;&#1604;&#1600;&#1578;&#1600;&#1600;&#1581;&#1600;&#1600;&#1605;&#1600;&#1600;&#1610;&#1600;&#1600;&#1600;&#1600;&#1600;&#1600;&#1604;</legend>
	<div align="center">
	<table border="0" cellpadding="10" cellspacing="0" width="100%" id="table17">
		<tr>
			<td><fieldset style="padding:0; border:1px solid #02BBF0; ">
			<legend class="fontablt">&#1571;&#1601;&#1590;&#1604; &#1575;&#1604;&#1576;&#1585;&#1575;&#1605;&#1580; &#1605;&#1606; &#1581;&#1610;&#1579; &#1593;&#1583;&#1583; &#1605;&#1585;&#1575;&#1578; &#1575;&#1604;&#1578;&#1581;&#1605;&#1610;&#1604;:</legend>
			<div align="center">
			<table border="0" cellpadding="10" cellspacing="0" width="100%" id="table24">
				<tr>
					<td class="fontablt"><?php 
$query=mysql_query("SELECT * FROM rafia_download WHERE allow='yes' ORDER BY clicks DESC LIMIT $Top_DeaDSouL"); 
while($result=mysql_fetch_array($query)){ 
echo"<a title=\"������: $result[name]\" href=\"download.php?action=view&id=$result[id]\"><li>$result[title]</li> (���� �������: <b>$result[clicks]</b>)</a>"; 
} 
?></td>
				</tr>
			</table>
			</div>
			</fieldset></td>
		</tr>
		<tr>
			<td><fieldset style="padding:0; border:1px solid #02BBF0; ">
			<legend class="fontablt">&#1571;&#1601;&#1590;&#1604; &#1575;&#1604;&#1576;&#1585;&#1575;&#1605;&#1580; &#1605;&#1606; &#1581;&#1610;&#1579; &#1593;&#1583;&#1583; &#1575;&#1604;&#1578;&#1593;&#1604;&#1610;&#1602;&#1600;&#1600;&#1600;&#1575;&#1578;:</legend>
			<div align="center">
			<table border="0" cellpadding="10" cellspacing="0" width="100%" id="table25">
				<tr>
					<td class="fontablt"><?php 
$query=mysql_query("SELECT * FROM rafia_download WHERE allow='yes' ORDER BY c_comment DESC LIMIT $Top_DeaDSouL"); 
while($result=mysql_fetch_array($query)){ 
echo"<a title=\"������: $result[name]\" href=\"download.php?action=view&id=$result[id]\"><li>$result[title]</li> (���������: <b>$result[c_comment]</b>)</a>"; 
} 
?></td>
				</tr>
			</table>
			</div>
			</fieldset></td>
		</tr>
		<tr>
			<td><fieldset style="padding:0; border:1px solid #02BBF0; ">
			<legend class="fontablt">&#1571;&#1601;&#1590;&#1604; &#1575;&#1604;&#1576;&#1585;&#1575;&#1605;&#1580; &#1605;&#1606; &#1581;&#1610;&#1579; &#1593;&#1583;&#1583; &#1605;&#1585;&#1575;&#1578; &#1575;&#1604;&#1578;&#1589;&#1608;&#1610;&#1578;:</legend>
			<div align="center">
			<table border="0" cellpadding="10" cellspacing="0" width="100%" id="table26">
				<tr>
					<td class="fontablt"><?php 
$query=mysql_query("SELECT * FROM rafia_download WHERE allow='yes' ORDER BY ratings DESC LIMIT $Top_DeaDSouL"); 
while($result=mysql_fetch_array($query)){ 
echo"<a title=\"������: $result[name]\" href=\"download.php?action=view&id=$result[id]\"><li>$result[title]</li> (���������: <b>$result[ratings]</b>)</a>"; 
} 
?></td>
				</tr>
			</table>
			</div>
			</fieldset></td>
		</tr>
		</table>
		</div>
		</fieldset></td>
    </tr>
    <tr>
      <td class="fontablt2" align="center">
      <hr width="65%" size="1" color="#0286AF"></td>
    </tr>
    <tr>
      <td class="fontablt2" align="justify">
      <fieldset style="padding:0; border:1px solid #02BBF0; ">
	<legend class="fontablt2">&#1583;&#1604;&#1600;&#1600;&#1600;&#1610;&#1600;&#1600;&#1600;&#1600;&#1600;&#1604; &#1575;&#1604;&#1600;&#1605;&#1600;&#1600;&#1600;&#1600;&#1608;&#1575;&#1602;&#1600;&#1593;</legend>
	<div align="center">
	<table border="0" cellpadding="10" cellspacing="0" width="100%" id="table18">
		<tr>
			<td><fieldset style="padding:0; border:1px solid #02BBF0; ">
			<legend class="fontablt">&#1571;&#1601;&#1590;&#1604; &#1575;&#1604;&#1605;&#1608;&#1575;&#1602;&#1593; &#1605;&#1606; &#1581;&#1610;&#1579; &#1593;&#1583;&#1583; &#1575;&#1604;&#1586;&#1610;&#1575;&#1585;&#1575;&#1578;:</legend>
			<div align="center">
			<table border="0" cellpadding="10" cellspacing="0" width="100%" id="table27">
				<tr>
					<td class="fontablt"><?php 
$query=mysql_query("SELECT * FROM rafia_links WHERE allow='yes' ORDER BY clicks DESC LIMIT $Top_DeaDSouL"); 
while($result=mysql_fetch_array($query)){ 
echo"<a target=\"_blank\" title=\"������:     $result[post] \r\n \r\n                                                    ������: $result[name]\" href=\"link.php?action=goto&id=$result[id]\"><li>$result[title]</li> (��������: <b>$result[clicks]</b>)</a>"; 
} 
?></td>
				</tr>
			</table>
			</div>
			</fieldset></td>
		</tr>
		<tr>
			<td><fieldset style="padding:0; border:1px solid #02BBF0; ">
			<legend class="fontablt">&#1571;&#1601;&#1590;&#1604; &#1575;&#1604;&#1605;&#1608;&#1575;&#1602;&#1593; &#1605;&#1606; &#1581;&#1610;&#1579; &#1593;&#1583;&#1583; &#1605;&#1585;&#1575;&#1578; &#1575;&#1604;&#1578;&#1589;&#1608;&#1610;&#1578;:</legend>
			<div align="center">
			<table border="0" cellpadding="10" cellspacing="0" width="100%" id="table28">
				<tr>
					<td class="fontablt"><?php 
$query=mysql_query("SELECT * FROM rafia_links WHERE allow='yes' ORDER BY ratings DESC LIMIT $Top_DeaDSouL"); 
while($result=mysql_fetch_array($query)){ 
echo"<a target=\"_blank\" title=\"������:     $result[post] \r\n \r\n                                                    ������: $result[name]\" href=\"link.php?action=goto&id=$result[id]\"><li>$result[title]</li> (���������: <b>$result[ratings]</b>)</a>"; 
} 
?></td>
				</tr>
			</table>
			</div>
			</fieldset></td>
		</tr>
		</table>
		</div>
		</fieldset></td>
    </tr>
    <tr>
      <td class="fontablt2" align="center">
      <hr width="65%" size="1" color="#0286AF"></td>
    </tr>
    <tr>
      <td class="fontablt2" align="justify">
      <fieldset style="padding:0; border:1px solid #02BBF0; ">
	<legend class="fontablt2">&#1575;&#1604;&#1571;&#1593;&#1600;&#1600;&#1600;&#1590;&#1600;&#1600;&#1600;&#1600;&#1600;&#1600;&#1575;&#1569;</legend>
	<div align="center">
	<table border="0" cellpadding="10" cellspacing="0" width="100%" id="table19">
		<tr>
			<td><fieldset style="padding:0; border:1px solid #02BBF0; ">
			<legend class="fontablt">&#1571;&#1601;&#1590;&#1604; &#1575;&#1604;&#1571;&#1593;&#1590;&#1575;&#1569; &#1605;&#1606; &#1581;&#1610;&#1579; &#1593;&#1583;&#1583; &#1575;&#1604;&#1605;&#1588;&#1575;&#1585;&#1603;&#1575;&#1578;:</legend>
			<div align="center">
			<table border="0" cellpadding="10" cellspacing="0" width="100%" id="table29">
				<tr>
					<td class="fontablt"><?php 
$query=mysql_query("SELECT * FROM rafia_users WHERE allowpost='yes' and userid !='$apt->Guestid' ORDER BY allposts DESC LIMIT $Top_DeaDSouL"); 
while($result=mysql_fetch_array($query)){ 
echo"<a title=\"��� ������� ������� ����� $result[username]\" href=\"members.php?action=info&userid=$result[userid]\"><li>$result[username]</li> (��� ���������: <b>$result[allposts]</b>)</a>"; 
} 
?></td>
				</tr>
			</table>
			</div>
			</fieldset></td>
		</tr>
		</table>
		</div>
		</fieldset></td>
    </tr>
    <tr>
      <td class="fontablt2" align="center">
      &nbsp;</td>
    </tr>
    <tr>
      <td width="680" height="8">
      &nbsp;</td>
    </tr>
    </table>
  </div>




<div align="center">
	<table border="0" cellpadding="0" cellspacing="0" width="60%" id="table128">
		<tr>
			<td align="center" dir="ltr" class="link2">
			<font face="MS Sans Serif" size="2">
			<a title="��� ����� ��� ������� ������� �������" target="_blank" href="http://DSQ8.com">� Top.Posts</a></font></td>
		</tr>
		<tr>
			<td align="center" dir="rtl" class="link2">
			<font face="MS Sans Serif" size="2"><font color="#D2390B">
			�����:</font>
			<a title="����� �������" href="mailto:Mr.DeaDSouL@hotmail.com?subject=Top Posts Module">
			DeaD SouL</a></font></td>
		</tr>
	</table>
</div>

