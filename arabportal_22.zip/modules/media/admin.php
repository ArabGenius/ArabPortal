<?php

/*

+===========================================+

|      ArabPortal V2.1.x Copyright � 2006   |

|   -------------------------------------   |

|            By Rafia AL-Otibi              |

|                    And                    |

|              Arab Portal Team             |

|   -------------------------------------   |

|      Web: http://www.ArabPortal.Net       |

|   -------------------------------------   |

|  Last Updated: 01/01/2007 Time: 00:00 AM  |

+===========================================+

*/



if (RUN_MODULE !== true)

{

    die ("<center><h3></h3>���� ��� ������� ��� ������</center>");

}
include("modules/media/config.php");

$media_middle  = $apt->table_cat_module("<a href=mod.php?mod=$mod_name>&nbsp;$mod_title</a>");




$media_middle .= "<script >
function checkAll(field)
{
  for(i = 0; i < field.elements.length; i++)
     field[i].checked = true ;
}
function uncheckAll(field)
{
 for(i = 0; i < field.elements.length; i++)
    field[i].checked = false ;
}
</script>";



//---------------------------------------------------

//

//---------------------------------------------------

if($apt->get['mode'] == ''){

     if ($member_gp = $allow_edit)

    {

        $apt->head(LANG_TITLE_MODERATE_POSTS);


        $result = $apt->query("SELECT * FROM rafia_media_items WHERE item_allow=0 order by item_id DESC ");

        if($apt->dbnumrows($result))

        {


        $media_middle .="   
        <div align=center><table border=0 width=90%  cellspacing=0 cellpadding=0>

        <tr>

        <td width=\"100%\" bgcolor=\"#34597D\" style=\"padding-top: 3; padding-bottom: 3\" class=\"normal_dark_link\">

        <span class=orang_b> �   </span>����� ����� ���������</td>

        </tr><tr><td width=100% bgcolor=FFFFFF><div align=center>     <table border=1 cellpadding='4'  dir=ltr cellspacing='0' style='border-collapse: collapse; border-width: 0' bordercolor='111111' width='100%' id='AutoNumber7'>";
        $media_middle .="<form method=\"POST\"  border=1 cellspacing=1 action=\"mod.php?mod=media&modfile=admin&mode=allow\" name='admin'>";
while(@extract($apt->dbarray($result))){
        $media_middle .=		"<td width=\"10%\"><input type=checkbox name=\"do[]\" value=$item_id></td>";
		$media_middle .=		"<td width=\"20%\"><a href=mod.php?mod=media&modfile=editpost&act=edit&itemid=$item_id><b>����� </b></td>";
		$media_middle .=		"<td width=\"30%\"><a href=mod.php?mod=media&modfile=item&itemid=$item_id ><b>������� ��������</b></td>";
		$media_middle .=		"<td width=\"50%\">$item_title</td></tr>";
  }
            $media_middle .= 	"</table>";
            $media_middle .= " <input type=\"button\" name=\"CheckAll\" value=\"����� ����\" onclick=\"checkAll(document.admin)\" >";  
            $media_middle .= "<input type=\"button\" name=\"UnCheckAll\" value=\"����� �������\" onclick=\"uncheckAll(document.admin)\" >";  
            $media_middle .= "<input type=\"submit\" name=\"del\"  value=\"������\" onClick=\"if (!confirm('�� ���� ����� �� ����ݿ')) return false;\">";
            $media_middle .= "&nbsp;&nbsp;<input type=\"submit\" name=\"allow\"  value=\"�����\"onClick=\"if (!confirm('�� ���� ����� �� �������  �')) return false;\">";
		             $media_middle .= 	"</form>";        
eval("\$index_middle .= \" " . $apt->getmodtemplate ( 'media_main', $modid,$mod_theme ) . "\";");
echo $index_middle;
            }

            else

            {

                $index_middle .= "<p>�� ���� ������� ��� ��������</p>";
echo $index_middle;
            }


        }

        else

        {

            $apt->head(LANG_TITLE_LOG_IN);

            eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");

        }





}

else if($apt->get['mode'] == 'allow')

{
    $do  = $apt->post['do'];
            if (count($do) > 0)

        {

        if($apt->post['allow']){



                 foreach($apt->post['do'] as $id)

                 {

                    $result = $apt->query("update rafia_media_items set item_allow=1  where item_id='$id'");

                }



       $apt->bodymsg("�� �����  ��������",$apt->refe);

       }elseif($apt->post['del']){

                 foreach($apt->post['do'] as $id)

            {

                $result = $apt->query("delete from   rafia_media_items where  item_id=$id");

            }
                   $apt->bodymsg("�� ��� ��������",$apt->refe);

			}
}

////////////////////////////////////////////////////////
}


elseif($apt->get['mode'] == 'comment'){
     if ($member_gp = $allow_edit)

    {    
 $apt->head(LANG_TITLE_MODERATE_POSTS);


        $result = $apt->query("SELECT * FROM rafia_media_comment WHERE comment_allow=0 order by comment_id  DESC");

        if($apt->dbnumrows($result))

        {


        $media_middle .="   
        <div align=center><table border=0 width=90%  cellspacing=0 cellpadding=0>

        <tr>

        <td width=\"100%\" bgcolor=\"#34597D\" style=\"padding-top: 3; padding-bottom: 3\" class=\"normal_dark_link\">

        <span class=orang_b> �   </span>����� ����� ���������</td>

        </tr><tr><td width=100% bgcolor=FFFFFF><div align=center>     <table border=1 cellpadding='4'  dir=ltr cellspacing='0' style='border-collapse: collapse; border-width: 0' bordercolor='111111' width='100%' id='AutoNumber7'>";
        $media_middle .="<form method=\"POST\"  border=1 cellspacing=1 action=\"mod.php?mod=media&modfile=admin&mode=allowcomment\" name='admin'>";
while(@extract($apt->dbarray($result))){
        $media_middle .=		"<td width=\"10%\"><input type=checkbox name=\"do[]\" value=$comment_id></td>";
		$media_middle .=		"<td width=\"20%\"><a href=mod.php?mod=media&modfile=editpost&act=editcomment&cid=$comment_id&itemid=$comment_item><b>����� </b></td>";
		$media_middle .=		"<td width=\"20%\"><a href=mod.php?mod=media&modfile=item&itemid=$comment_item><b>��� ��������  </b></td>";
		$media_middle .=		"<td width=\"50%\">$comment_text </td></tr>";
  }
            $media_middle .= 	"</table>";
            $media_middle .= " <input type=\"button\" name=\"CheckAll\" value=\"����� ����\" onclick=\"checkAll(document.admin)\" >";  
            $media_middle .= "<input type=\"button\" name=\"UnCheckAll\" value=\"����� �������\" onclick=\"uncheckAll(document.admin)\" >";  
            $media_middle .= "<input type=\"submit\" name=\"del\"  value=\"������\" onClick=\"if (!confirm('�� ���� ����� �� ����ݿ')) return false;\">";
            $media_middle .= "&nbsp;&nbsp;<input type=\"submit\" name=\"allow\"  value=\"�����\"onClick=\"if (!confirm('�� ���� ����� �� �������  �')) return false;\">";
		             $media_middle .= 	"</form>";        
eval("\$index_middle .= \" " . $apt->getmodtemplate ( 'media_main', $modid,$mod_theme ) . "\";");
echo $index_middle;
            }

            else

            {

                $index_middle .= "<p>�� ���� ������� ��� ��������</p>";
echo $index_middle;
            }


        }

        else

        {

            $apt->head(LANG_TITLE_LOG_IN);

            eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");

        }





}




else if($apt->get['mode'] == 'allowcomment')

{
    $do  = $apt->post['do'];
            if (count($do) > 0)

        {

        if($apt->post['allow']){



                 foreach($apt->post['do'] as $id)

                 {

                    $result = $apt->query("update rafia_media_comment set comment_allow='1'  where comment_id='$id'");

                }



       $apt->bodymsg("�� �����  �������",$apt->refe);

       }elseif($apt->post['del']){

                 foreach($apt->post['do'] as $id)

            {

                $result = $apt->query("delete from  rafia_media_comment  where comment_id=$id");

            }
                   $apt->bodymsg("�� ��� �������",$apt->refe);

			}
}

}

if(isset($fo))

{

    print $apt->script->post_java();

}


?>