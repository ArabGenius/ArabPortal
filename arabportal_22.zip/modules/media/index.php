<?php


if (RUN_MODULE !== true)
{
    die ("<center><h3>���� ��� ������� ��� ������</h3></center>");
}

include("modules/media/config.php");
if($Cat_media < 1 ) $Cat_media = 1;
$index_middle = $apt->table_cat_module("<a href=mod.php?mod=$mod_name>&nbsp;$mod_title</a>");
$media_middle .= " <p align=right><b>
<a href=mod.php?mod=media&modfile=moailf><font size=4>����� ��� ������</font></a><font size=4>
</font></b></p>";
$tdwidth =  100/$Cat_media;
$result = $apt->query("SELECT * FROM rafia_media_cat where cat_main='1' order by cat_order");
$media_middle .= "<table border='0' width='100%' align='center' cellpadding='".$Cat_media."'><tr>";
if($apt->dbnumrows($result)== 0){
$media_middle .= "<td align=\"center\" width=\"100%\"  valign=\"top\" height=\"100%\">";
$media_middle .= " �� ���� ������� ����� ";
$media_middle .= "</td>";
}else{
while(@extract($apt->dbarray($result))){

if(file_exists("modules/media/cat/".$cat_id.".jpg")){
	$gimg="<img border=0 src=modules/media/cat/$cat_id.jpg >";
}else{
	$gimg="<img border=0 src=modules/media/cat/noimg.jpg >";
}

$cat_main= $apt->dbnumquery("rafia_media_cat","cat_main='0' and cat_sub='$cat_id' ");

$itemCount = $apt->dbnumquery("rafia_media_items","item_cat=$cat_id and item_allow=1 ");

$media_middle .= "<td align=\"center\" width=\"".$tdwidth."%\"  valign=\"top\" height=\"100%\">";

eval("\$media_middle .= \" " . $apt->getmodtemplate ( 'media_category', $modid,$mod_theme ) . "\";");
$media_middle .= "</td>";
$count++;
if ($count ==  $Cat_media){
$media_middle .= "</tr>";
$count = 0;
}
}
}
$media_middle .= "</tr></table><br>";

eval("\$index_middle .= \" " . $apt->getmodtemplate ( 'media_main', $modid,$mod_theme ) . "\";");

echo $index_middle;



?>