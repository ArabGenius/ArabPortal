<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 01/01/2007 Time: 00:00 AM  |
+===========================================+
*/


if (RUN_MODULE !== true)
{
    die ("<center><h3>���� ��� ������� ��� ������</h3></center>");
}
include("modules/media/config.php");


if($apt->get['mode'] == ''){
$index_middle = $apt->table_cat_module("<a href=mod.php?mod=$mod_name>&nbsp;$mod_title</a>");
eval("\$media_middle .= \" " . $apt->getmodtemplate ( 'media_moalif_top', $modid,$mod_theme ) . "\";");

$result = $apt->query("SELECT * FROM rafia_media_moalif order by order_moalif ");
while(@extract($apt->dbarray($result))){
              $countwit = $apt->dbnumquery(" rafia_media_items","item_moalif='$name_moalif' and item_allow='1'");
                            $mediasmoalif = urlencode($name_moalif); 

              eval("\$media_middle .= \" " . $apt->getmodtemplate ( 'media_moalif_middle', $modid,$mod_theme ) . "\";");
}
eval("\$media_middle .= \" " . $apt->getmodtemplate ( 'media_list_botton', $modid,$mod_theme ) . "\";");

eval("\$index_middle .= \" " . $apt->getmodtemplate ( 'media_main', $modid,$mod_theme ) . "\";");

echo $index_middle;

}

elseif($apt->get['mode'] == 'desc'){
$name = urldecode(base64_decode($apt->get['mediasmoalif']));
if($name == '')$apt->errmsg("���� ... ��� ������ ��� �����");
$index_middle = $apt->table_cat_module("<a href=mod.php?mod=$mod_name>&nbsp;$mod_title</a>");

$result = $apt->query("SELECT * FROM rafia_media_moalif where name_moalif='$name'");
while(@extract($apt->dbarray($result))){
$desc_moalif          = $apt->rep_words($desc_moalif);
$desc_moalif          = $apt->rafia_code($desc_moalif);
eval("\$media_middle .= \" " . $apt->getmodtemplate ( 'media_moalif', $modid,$mod_theme ) . "\";");
}
eval("\$media_middle .= \" " . $apt->getmodtemplate ( 'media_list_top', $modid,$mod_theme ) . "\";");
$result = $apt->query("SELECT * FROM rafia_media_items where item_allow=1 and item_moalif like '%$name%' order by item_show DESC");
$media_items ='';
while(@extract($apt->dbarray($result))){
$item_user = $user[$item_uid];
$item_date = $apt->Hijri($item_date);
$mediasmoalife = urlencode(base64_encode($item_moalif));  

eval("\$media_middles .= \" " . $apt->getmodtemplate ( 'media_list_middle', $modid,$mod_theme ) . "\";");
}

$media_middle .= $media_middles;
eval("\$media_middle .= \" " . $apt->getmodtemplate ( 'media_list_botton', $modid,$mod_theme ) . "\";");

eval("\$index_middle .= \" " . $apt->getmodtemplate ( 'media_main', $modid,$mod_theme ) . "\";");
echo $index_middle;
}
?>