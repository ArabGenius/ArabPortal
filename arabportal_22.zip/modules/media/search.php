<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 01/01/2007 Time: 00:00 AM  |
+===========================================+
*/


if (RUN_MODULE !== true)
{
    die ("<center><h3>���� ��� ������� ��� ������</h3></center>");
}


include("modules/media/config.php");

$media_middle = '';

$uresult = $apt->query("SELECT userid,username FROM rafia_users");
while(@extract($apt->dbarray($uresult))){
$user[$userid] = $username;
}

if($member_gp != 1){
$open_hide = "<!--";
$close_hide = " -->";
}
    if (!$apt->full($apt->post['searchfor'],$apt->post['searchin']))
    {
        $apt->errmsg(LANG_ERROR_VALID_SEARCH);
    }
    if($apt->post['searchfor'] == '*')
    {
        $apt->errmsg(LANG_ERROR_VALID_SEARCH);
    }
    if($apt->post['searchin'] == '*')
    {
        $apt->errmsg(LANG_ERROR_VALID_SEARCH);
    }

    $searchfor  = $apt->format_data(trim($apt->post['searchfor']));
    $searchin  = $apt->format_data(trim($apt->post['searchin']));
    $searchfor  = str_replace("]","",$searchfor);
    $searchfor  = str_replace("[","",$searchfor);

$sin = array('item_title','item_moalif','item_desc');
if(!in_array($searchin,$sin)){$apt->errmsg(LANG_ERROR_VALID_SEARCH);}
eval("\$media_middle .= \" " . $apt->getmodtemplate ( 'media_list_top', $modid,$mod_theme ) . "\";");
$result = $apt->query("SELECT * FROM rafia_media_items where item_allow=1 and $searchin like '%$searchfor%' order by item_show DESC");
$media_items ='';
while(@extract($apt->dbarray($result))){
$item_user = $user[$item_uid];
$item_date = $apt->Hijri($item_date);
eval("\$media_middles .= \" " . $apt->getmodtemplate ( 'media_list_middle', $modid,$mod_theme ) . "\";");
}

//$media_middles = str_replace('modfile=item',"modfile=item&word=$searchfor",$media_middles);
$media_middle .= $media_middles;
eval("\$media_middle .= \" " . $apt->getmodtemplate ( 'media_list_botton', $modid,$mod_theme ) . "\";");

eval("\$index_middle .= \" " . $apt->getmodtemplate ( 'media_main', $modid,$mod_theme ) . "\";");
echo $index_middle;

?>