<?php



if (RUN_MODULE !== true)

{

    die ("<center><h3></h3>���� ��� ������� ��� ������</center>");

}



$catid= $apt->setid('catid');

include("modules/media/config.php");

$index_middle = mtable_cat_link("<a href=mod.php?mod=$mod_name>&nbsp;$mod_title</a>",$catid);


if($Cat_media < 1 ) $Cat_media = 1;

	$tdwidth =  100/$Cat_media;
$result = $apt->query("SELECT * FROM rafia_media_cat where cat_main='0' and cat_sub='$catid' order by cat_order ");
$media_middle .= "<table border='0' width='100%' align='center' cellpadding='".$Cat_media."'><tr>";
if($apt->dbnumrows($result)== 0){
$media_middle .= "<td align=\"center\" width=\"100%\"  valign=\"top\" height=\"100%\">";
$media_middle .= " ";
$media_middle .= "</td>";
}else{
while(@extract($apt->dbarray($result))){

            if(file_exists("modules/media/cat/".$cat_id.".jpg")){
$gimg="<img border=0 src=modules/media/cat/$cat_id.jpg >";
		}else{
$gimg="<img border=0 src=modules/media/cat/noimg.jpg >";
		}
		
$cat_main= $apt->dbnumquery("rafia_media_cat","cat_main='0' and cat_sub='$cat_id' ");
$itemCount = $apt->dbnumquery("rafia_media_items","item_cat=$cat_id and item_allow=1");

$media_middle .= "<td align=\"center\" width=\"".$tdwidth."%\"  valign=\"top\" height=\"100%\">";
eval("\$media_middle .= \" " . $apt->getmodtemplate ( 'media_category', $modid,$mod_theme ) . "\";");
$media_middle .= "</td>";
$count++;
if ($count ==  $Cat_media){
$media_middle .= "</tr>";
$count = 0;
}
}
}



$uresult = $apt->query("SELECT userid,username FROM rafia_users");

while(@extract($apt->dbarray($uresult))){

$user[$userid] = $username;

}

if (!$allow_add){

$open_hide = "<!--";

$close_hide = " -->";

}


eval("\$media_middle .= \" " . $apt->getmodtemplate ( 'media_list_top', $modid,$mod_theme ) . "\";");
$page = intval($apt->get[page]);

if($page ==0) $page=1;
$end= $media_active; 
$show=3; 
$start=$page*$end-$end; 
if($start < 0) $start=0;
$result = $apt->query("SELECT * FROM rafia_media_items where item_allow=1 and item_cat='$catid' order by !item_sticky,item_id DESC LIMIT $start,$end");
$media_items ='';
while(@extract($apt->dbarray($result))){
$item_user = $user[$item_uid];

$mediasmoalife = urlencode(base64_encode($item_moalif));  

$item_date = $apt->Hijri($item_date);

 if ( $item_sticky  == 1) 
           $item_title = "<font color=#FF0000><b> ����: </b></font>$item_title"; 
       else 
           $item_title = "$item_title";

 if ( $color == "$color1") 
           $color = "$color2"; 
       else 
           $color = "$color1";

		$item_user = $user[$item_uid];
//////////////
		$item_user = $user[$item_uid];
if($item_type == 1){
$gimg="<img border=0 src=modules/media/cat/media.jpg >";
}elseif($item_type == 2){
$gimg="<img border=0 src=modules/media/cat/realplayer.jpg >";
}elseif($item_type == 3){
$gimg="<img border=0 src=modules/media/cat/flash.jpg >";
}else{
$gimg="<img border=0 src=modules/media/cat/flv.jpg >";
}
/////////////////


eval("\$media_middle .= \" " . $apt->getmodtemplate ( 'media_list_middle', $modid,$mod_theme ) . "\";");

}

eval("\$media_middle .= \" " . $apt->getmodtemplate ( 'media_list_botton', $modid,$mod_theme ) . "\";");
eval("\$index_middle .= \" " . $apt->getmodtemplate ( 'media_main', $modid,$mod_theme ) . "\";");

$cat = $catid;
$Sql2 = "select * from rafia_media_items where item_cat='$catid'"; 
$user2 = mysql_query($Sql2); 
$rows=mysql_num_rows($user2); 
$links=$rows/$end; 
$lastlink=ceil($links); 

if($rows > $end){
if ($lastlink!=1) {
$index_middle .= "<b>������� : </b>";
if (($lastlink<=$page+$show and $page-$show>1) or ($page-$show>1) ) { $index_middle .= "<a title='��� ����' href=mod.php?mod=media&modfile=category&catid=$cat&page=1> � </a> ..";} 
if ($page-$show<1) { for ($i=1 ;$i<=$page-1 ;$i++) $index_middle .= "<a href=mod.php?mod=media&modfile=category&catid=$cat&page=$i>[$i]</a>"; } 
if ($page-$show>=1) { for ($i=$page-$show ;$i<=$page-1 ;$i++) $index_middle .= "<a href=mod.php?mod=media&modfile=category&catid=$cat&page=$i>[$i]</a>"; } 
if ($lastlink>$page+$show) { $index_middle .= "[$page]"; for ($i=$page+1 ;$i<=$page+$show ;$i++) { $index_middle .= "<a href=mod.php?mod=media&modfile=category&catid=$cat&page=$i>[$i]</a>";}
$index_middle .= " .. <a title='��� ����' href=mod.php?mod=media&modfile=category&catid=$cat&page=$lastlink> � </a>"; } 
if ($lastlink<=$page+$show) { $index_middle .= "[$page]"; for ($i=$page+1 ;$i<=$lastlink ;$i++) $index_middle .= "<a href=mod.php?mod=media&modfile=category&catid=$cat&page=$i>[$i]</a>"; } 
}

}
echo $index_middle;



?>