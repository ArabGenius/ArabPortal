<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright ? 2006   |
|   -------------------------------------   |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 01/01/2007 Time: 00:00 AM  |
+===========================================+
*/


if (RUN_MODULE !== true)
{
    die ("<center><h3>���� ��� ������� ��� ������</h3></center>");
}

$mod_theme	= $mod->modInfo[themeid];
$mod_name	= $mod->modInfo[mod_name];
$modid	= $mod->modInfo[id];
$mod_title	= $mod->modInfo[mod_title];
$member_un   = $apt->format_data($apt->cookie['cname']);
$member_gp = $apt->format_data($apt->cookie['cgroup']);

$color1  = $mod->getmodsettings('color1',$mod_id);
$color2  = $mod->getmodsettings('color2',$mod_id);
$ufile_size  = $mod->getmodsettings('file_size',$mod_id);
$file_size  = $apt->format_Size($ufile_size*1024);
$allow_user = $mod->getmodsettings('allow_user',$mod_id);
$new_active = $mod->getmodsettings('new_active',$mod_id);
$media_add_gp	= @explode(",",$mod->getmodsettings('media_add_gp',$mod_name));
$media_edit_gp	= @explode(",",$mod->getmodsettings('media_edit_gp',$mod_name));
$allow_edit = in_array($member_gp,$media_edit_gp);
$allow_add = in_array($member_gp,$media_add_gp);

$allow_ext = array('.mp3','.rm','.ram','.ra','.wav','.wma','.wmv','.swf','.avi','.flv','.mpg');
$allow_types = array('audio/vnd.rn-realmedia','audio/x-ms-wma','video/x-ms-wmv', 'audio/wav', 'audio/mp3', 'audio/mpeg', 'video/mpeg', 'application/vnd.rn-realmedia-vbr', 'video/avi', 'application/vnd.rn-realmedia', 'audio/x-pn-realaudio','application/x-shockwave-flash','application/octet-stream');

$mediaply_ext = array('.wma', '.wav', '.mp3', '.wmv', '.avi','.mpg');
$realply_ext = array('.rm', '.rm', '.ram');
$flash_ext = array('.swf');
$flv_ext   = array('.flv');

$comment_allow	= $mod->getmodsettings('comment_allow',$mod_name);
$Cat_media	= $mod->getmodsettings('Cat_media',$mod_name);
$media_active	= $mod->getmodsettings('media_active',$mod_name);
$catCount = $apt->dbnumquery("rafia_media_cat");
$itemCount= $apt->dbnumquery("rafia_media_items","item_allow=1");
$open_hide  = "";
$close_hide = "";

    function mtable_cat_link($part,$cat_id='',$title='')
    {
       global $apt,$row,$id;
       $self = $apt->self;
        if($cat_id == ''){
            $cat_id = intval($apt->get['cat_id']);
        }
        include("modules/media/ModCatTree.php");
        $MTree = NEW MCatTree;
        $CatTree =  $MTree->mCatTreeLast($cat_id);
        $sitetitle = $apt->getsettings("sitetitle");
        if($title != ''){
            $post_title = " � ".$apt->format_data_out($title)."</font>";
        }else{
             $cat_dsc = "<br>".$row[dscin];
        }
        eval ("\$template .=\"" . $apt->gettemplate ( 'table_cat_link' ) . "\";");
        return $template;
    }
    
    
    function RemoveSQLINJ($u) {
	$url = html_entity_decode(urldecode($u));
	if ($url) {
		if (
			(strpos($url, 'union') !== false) ||
			(strpos($url, 'select') !== false) ||
			(strpos($url, 'into') !== false) ||
			(strpos($url, 'from') !== false) ||
			(strpos($url, 'where') !== false) ||
			 (strpos($url, 'delete') !== false) ||
			(strpos($url, ' or ') !== false)
		   ) 
		{
		die("<br><center><h2>���� .. ��� ������� ��� ������</h2></center>");
		}
	}
}

    
if( $allow_edit){
$media_admin .= "<form name='Jump'>";
$media_admin .= "<select onChange=PopUpName=window.open('','_self');PopUpName.location=this.options[this.selectedIndex].value;>";
$media_admin .= "<option selected >��� ��������</option>";
              $countwit = $apt->dbnumquery(" rafia_media_items","item_allow='0'");
$media_admin .= "<option value=mod.php?mod=media&modfile=admin>����� ���������($countwit)</option>";
              $countwit = $apt->dbnumquery(" rafia_media_comment","comment_allow ='0'");
$media_admin .= "<option value=mod.php?mod=media&modfile=admin&mode=comment>����� ������($countwit)</option>";
$media_admin .= "</select>";
$media_admin .= "</font>";

}


?>