<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 01/01/2007 Time: 00:00 AM  |
+===========================================+
*/


if (RUN_MODULE !== true)
{
    die ("<center><h3>���� ��� ������� ��� ������</h3></center>");
}

$itemid= $apt->setid('itemid');
include("modules/media/config.php");

$uresult = $apt->query("SELECT userid,username FROM rafia_users");
while(@extract($apt->dbarray($uresult))){
$user[$userid] = $username;
}

if(!$allow_edit){
$open_hide = "<!--";

$close_hide = " -->";

}
if($member_gp == $allow_edit){
$result = $apt->query("SELECT * FROM rafia_media_items where item_id='$itemid'");
}else{
$result = $apt->query("SELECT * FROM rafia_media_items where item_allow=1 and item_id='$itemid'");}
if($apt->dbnumrows($result)== 0){$apt->errmsg("���� ... �������� ���� ���� ���� �� ��� ������� ���");}
@extract($apt->dbarray($result));
$item_user = $user[$item_uid];
$item_date = $apt->Hijri($item_date);
$result_c = $apt->query("SELECT cat_title FROM rafia_media_cat where cat_id='$item_cat'");
@extract($apt->dbarray($result_c));
$index_middle = mtable_cat_link("<a href=mod.php?mod=$mod_name>&nbsp;$mod_title</a>",$item_cat);
$item_desc          = $apt->rep_words ($item_desc);
$item_desc          = $apt->rafia_code($item_desc);
$all		        = $item_rate*5;
$resultpoll = @(($item_crate/ $all)* 100);
$resultpoll = number_format($resultpoll);
$rate .="$resultpoll%";
$apt->title = $item_title;
$mediasmoalife = urlencode(base64_encode($item_moalif));  
$realname	= basename($item_link);
$ext		= strrchr($realname,'.');



if($item_type == 1){
$gimg = "��� ���������";
$item_link = <<<VOD
  <object id="MediaPlayer1" CLASSID="CLSID:22d6f312-b0f6-11d0-94ab-0080c74c7e95" codebase="http://activex.microsoft.com/activex/controls/mplayer/ en/nsmp2inf.cab#Version=5,1,52,701" standby="Loading Microsoft Windows� Media Player components..." TYPE="application/x-oleobject" AutoSize="true">
  <param name="fileName" value="$item_link">
  <param name="animationatStart" value="true">
  <param name="transparentatStart" value="true">
  <param name="autoStart" value="false">
  <param name="showControls" value="true">
  <param name="Volume" value="-20">
  <embed type="application/x-mplayer2" pluginspage="http://www.microsoft.com/Windows/MediaPlayer/" src="$item_link" name="MediaPlayer1" autostart="1" showcontrols="1" volume="-20" AutoSize="true">
</object>
VOD;
}elseif($item_type == 2){
$gimg = "��� ��� ����";
$item_link = '<p align="center">
<OBJECT id="rvocx" classid="clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA"
        width="300" height="250">
	<param name="src" value="'.$item_link.'">
        <param name="autostart" value="-1"><param name="controls" value="imagewindow">
        <param name="console" value="video"><param name="loop" value="0">
        <param name="SHUFFLE" value="0">
	<param name="PREFETCH" value="0">
	<param name="NOLABELS" value="0">
	<param name="NUMLOOP" value="0">
	<param name="CENTER" value="0">
	<param name="MAINTAINASPECT" value="0">
	<param name="BACKGROUNDCOLOR" value="#000000">
        <EMBED src="'.$item_link.'" width="300" height="250" loop="false" type="audio/x-pn-realaudio-plugin" controls="imagewindow" console="video" autostart="true">
        </EMBED></OBJECT></p>
<p align=center><OBJECT id="rvocx" classid="clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA" width="300" height="30">
          <param name="src" value="'.$item_link.'">
			<param name="autostart" value="-1">
          <param name="controls" value="ControlPanel"><param name="console" value="video">
          <param name="SHUFFLE" value="0">
			<param name="PREFETCH" value="0">
			<param name="NOLABELS" value="0">
			<param name="LOOP" value="0">
			<param name="NUMLOOP" value="0">
			<param name="CENTER" value="0">
			<param name="MAINTAINASPECT" value="0">
			<param name="BACKGROUNDCOLOR" value="#000000">
          <EMBED src="'.$item_link.'" width="300" height="30" controls="ControlPanel" type="audio/x-pn-realaudio-plugin" console="video" autostart="true">
          </EMBED></OBJECT>';
}elseif($item_type == 3){
$gimg = "��� ����";
$item_link = "<EMBED src=\"$item_link\" width=400
height=325 type=application/x-shockwave-flash wmode=\"transparent\" quality=\"best\">";
}elseif($item_type == 4){
$gimg = "��� ������";
$realname	= basename($item_link);
$link = 'http://'.$_SERVER['SERVER_NAME'].$_SERVER['PHP_SELF'];
$slink = ereg_replace("mod.php","",$link);
$mlink = $slink."modules/media";
if(strstr($item_link,'http://'))$slink='';
$item_link = <<<EOF
<center>
<div align=center id="container">���� ... <a href="http://www.macromedia.com/go/getflashplayer"> ���� ��� </a> ������ ���� ����.</div>
	<script type="text/javascript" src="$mlink/swfobject.js"></script>
	<script type="text/javascript">
		var s1 = new SWFObject("$mlink/player.swf","ply","428","300","9","#FFFFFF");
		s1.addParam("allowfullscreen","true");
		s1.addParam("allowscriptaccess","always");
		s1.addParam('autostart', 'true');
		s1.addParam('skin', 'http://www.longtailvideo.com/jw/upload/stylish.swf');
		s1.addParam("flashvars","file=$slink$item_link&image=$mlink/preview.jpg");
		s1.write("container");
	</script>
</center>
EOF;
}

if($allow_edit){
$item_admin .= "<form name='admin'>";
$item_admin .= "<select size='1' name='ghazi' onChange='location=document.admin.ghazi.options[document.admin.ghazi.selectedIndex].value;' value='GO'>";
$item_admin .= "<option selected >����� ��������</option>";
$item_admin .= "<option value=mod.php?mod=media&modfile=editpost&act=edit&itemid=$itemid>�����:���/���</option>";
if ( $item_sticky  == 1){ 
$item_admin .= "<option value=mod.php?mod=media&modfile=editpost&act=nosticky&itemid=$itemid>����� ����� ��������</option>";
}else{ 
$item_admin .= "<option value=mod.php?mod=media&modfile=editpost&act=sticky&itemid=$itemid>����� ��������</option>";
}
$item_admin .= "</select>";
$item_admin .= "</font><p>";
}


if(!$member_gp == 2){
$add_comment_user='<input type="text" name="user_name" size="26" dir="rtl">';
}else{
$add_comment_user='<input type="text" name="user_name" value="'.$member_un.'" size="26" dir="rtl">';
}

	if(($item_gcomm == 0) or ($comment_allow == no)){
	$media_add_comment = '';
	}else{
	eval("\$media_add_comment = \" " . $apt->getmodtemplate ( 'media_add_comment', $modid,$mod_theme ) . "\";");
	}

$media_comment = '';
$result = $apt->query("SELECT * FROM rafia_media_comment where comment_item=$itemid and comment_allow = 1 order by comment_id DESC");
while(@extract($apt->dbarray($result))){
$comment_text	= $apt->format_data_out($comment_text);
$comment_text     = $apt->rep_words ($comment_text);
eval("\$media_comment .= \" " . $apt->getmodtemplate ( 'media_comment', $modid,$mod_theme ) . "\";");
}

$apt->query("update rafia_media_items set item_show=item_show+1 where item_id=$itemid");



$result = $apt->query("SELECT item_id,item_title FROM rafia_media_items WHERE item_id != $itemid AND item_allow=1 and MATCH (item_title) AGAINST ('$item_title' IN BOOLEAN MODE) ORDER BY 'item_id' DESC LIMIT 0,10 ");
if($apt->dbnumrows($result)== 0){$media_tshbh .='';
}else{

eval("\$media_tshbh  .= \" " . $apt->getmodtemplate ( 'media_tshbh_top', $modid,$mod_theme ) . "\";");
$result = $apt->query("SELECT item_id,item_title,item_moalif,item_show,item_down,item_send  FROM rafia_media_items WHERE item_id != $itemid AND item_allow=1 and MATCH (item_title) AGAINST ('$item_title' IN BOOLEAN MODE) ORDER BY 'item_id' DESC LIMIT 0,10 ");

while($rows=mysql_fetch_array($result)){

 if ( $color == "$color1") 
           $color = "$color2"; 
       else 
           $color = "$color1";
           $item_id1          = $rows['item_id'];
$item_title1          = $rows['item_title'];
$item_moalif1          = $rows['item_moalif'];
$mediasmoalif1 = urlencode($item_moalif1);  
$item_show1          = $rows['item_show'];
eval("\$media_tshbh  .= \" " . $apt->getmodtemplate ( 'media_list_tshbh', $modid,$mod_theme ) . "\";");

}

eval("\$media_tshbh  .= \" " . $apt->getmodtemplate ( 'media_list_botton', $modid,$mod_theme ) . "\";");
}


eval("\$media_middle .= \" " . $apt->getmodtemplate ( 'media_item', $modid,$mod_theme ) . "\";");

eval("\$index_middle .= \" " . $apt->getmodtemplate ( 'media_main', $modid,$mod_theme ) . "\";");



echo $index_middle;

?>