<?php
/*
+===========================================+
|      ArabPortal V2.2.x Copyright � 2009   |
|   -------------------------------------   |
|                     BY                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Info      |
|   -------------------------------------   |
|  Last Updated: 08/08/2008 Time: 06:00 AM  |
+===========================================+
*/

error_reporting(E_ERROR | E_WARNING | E_PARSE);

if (@phpversion() >= '5.0.0' && (!@ini_get('register_long_arrays') || @ini_get('register_long_arrays') == '0' || strtolower(@ini_get('register_long_arrays')) == 'off'))
{
	$HTTP_POST_VARS = $_POST;
	$HTTP_GET_VARS = $_GET;
	$HTTP_SERVER_VARS = $_SERVER;
	$HTTP_COOKIE_VARS = $_COOKIE;
	$HTTP_ENV_VARS = $_ENV;
	$HTTP_POST_FILES = $_FILES;
	if (isset($_SESSION))
	{
		$HTTP_SESSION_VARS = $_SESSION;
	}
}

if(is_file("install/index.php")){
$open = @fopen("install/SysMsg.tpl",r);
$data = @fread($open,@filesize("install/SysMsg.tpl"));
@fclose($open);
echo $data;
exit;
}

define('TURN_BLOCK_ON', true);

function rff_callback($matches)
{
	global $apt;
	return $apt->ReadFromFile($matches[1],$matches[2]);
}

function inc_callback($matches)
{
	global $apt;
	return $apt->includeFile($matches[1],$matches[2]);
}

require_once("func/protection.php");
require_once("func/Files.php");
require_once('html/JavaScript.php');
require_once('admin/conf.php');
require_once("func/info.php");
require_once('func/mysql.php');
require_once('func/email.php');
require_once('func/CatTree.php');
require_once('func/mainsub.php');
require_once('func/functions.php');
require_once("func/Session.php");
require_once('func/upload.php');
require_once('func/printer.php');
require_once('func/menu.php');
require_once('lang/arabic.php');
require_once('func/form.php');
require_once('func/search.php');
require_once('func/counter.php');
require_once('func/module.php');
require_once('func/Cache.php');
require_once('func/Spams.php');

$apt = new func();
$start = (int) $apt->get['start'];

$forum_middle = '';
$adminJump = '';
$Jump = '';
$form = '';
$middle_menu = '';
$ads_head = '';
$ads_foot = '';
$title = '';
$add_new_post ='';
$add_new_reply ='';

$SetMain = array();
$SetRows = array();

$apt->arrSetting  = $apt->settings();
$apt->lang_form   = $lang_form;
$apt->all_groups = $apt->allgroups();

$chs_theme = $apt->selecttheme();

$Counter = new Counter();

$apt->start_loginfo();
if($apt->cookie['cgroup']=='')$cgroup=5; else $cgroup=$apt->cookie['cgroup'];
$apt->LoadGroupPerm($cgroup);

$maxlifetime             = $apt->conf['maxlifetime'] ?  $apt->conf['maxlifetime'] : get_cfg_var("session.gc_maxlifetime");

$apt->upload_path        = $apt->conf['upload_path'];

$apt->hijri_date         = $apt->getsettings("hijri_date");

if(!isset($apt->get['start']))
{
    $start = 0;
}


//---------------------------------------------------
//                        theme
//---------------------------------------------------

if(isset($apt->cookies['logintheme']))
{
    $apt->theme =  $apt->cookie['ctheme'];
}

if((isset($apt->theme)) ||($apt->theme != '0'))
{

    $theme_result = $apt->query("SELECT rafia_design.usertheme,rafia_templates.theme
                                   FROM rafia_design,rafia_templates
                                   WHERE rafia_design.theme ='". $apt->theme."'
                                   AND rafia_templates.theme ='". $apt->theme."'
                                   AND rafia_templates.theme = rafia_design.theme
                                   AND rafia_design.usertheme='1'");
                             
    if($apt->dbnumrows($theme_result)==0)
    {
        $apt->theme = $apt->getsettings('theme');
    }
}

if(empty($apt->theme))
{
    $apt->theme = $apt->getsettings('theme');
}
if($apt->conf['Theme_From_File']==1)
{
    $Cache = new Cache();
        if($Cache->isCache() == false)
             $Cache->mkCache ($apt->theme);

}
//echo $apt->theme;
//---------------------------------------------------
//                       end theme
//---------------------------------------------------


//-------------------start Turn Off APT---------------
if ($apt->cookie['cgroup'] !== '1'){
if($apt->getsettings('turn_off')=='yes'){
$file = basename($apt->self);
if(($apt->get[action] !== "login") or ($file !== "members.php")){
	$apt->head("������ ����");
	$turn_off_msg = $apt->getsettings('turn_off_msg');
	eval (" print \"" . $apt->gettemplate ( 'turn_off_site' ) . "\";");
	exit;
}
}
}
//--------------------end Turn Off APT----------------
//

//-------------------start IP PAN---------------
$pan_ips = $apt->getsettings('pan_ip');
$pan_ips = @explode("\n",$pan_ips);
if(in_array($apt->ip,$pan_ips)){
$apt->errmsg("���� ... ��� ����� �� ������ ��� ��� ������");
exit;
}
//--------------------end Turn Off APT----------------
//


if(count($_POST) > 0)
{
    $apt->check_referer();
}

$session =  md5(uniqid(rand()));

//---------------------------------------------------
//                      pm  messages
//---------------------------------------------------
if($apt->cookie['cid'] >0)
{
    $resultnew = $apt->query("SELECT * FROM rafia_messages WHERE
                              msgbox='1' and userbox='".$apt->cookie['cid']."'
                              and userbox != '$apt->Guestid' and msgisread='1'");
                                           
    $pmumrows = $apt->dbnumrows($resultnew);

    if ( $pmumrows > 0)
    {
       $apt->ifpm = 1;
    }
}

//---------------------------------------------------
//                        design
//---------------------------------------------------

$result = $apt->query("SELECT * FROM rafia_design WHERE theme='".$apt->theme."'");

  $drow         = $apt->dbarray($result);

  $themepath      = $drow["themepath"];

  $themewidth      = $drow["themewidth"];

  $apt->themepath = $themepath;
  
  $pagehd =  $apt->replace_callback($drow['pagehd']);
  $pageft =  $apt->replace_callback($drow['pageft']);

  $ads_head = $apt->ads_view_in('h');
  $ads_foot = $apt->ads_view_in('f');

  eval("\$pagehd =\"".str_replace("\"","\\\"",stripslashes($pagehd)). "\";");
  eval("\$pageft =\"".str_replace("\"","\\\"",stripslashes($pageft)). "\";");

///////////////
  $apt->load_smile();
//////////////
$timestamp   = $apt->time;
$lifetimeout = 300;
$timeout     = $timestamp-$lifetimeout;
$online_ip   = $apt->ip;
$session_id  = session_id() ;


$useronline   = $apt->format_data($apt->cookie['cname']);
$useronlineid = $apt->format_data($apt->cookie['cid']);

if(($useronline =='') and ($useronlineid =='')){
$apt->cookie['clogin'] = '';
$apt->cookie['cname'] = 'Guest';
$apt->cookie['cid'] = $apt->Guestid;
$useronline   = $apt->format_data($apt->cookie['cname']);
$useronlineid = $apt->format_data($apt->cookie['cid']);
}

$session_id   = $apt->format_data($session_id);
$REQUEST_URI  = $apt->format_data($_SERVER['REQUEST_URI']);
$PHP_SELF     = $apt->format_data($_SERVER['PHP_SELF']);
$USER_AGENT   = $apt->format_data($_SERVER['HTTP_USER_AGENT']);

$apt->query("DELETE FROM rafia_online WHERE onlineSID ='$session_id' or timestamp < $timeout");

$apt->query("INSERT INTO rafia_online (timestamp,
                                          onlineip,
                                          onlinefile,
                                          onlinepage,
                                          onlineSID,
                                          user_online,
                                          user_agent,
                                          useronlineid)
                                  VALUES ('$timestamp',
                                          '$online_ip',
                                          '$PHP_SELF',
                                          '$REQUEST_URI',
                                          '$session_id',
                                          '$useronline',
                                          '$USER_AGENT',
                                          '$useronlineid')",'rafia_online');


//////////////////////////// function check cookies ////////////////
function checkcookie()
{
    @extract($GLOBALS);
    
    unset($Login);
    
    if (( $apt->cookie['clogin'] != 'arabportal' ) && (!$apt->cookie['cid'] > 0 or $apt->cookie['cid'] == $apt->Guestid))
    {
        $apt->head(LANG_TITLE_LOG_IN);
        
         eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");
         
        $apt->foot($pageft);
        
        exit;
   }
}

function Login()
{
    @extract($GLOBALS);
    $apt->head(LANG_TITLE_LOG_IN);
    eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");
    $apt->foot($pageft);
}

$urlarr = array($_rafia,$id,$cat_id,$userid,$msgid,$start,$page,
                $adsid,$news_id,$thread_id,$down_id,$allowid,$mineID);

while (list($key, $value) = each ($urlarr))
{
    if (!empty($key))
    {
        if (eregi ('[^0-9]', $value))
        {
            $apt->errmsg(LANG_ERROR_URL);
        }
    }

}
$index_middle = '';


//for upgrade ��� ��� ��������

function getimagefile($postid)
{
    global $apt;
    $file_left = $apt->upload_path."/left/$postid.jpg";

    if (file_exists($file_left))
    {
          $image = "<img src=\"$file_left\"  align=\"left\">";
          return $image;
     }
     $file_right = $apt->upload_path."/right/$postid.jpg";
    if (file_exists($file_right))
    {
          $image = "<img src=\"$file_right\"  align=\"right\">";
          return $image;
     }
     unset($image);
  return $image;
}

?>