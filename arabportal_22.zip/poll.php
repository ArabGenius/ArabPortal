<?php
/*
+===========================================+
|      ArabPortal V2.2.x Copyright � 2009   |
|   -------------------------------------   |
|                     BY                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Info      |
|   -------------------------------------   |
|  Last Updated: 25/08/2008 Time: 03:35 AM  |
+===========================================+
*/

require_once("global.php");
unset($ads_head,$ads_foot);
$menu = new menu;
$menu->menuid       =  $apt->getsettings("index_menuid");
$left_menu          = $menu->_menu(2);
$right_menu         = $menu->_menu(1);
$middle_menu_count  =  $apt->getsettings("count_middle_menu");
$middle_menu = "<table border=0 cellpadding=0 cellspacing=0 width=100%><tr valign=top>";
$middle_menus = $menu->_menu(3);
$ex = @explode('<!-- BLOCK END -->',$middle_menus);
$m=0;
foreach($ex as $amenu){
$middle_menu .= '<td valign=top>'.$amenu.'</td>';
$m++;
if($m==$middle_menu_count)$middle_menu .= "</tr>";
}
$middle_menu .= "</tr></table><br>";

if ( $apt->get['action'] == "" )
{
    $apt->head("");
    $result = $apt->query("SELECT * FROM rafia_pollques  ORDER BY quesid DESC");
    $index_middle ='<table border="0" width="100%" class=bgcolor3>
                     <tr>
                     <td width="5%" align="center"><b><font  color="#FFFFFF">���</td>
                     <td width="65%" align="right"><b><font  color="#FFFFFF">������</td>
                     <td width="22%" align="center"><b><font color="#FFFFFF">��� �������</td>
                     </tr>
                     </table>';
    while($row = $apt->dbarray($result))
    {
        @extract($row);
        $index_middle .='<table border="0" width="100%">
           <tr><td width="5%" align="center">'.$quesid.':</td>
           <td width="65%" align="right"><font class=fontablt>'.$question.'</td>
           <td width="22%" align="center"><a href="poll.php?action=view&id='.$quesid.'">����� �������</a></td></tr></table>';
    }

        $apt->html_Output($left_menu);
        $apt->foot($pageft);
}
else if($apt->get['action']=="vote")
{
        if ( !$apt->full ($apt->post['pollid']) )
        {
            $apt->errmsg (LANG_ERROR_CHOICE_ANSWER);
        }
        if((isset($apt->post['pollid']))&&($apt->cookies["cookiepoll".$apt->setid('id')]!= $apt->setid('id')))
        {
            $expires = time()+(60*60*24*7);
            setcookie ("cookiepoll".$apt->setid('id') , $apt->setid('id') ,"$expires");
            $pollid = $apt->post['pollid'];
            $apt->query( "UPDATE rafia_pollanswer SET results=results+1 WHERE pollid='$pollid'");
        }
        $id = $apt->setid('id');
        $result = $apt->query("SELECT * FROM rafia_pollques WHERE quesid='$id'" );
        $question = $apt->dbarray($result);
        $index_middle ="<center><font class=fontablt>".$question["question"]."<hr noshade color=#000000 size=0 width=90%></font>";
        $index_middle .="<table border='1' cellpadding='0' cellspacing='0' style='border-collapse: collapse' bordercolor='#111111' width='95%' align='right'>";
        $answer = "SELECT * FROM rafia_pollanswer WHERE quesid='$question[0]'";
        $answer_res = $apt->query($answer);
        $total = 0;
        $imagebar = "images/poll.gif";
        while($row = $apt->dbarray($answer_res))
        {
            $total = $total + $row["results"];
        }
        $answer_res = $apt->query($answer);
        while($row = $apt->dbarray($answer_res))
        {
            $resultpoll = @(($row["results"] / $total)* 100);
            $resultpoll = number_format($resultpoll);
            $answer  = $row['text'];
            $pollid = $row['pollid'];
            $index_middle .="  <tr>
            <td width='35%'>$answer</td>
            <td width='45%'><img src=\"$imagebar\" height=10 width=$resultpoll></td>
            <td width='10%' align='center'>$resultpoll %</td>
            <td width='10%' align='center'>$row[results]</td>
            </tr>";
        }
        $index_middle .="</tr><tr>
		<td width='100%' colspan='4'><p align='center'>
		<font class=fontablt>����� �������: <font color=#000000><b>$total</b></font></td>
  		</tr></table>";
        $apt->head($question["question"]);
        $apt->html_Output($left_menu);
        $apt->foot($pageft);
}
else if($apt->get['action']=="view")
{
        $id = $apt->setid('id');
        $result = $apt->query("SELECT * FROM rafia_pollques WHERE quesid='$id'" );
        $question = $apt->dbarray($result);
        $index_middle ="<center><font class=fontablt>".$question["question"]."<hr noshade color=#000000 size=0 width=90%></font>";
        $index_middle .="<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: collapse' bordercolor='#111111' width='95%' align='right'>";
        $answer = "SELECT * FROM rafia_pollanswer WHERE quesid='$question[0]'";
        $answer_res = $apt->query($answer);
        $total = 0;
        $imagebar = "images/poll.gif";
        while($row = $apt->dbarray($answer_res))
        {
            $total = $total + $row["results"];
        }
        $answer_res = $apt->query($answer);
        while($row = $apt->dbarray($answer_res))
        {
            $resultpoll = @(($row["results"] / $total)* 100);
            $resultpoll = number_format($resultpoll);
            $answer  = $row['text'];
            $pollid = $row['pollid'];
            $index_middle .="  <tr>
            <td width='35%'>$answer</td>
            <td width='45%' align='right'><img src=\"$imagebar\" height=10 width=$resultpoll></td>
            <td width='10%' align='center'>$resultpoll %</td>
            <td width='10%' align='center'>$row[results]</td>
            </tr>";
        }
        $index_middle .="</tr><tr>
		<td width='100%' colspan='4'><p align='center'>
		<font class=fontablt>����� �������: <font color=#000000><b>$total</b></font></td>
  		</tr></table>";
        $apt->head($question["question"]);
        $apt->html_Output($left_menu);
        $apt->foot($pageft);
}
?>