<?php
/*
+===========================================+
|      ArabPortal V2.2.x Copyright � 2009   |
|   -------------------------------------   |
|                     BY                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Info      |
|   -------------------------------------   |
|  Last Updated: 25/08/2008 Time: 03:35 AM  |
+===========================================+
*/

define('RUN_MODULE', true);

require_once('global.php');

if (isset($apt->get[mod])){
    if (eregi("http\:\/\/", $apt->get[mod]))
    {
        $apt->errmsg (_MOD_NOT_AUTH);
    }
}
//=======================================================

$mod = new module();
$mod->mod_set_arr = $mod->mods_settings($mod->modInfo[mod_name]);

ob_start();

if($mod->modInfo[adsH] == '0'){
unset($ads_head);
}
if($mod->modInfo[adsF] == '0'){
unset($ads_foot);
}

$index_middle =  $mod->module_OutPut();
if($apt->title == ''){
$apt->head($mod->modInfo[mod_title]);
}else{
$apt->head($mod->modInfo[mod_title]."->".$apt->title);
}
ob_end_flush();

if($mod->modInfo[mnueid] == ''){
	$menu = new menu;
	$apt->html_Output('',0);
}else{
	$menu = new menu;
	$menu->menuid  =  $mod->modInfo[mnueid];
	if($mod->modInfo[right_menu] == 1 )
	{
	    $right_menu = $menu->_menu(1);
	}

	if($mod->modInfo[left_menu] == 1 )
	{
	    $left_menu  = $menu->_menu(2);
	}

	if($mod->modInfo[middle_menu] == 1 )
	{
		$middle_menu =  $menu->middle_menu();
	}

	$apt->html_Output($left_menu,$mod->modInfo[right_menu]);
}

//=======================================================

$apt->foot($pageft);

?>