<?
/*
+===========================================+
|      ArabPortal V2.2.x Copyright � 2009   |
|   -------------------------------------   |
|                     BY                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Info      |
|   -------------------------------------   |
|  Last Updated: 25/08/2008 Time: 03:35 AM  |
+===========================================+
*/

require_once("global.php");
if((!$_GET[action]) or ($_GET[action]) == ""){
$REFERER = $_SERVER[HTTP_REFERER];

if(!ereg($_SERVER[SERVER_NAME],$REFERER))die("<center><h3>���� ��� ������� ��� ������</h3></center>");

if(ereg("news_view_",$REFERER)){
$link = str_replace(".html","",$REFERER);
$link = str_replace("news_view_","translate.php?action=topic&id=",$link);
}else{
$link = str_replace("news.php?action=view&","translate.php?action=topic&",$REFERER);
}

$google_ip =  $apt->getsettings("googleIP");

$link = urlencode($link);
$page = $apt->get_contents("http://$google_ip/translate_c?hl=en&sl=ar&u=".$link);

if(!$page) die("<center><h3>���� �� ��� ������� ������ ������� ($google_ip) ���� ����</h3></center>");

echo $page;
}elseif($_GET[action] =="topic"){
$index_middle = '';
    $id = $apt->setid('id');
    if (( $apt->cookie['cgroup'] == $apt->a_g) || ( $apt->cookie['cgroup'] == $apt->m_g))
    {
       $row = $apt->dbfetch("SELECT rafia_news.*,rafia_users.userid,rafia_users.username,
                                rafia_users.datetime,rafia_users.allposts,rafia_users.signature,
                                rafia_users.homepage,rafia_users.avatar FROM rafia_news,rafia_users
                                WHERE id='$id' AND rafia_news.userid = rafia_users.userid LIMIT 1");
    }
    else
    {
        $row = $apt->dbfetch("SELECT rafia_news.*,rafia_users.userid,rafia_users.username,
                                 rafia_users.datetime,rafia_users.allposts,rafia_users.signature,
                                 rafia_users.homepage,rafia_users.avatar FROM rafia_news,rafia_users
                                 WHERE allow='yes' AND id='$id' AND rafia_news.userid = rafia_users.userid LIMIT 1");
    }
    @extract($row);
    if(!$apt->catgroup('groupview'))
    {
        $apt->head(LANG_TITLE_LOG_IN);
        eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");
        $apt->foot($pageft);
        exit;
    }
    $apt->query("UPDATE rafia_news SET reader = reader+1 WHERE id = '$id'");
    $apt->usereaderp("news_id",$id);
    $postid = $id;
    if($catmig == 0)
    {
        $newsimage = $apt->getnewsimage($id,$uploadfile);
    }
    else
    {
        $getImageCat = $apt->getImageCat();
        $newsimage  = $getImageCat[$cat_id];
    }
    $apt->head($title);
    $topic_nav = $apt->next_old_post("SELECT id FROM rafia_news WHERE allow='yes' and cat_id='$cat_id' and timestamp < '$timestamp'  ORDER BY timestamp DESC LIMIT 1");
    $topic_nav.= $apt->next_new_post("SELECT id FROM rafia_news WHERE allow='yes' and cat_id='$cat_id' and timestamp > '$timestamp'  ORDER BY timestamp LIMIT 1");
    $index_middle .= $apt->table_cat_link(LANG_TITLE_NEWS,$cat_id,$title);
    if ($start == 0)
    {
        if(( $userid == 0) || ($userid == $apt->Guestid))
        {
             $usertitle    =  $username;
             $username     =  $apt->format_data_out($name);
             $datetime     =  $apt->Hijri($date_time);
             $allposts     =  1;
        }
        else
        {
            $usertitles    =  explode("-", $apt->userRating($allposts));
            $usertitle     =  $usertitles[1];
            $userimgtitle  =  $usertitles[0];
            $username      =  $apt->format_data_out($username);
            $homepage      =  $apt->addToURL ($homepage);
            $signature     =  $apt->format_data_out ($signature);
            $datetime      =  $apt->Hijri($datetime);
            if($avatar == 0){
			    $avatar_pic = '';
            }else{
		    $avatarfile = $apt->upload_path."/".$userid.".".'avatar';
		    if(file_exists($avatarfile)){
		       $avatar_pic = "<img src=members.php?action=image&userid=".$userid."><br>";
		    }else{
		       $avatar_pic = '';
		    }
             }
        }
        $title         =  $apt->format_data_out($title);
        $news_head     = $apt->rep_words ($news_head);
        $news_head     =  $apt->rafia_code($news_head,1000); // Modified By Myrosy 24/10/2006
        //$post        =  $apt->phpcode($post);
        $post          = $apt->rep_words ($post);
        $post          =  $apt->rafia_code($post);
        if(isset($apt->get[highlight]))
        {
            $news_head     = $apt->highlight_words($news_head);
            $post          = $apt->highlight_words($post);
        }
        $date          =  $apt->Hijri($date_time)." ".$apt->gettime($date_time);
        $c_comment     =  $apt->dbnumquery("rafia_comment","news_id = $id");
        if (!$apt->checkcadmincat($cat_id)){$edit_link = '';}else{
           $edit_link = "<a href=\"$PHP_SELF?action=edit&id=$id\"><img border=\"0\" src=\"themes/$apt->themepath/edit.gif\"></a>";
        }
        eval("\$index_middle .= \" " . $apt->gettemplate ( 'news_table' ) . "\";");}
$index_middle = str_replace("translate.php","news.php",$index_middle);
echo $index_middle . "<font size=2><center>Powered by: <a href=http://www.arabportal.info>Arab Portal</a> v2.2 , Copyright� 2009</center></font>";
}
?>