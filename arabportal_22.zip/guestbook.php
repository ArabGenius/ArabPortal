<?php
/*
+===========================================+
|      ArabPortal V2.2.x Copyright � 2009   |
|   -------------------------------------   |
|                     BY                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Info      |
|   -------------------------------------   |
|  Last Updated: 25/08/2008 Time: 03:35 AM  |
+===========================================+
*/

require_once('global.php');

$apt->GroupAllow('view_site');

$cat_img = "sign.gif";
$action = $apt->get['action']; 

$menu = new menu;
$middle_menu =  $menu->middle_menu();

if ($action=="add")
{
    $apt->head(LANG_TITLE_ADD_SIGNATURE,1);
    $fo = new form;
    $fo->countpost	= $apt->getsettings('txtcount5');
    $txtcount_count	= $fo->countpost;
    $txtcount_java	= $fo->txtcount();
    $use_smiles		= $fo->smiles();
	$cap = $apt->getcaptcha();
    eval("\$index_middle = \" " . $apt->gettemplate ( 'guestbook_add' ) . "\";");
    $right_menu   =  $menu->_menu(1);
    $apt->html_Output("");
}
else if ( $apt->get['action']=="insert" )
{
    @extract($HTTP_POST_VARS);

    if($CONF['mach_ip'] == 1){
    $this_url = explode('/',$_SERVER['HTTP_HOST']);
    $reff_url = explode('/',$_SERVER['HTTP_REFERER']);

    if($this_url[0] !== $reff_url[2])
    $apt->bodymsg('���� ... �� ����� ����� ����� �� ���� ������',"guestbook.php?action=add");
    }

    $cap = $apt->getcaptcha();
    if($spam !== "guestnotspam_$cap"){
    $apt->bodymsg('���� ... ��� ������� ��� ������',"guestbook.php?action=add");
    exit;
    }

    $fullarr =  array($name,$email,$post);

     if (!$apt->full($fullarr))
     {
         $apt->errmsg(LANG_ERROR_VALIDATE);
     }

     if(!$apt->check_email($email))
     {
         $apt->errmsg(LANG_ERROR_VALID_EMIAL);
     }

    if (!$apt->txtcounmxs($post,$apt->getsettings("txtcount5")))
    {
        $apt->errmsg($error_mxs);
    }

    $gballow = $apt->getsettings("gballow");
    $title     = $apt->format_data($title);
    $name      = $apt->format_data($name);
    $email     = $apt->format_data($email);
    $url       = $apt->format_data($url);
    $guestbook = $apt->format_data($post);
    $timestamp = time();
    $Spams  = new Spams();
    if( $Spams->checkSpams() == false )
    {
        $apt->bodymsg(LANG_ERROR_WAIT_SECONDS,'guestbook.php');
    }
    $result=$apt->query("insert into rafia_guestbook
                          (date_time,name,email,url,guestbook,allow,ip) values
                          ('$timestamp','$name','$email','$url','$guestbook',
                          '$gballow','$apt->ip')");
    if ($result)
    {
        if($gballow == 1)$Counter->increment('gbCount');
        $apt->set_cookie("guestbook_added",'1',$apt->time + '600');
        $apt->bodymsg(LANG_MSG_POST_HAS_BEEN_ADDED,"guestbook.php");
    }
    else
    {
        $apt->bodymsg(LANG_ERROR_ADD_DB,"guestbook.php");
    }
}
if ($apt->get['action']=="edit")
{
    checkcookie();
    if (( $apt->cookie['cgroup'] == $apt->a_g) || ( $apt->cookie['cgroup'] == $apt->s_g))
    {
         $id = $apt->setid('id');
         $result = $apt->query("select * from rafia_guestbook where id='$id'");

         $apt->row = $apt->dbarray ($result);

         $apt->head(LANG_TITLE_LOG_IN,1);
         $fo = new form;

    $fo->countpost	= $apt->getsettings('txtcount5');
    $txtcount_count	= $fo->countpost;
    $txtcount_java	= $fo->txtcount();
    $use_smiles		= $fo->smiles();
    eval("\$index_middle = \" " . $apt->gettemplate ( 'guestbook_add' ) . "\";");
        $index_middle = $fo->gb_form('edit');
        $right_menu   =  $menu->_menu(1);
        $apt->html_Output("");
    }
}
else if($apt->get['action']=="UG")
{
      checkcookie();

      if (( $apt->cookie['cgroup'] == $apt->a_g) || ( $apt->cookie['cgroup'] == $apt->s_g))
      {
          $id = $apt->setid('id');
          @extract($HTTP_POST_VARS);

          if ($HTTP_POST_VARS['del'] =='1')
          {
              $apt->delmsg('',$id);
          }

          $fullarr =  array($name,$email,$post);

          if ( !$apt->full ($fullarr) )
          {
              $apt->errmsg (LANG_ERROR_VALIDATE);
          }

          if ( !$apt->check_email ($email) )
          {
              $apt->errmsg(LANG_ERROR_VALID_EMIAL);
          }

          if ( !$apt->txtcounmxs ($post,$apt->getsettings("txtcount5") ))
          {
              $apt->errmsg ($error_mxs);
          }

          $title     = $apt->format_data($title);
          $name      = $apt->format_data($name);
          $email     = $apt->format_data($email);
          $url       = $apt->format_data($url);
          $guestbook = $apt->format_data($post);
          $allow     = $apt->adminunset($allow);

          $result= $apt->query("update rafia_guestbook set
                                                       name = '$name',
                                                       email= '$email',
                                                       url = '$url',
                                                       guestbook = '$guestbook',
                                                       allow = '$allow'
                                                       where id=$id");
         if ($result)
         {
             header("Refresh: 1;url=guestbook.php");
             $apt->bodymsg(LANG_MSG_YOUR_POST_HAS_EDITED, "guestbook.php");
         }
    }
}
else if ($apt->get['action']=="")
{
    $apt->head(LANG_TITLE_GUEST_BOOK);
    
    $gbestperpage =  $apt->getsettings("gbperpagelist");

     if (( $apt->cookie['cgroup'] == $apt->a_g) || ( $apt->cookie['cgroup'] == $apt->s_g))
     {
         $numrowsg = $apt->dbnumquery("rafia_guestbook","allow!='yes'",'id');

         $index_middle =  "<a href=$PHP_SELF?action=admin>����� ��� ������</a> || <a href=$PHP_SELF?action=gbwait>������� �� ��������</a> ($numrowsg)<br>";
     }
     
    $result = $apt->query("SELECT *
                           FROM rafia_guestbook WHERE
                           allow='yes'
                           ORDER BY id DESC
                           LIMIT  $start,$gbestperpage");

     $apt->numrows = $apt->dbnumquery("rafia_guestbook","allow='yes'",'id');
     
      $pagenum =  $apt->pagenum($gbestperpage,"");
     
     eval("\$index_middle .= \" " . $apt->gettemplate ( 'guestbook_tools' ) . "\";");

    while( $row = $apt->dbarray ($result) )
 	{
         extract($row);

         $title     = $apt->format_data_out($title);
         $name      = $apt->format_data_out($name);
         $email     = $apt->format_data_out($email);
         $url       = $apt->addToURL($url);
         $guestbook = $apt->rep_words ($guestbook);
         $guestbook = $apt->rafia_code ($guestbook);

         //$date    =  $apt->Hijri($date_time)." ".$apt->gettime($date_time);

         eval("\$index_middle .= \" " . $apt->gettemplate ( 'guestbook_table' ) . "\";");
   }

    $right_menu         = $menu->_menu(1);
    $left_menu          = $menu->_menu(2);
    $apt->html_Output($left_menu);
}
else if ($apt->get['action']=="admin")
{
    if (( $apt->cookie['cgroup'] == $apt->a_g) || ( $apt->cookie['cgroup'] == $apt->s_g))
    {
        $apt->head(LANG_TITLE_MODERATE_POSTS);

        $numrowsg = $apt->dbnumquery("rafia_guestbook","allow='wit'",'id');

        $index_middle =  "<a href=$PHP_SELF?action=admin>����� ��� ������</a> || <a href=$PHP_SELF?action=gbwait>������� �� ��������</a> ($numrowsg)<br>";

        $perpage = 50;

        $result = $apt->query("SELECT * FROM rafia_guestbook WHERE
                                          allow='yes' ORDER BY id DESC
                                          LIMIT  $start,$perpage");

        $numrows = $apt->dbnumquery("rafia_guestbook","allow='yes'",'id');

        $index_middle .= $apt->pagenum($perpage,"guestbook");

        $index_middle .=  $apt->admin_form_opan("delete");

        $index_middle .= $apt->admin_table_head("����� ��� ������");

        while( $apt->row = $apt->dbarray($result))
        {
            $apt->row["title"] = "������ : ".$apt->row['name']."<hr>".$apt->title_cut($apt->rafia_code($apt->row['guestbook']),200);
            $index_middle .= $apt->admin_table_cell("","edit","delete",0);
        }

        $index_middle .= $apt->admin_table_close();
        $index_middle .= $apt->admin_form_close();
    }
    $apt->html_Output($left_menu);
}
else if($apt->get['action']=="del")
{
    if (( $apt->cookie['cgroup'] == $apt->a_g) || ( $apt->cookie['cgroup'] == $apt->s_g))
    {
        if(!empty( $apt->post['idp']))
        {
            $id = $apt->post['idp'] ;

            $result = $apt->query("delete from  rafia_guestbook where id=$id");
            if ($result)
            {
                $Counter->decrement('gbCount');
                header("Refresh: 1;url=guestbook.php");
                $apt->bodymsg(LANG_MSG_POST_HAS_BEEN_DELETED, "guestbook.php");
            }
        }
    }
}
else if ($apt->get['action']=="doguestbook")
{
    if (( $apt->cookie['cgroup'] == $apt->a_g) || ( $apt->cookie['cgroup'] == $apt->s_g))
    {
        if (count($apt->post['do']) > 0)
        {
            if($apt->post['del'])
            {
			$id = $apt->myimplode($apt->post['do']);
                   $result= $apt->query("delete from rafia_guestbook where id in($id)");
                if ($result)
                {
                    header("Refresh: 1;url=".$apt->refe);
                    $apt->bodymsg(LANG_MSG_POST_HAS_BEEN_DELETED,$apt->refe);
                }
            }elseif($apt->post['allow'])
            {
			$id = $apt->myimplode($apt->post['do']);
                   $result= $apt->query("update rafia_guestbook set allow='yes' where id in($id)");
                if ($result)
                {
                    header("Refresh: 1;url=".$apt->refe);
                    $apt->bodymsg(LANG_MSG_POST_HAS_APPROVED,$apt->refe);
                }
            }
        }
    }
}
else if ($apt->get['action']=="gbwait")
{
   if (( $apt->cookie['cgroup'] == $apt->a_g) || ( $apt->cookie['cgroup'] == $apt->s_g))
   {
       $result = $apt->query("SELECT * FROM rafia_guestbook WHERE allow='wit' ORDER BY id ASC");

       $apt->head(LANG_TITLE_MODERATE_POSTS);

       if($apt->dbnumrows($result))
       {
           $index_middle = $apt->admin_form_opan("doguestbook");

           $index_middle .= $apt->admin_table_head("������� ����� �������");

           while($apt->row = $apt->dbarray($result))
           {
               $apt->row["title"] = "������ : ".$apt->row['name']."<hr>".$apt->title_cut($apt->rafia_code($apt->row['guestbook']),200);

               $index_middle .= $apt->admin_table_cell("","edit","",0);
           }

           $index_middle .= $apt->admin_table_close();

           $index_middle .= $apt->admin_form_close(0,0);
       }
       else
       {
           $index_middle .=  "<p>�� ���� ����� �� ��������.</p>";
       }
       $apt->html_Output($left_menu);
    }
}
if(isset($fo))
{
    print $apt->script->post_java();
}
$apt->foot($pageft);
?>