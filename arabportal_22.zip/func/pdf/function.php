<?php

    function rep_smile($r)
    {
	  global $mysql;
        $result = $mysql->query("SELECT * FROM rafia_smileys ORDER BY id");
        while($row=$mysql->dbarray($result))
        {
            @extract($row);
            $r = str_replace("$code" , "<img src='images/smiles/$smile' border='0'>" , $r);
        }
        return $r;
    }

    function rafia_code($Str,$wrap=100000)
    {
        $Str = preg_replace( "#(\?|&amp;|&)(PHPSESSID|s|S)=([0-9a-zA-Z]){32}#e", "", $Str );
        $Str = wordwrap( $Str, $wrap , "\n", 0);
        $Str = stripslashes(bbc_replace($Str));
        return str_replace('<font color="', '<font color="#', $Str);
    }

    function bbc_code($Str)
    {
        return nl2br(stripslashes(bbc_replace($Str)));
    }

    function bbc_replace_print($r)
    {
        $r = bbc_linkcode($r);
        
        $r = bbc_fontcode($r);
        
        $r = bbc_images($r);

        $r = preg_replace("#([\n ])([a-z0-9\-_.]+?)@([\w\-]+\.([\w\-\.]+\.)?[\w]+)#i", "\\1<a href=\"javascript:mailto:mail('\\2','\\3');\">\\2_(at)_\\3</a>", $r);
        $search = array(
                '~  ~',
                '~rafiaphp.com~i',
				'~\[url\](http:\/\/.+?)\[\/url\]/is~i',
				'~(^|\s)(http|https|ftp)(://\S+)~i',
                 '~(^|\s)(www.+[a-z0-9-_.])~i',
				'~(^|\s)([a-z0-9-_.]+@[a-z0-9-.]+\.[a-z0-9-_.]+)~i',
				'~\[img](http|https|ftp)://(.+?)\[/img]~i',
				'~\[code](.+?)\[/code]~ise',
				'~\[php](.+?)\[/php]~ise',
                '~\[NOTE](.+?)\[/NOTE]~ise',
                '~\[QUOTE](.+?)\[/QUOTE]~ise'
            );
       $replace = array(
   				'&nbsp; ',
                'arabportal.info',
				'<a href="\\1" target=_blank>\\2</a>',
                '\\1<a href="\\2\\3" target="_blank">\\2\\3</a>',
                '\\1<a href="http://\\2" target="_blank">\\2</a>',
				'\\1<a href="mailto:\\2">\\2</a>' ,
				'<img src="\\1://\\2" border="0" alt="\\1://\\2">',
				'sp_code(\'\\1\',\' 100 \')',
				'sp_code(\'\\1\',\' 100 \')',
                'mysp_code(\'\\1\',\' ������ \')',
                'mysp_code(\'\\1\',\' ������  \')'
           );
        $r = preg_replace($search, $replace, $r);
        return $r;
    }

//-----------------------------------------------
    function bbc_fontcode($r)
    {
        $search = array( '~\[B](.+?)\[/B]~is',
                         '~\[I](.+?)\[/I]~is',
                         '~\[U](.+?)\[/U]~is',
                         '~\[C](.+?)\[/C]~is',
                         '~\[Q](.+?)\[/Q]~is',
                         '~\[align=(.+?)](.+?)\[/align]~is',
                         '~\[face=(.+?)](.+?)\[/face]~is',
                         '~\[color=(\S+?)](.+?)\[/color]~is',
                         '~\[size=([0-9]+?)](.+?)\[/size]~is'
				  );
       $replace = array( '<b>\\1</b>',
                         '<i>\\1</i>',
                         '<u>\\1</u>',
                         '<center>\\1</center>',
                         '<font color="#990033 face="traditional arabic" size=4>\\1</font>',
                         '<p align="\\1">\\2</p>',
                         '<font face="\\1">\\2</font>',
                         '<font color="\\1">\\2</font>',
                         '<font color="\\1">\\2</font>',
                         '<font size="\\1">\\2</font>'
                   );

       $r = preg_replace($search, $replace, $r);
       
        return $r;
    }



  function sp_code($r,$msg)
  {
        $output ="<br><p dir='ltr' align='left'><br>=============  $msg  ============</p><br>";
	  $lines = explode("\n",$r);
	  foreach($lines as $line)$output .= "<p dir='ltr' align='left'>".$line."</p>";
        $output .="<br><p dir='ltr' align='left'>=================================</p>";
	  $output = str_replace("\n",'',$output);
      return  $output;
  }


function sp_codePDFNCode($code,$msg) {
    $code = preg_replace( "/<br>|<br \/>/", "<BR>", $code );
    $arr = explode("<BR>",$code);
    $lines = count($arr);
    $height = $lines * 15;
    if($height!=15){
        $code = "";
        for ($i=0; $i<=$lines-1; $i++)  {
            $code .= "<tr><th width='85%' dir='ltr' height='10' align='left'>".$arr[$i]."</th></tr>";
        }
        return "<table border='1' cellspacing='0' cellpadding='0'><tr><th width='85%' bgcolor='#666666' height='10' color='#ffffff' dir='ltr' align='left'>$msg :</th></tr><tr><th width='750' height='$height'><table border='0' cellspacing='0' cellpadding='0'>$code</table></th></tr></table>";
    }else{
        return "<table border='1' cellspacing='1' cellpadding='1'><tr><th width='85%' bgcolor='#666666' height='10' color='#ffffff' dir='ltr' align='left'>$msg :</th></tr><tr><th width='750' height='10' dir='ltr' align='left'>$code</th></tr></table>";
    }
}


function mysp_code($code,$msg) {
    $code = preg_replace( "/<br>|<br \/>/", "<BR>", $code );
    $arr = explode("<BR>",$code);
    $lines = count($arr);
    $height = $lines * 15;
    if($height!=15){
        $code = "";
        for ($i=0; $i<=$lines-1; $i++)  {
            $code .= "<tr><th width='85%' dir='rtl' height='10' align='left'>".$arr[$i]."</th></tr>";
        }
        return "<table border='1' cellspacing='0' cellpadding='0'><tr><th width='85%' bgcolor='#666666' height='10' color='#ffffff' dir='rtl' align='right'>$msg :</th></tr><tr><th width='750' height='$height'><table border='0' cellspacing='0' cellpadding='0'>$code</table></th></tr></table>";
    }else{
        return "<table border='1' cellspacing='1' cellpadding='1'><tr><th width='85%' bgcolor='#666666' height='10' color='#ffffff' dir='rtl' align='right'>$msg :</th></tr><tr><th width='750' height='10' dir='rtl' align='right'>$code</th></tr></table>";
    }
}



//-----------------------------------------------

    function bbc_replace($r)
    {
        $r = bbc_fontcode($r);
        $r = str_replace('[||]','[ll]',$r);
        $r = preg_replace("#([\n ])([a-z0-9\-_.]+?)@([\w\-]+\.([\w\-\.]+\.)?[\w]+)#i", "\\1<a href=\"javascript:mailto:mail('\\2','\\3');\">\\2_(at)_\\3</a>", $r);
        $search = array(
                '~  ~',
                '~rafiaphp.com~i',
                         '~\[move=(.+?)](.+?)\[/move]~is',
				'~\[url\]([^\\[]*)\\[ll\]([^\\[]*)\\[/url\\]~i',
				'~(^|\s)(http|https|ftp)(://\S+)~i',
                 '~(^|\s)(www.+[a-z0-9-_.])~i',
				'~(^|\s)([a-z0-9-_.]+@[a-z0-9-.]+\.[a-z0-9-_.]+)~i',
				'~\[img](http|https|ftp)://(.+?)\[/img]~i',
				'~\[code](.+?)\[/code]~ise',
				'~\[php](.+?)\[/php]~ise',
                '~\[NOTE](.+?)\[/NOTE]~ise',
                '~\[QUOTE](.+?)\[/QUOTE]~ise',
                '~\[QURAN](.+?)\[/QURAN]~is',
                '~\[rams](.+?)\[/rams]~is',
                '~\[ramv](.+?)\[/ramv]~is',
                '~\[media](.+?)\[/media]~is',
                '~\[media=(.+?)]\[/media]~is',
		   '~\[flash width=([0-6]?[0-9]?[0-9]) height=([0-4]?[0-9]?[0-9])\](.*?)\[/flash\]~i'
            );
       $replace = array(
                '&nbsp; ',
                'arabportal.net',
                '<P align="\\1">\\2</P>',
			'<a href="\\1" target=_blank>\\2</a>',
                '\\1<a href="\\2\\3" target="_blank">\\2\\3</a>',
                '\\1<a href="http://\\2" target="_blank">\\2</a>',
				'\\1<a href="mailto:\\2">\\2</a>' ,
				'<img src="\\1://\\2" border="0" alt="\\1://\\2">',
				'sp_code(\'\\1\',\' CODE \')',
				'sp_code(\'\\1\',\' PHP \')',
                'mysp_code(\'\\1\',\' ������ \')',
                'mysp_code(\'\\1\',\' ������  \')',
                '<font color="#990033" face="traditional arabic" size="4">&#64831;</font> \\1 <font color="#990033" face="traditional arabic" size="4">&#64830;</font>',
'<a href="\\1">\\1</a>',
'<a href="\\1">\\1</a>',
'<a href="\\1">\\1</a>',
'<a href="\\1">\\1</a>',
'<a href="\\3">\\3</a>'
           );
        $r = preg_replace($search, $replace, $r);
        return $r;
    }

//------------------------------------------------------
// ������ �������  //
//------------------------------------------------------
   function bbc_linkcode($r)
    {
          $r = eregi_replace("\\[url\]([^\\[]*)\\[ll\]([^\\[]*)\\[/url\\]","<a href='\\1' target=_blank>\\2</a>",$r);

          $search  = array("/([^]_a-z0-9-=\"'\/])((http|https|ftp):\/\/|www\.)([^ \r\n\(\)\*\^\$!`\"'\|\[\]\{\}<>]*)/si",
                           "/^((http|ftp):\/\/|www\.)([^ \r\n\(\)\*\^\$!`\"'\|\[\]\{\}<>]*)/si"
                     );

          $replace = array("\\1[url]\\2\\4[/url]",
                            "[url]\\1\\3[/url]"
                     );

          $r = preg_replace($search, $replace, $r);

          $r = preg_replace("/\[url\](http:\/\/.+?)\[\/url\]/is","<a href='\\1' target=_blank>\\1</a>",$r);

          $r = preg_replace("/\[url\](www.+?)\[\/url\]/is","<a href='http:\/\/\\1' target=_blank>\\1</a>",$r);

          $r = preg_replace('/([\w-?&;#~=\.\/]+\@(\[?)[a-zA-Z0-9\-\.]+\.([a-zA-Z]{2,4}|[0-9]{1,3})(\]?))/i', "<a href='mailto:\\1'>\\1</a>", $r);

        return $r;
    }


?>