<?php


class sessions  extends func
{
    /* Define the mysql table you wish to use with
       this class, this table MUST exist. */
    var $ses_table = "rafia_sessions";


    /* Configure the info to connect to MySQL, only required
       if $db_con is set to 'Y' */
  //  var $db_host = "localhost";
  //  var $db_user = "root";
   // var $db_pass = "pass";
 //   var $db_dbase = "demo";

    
    /* Open session, if you have your own db connection
       code, put it in here! */
    function _open($path, $name) {

		$this->link = @mysql_connect($this->dbserver, $this->dbuser, $this->dbpword);
        return TRUE;
    }

    /* Close session */
    function _close() {
        /* This is used for a manual call of the
           session gc function */
        $this->_gc(0);
        return TRUE;
    }

    /* Read session data from database */
    function _read($ses_id) {
        $session_sql = "SELECT * FROM " . $this->ses_table
                     . " WHERE ses_id = '$ses_id'";
        $session_res = @mysql_query($session_sql,$this->link);
        if (!$session_res) {
            return '';
        }

        $session_num = @mysql_num_rows ($session_res);
        if ($session_num > 0) {
            $session_row = mysql_fetch_assoc ($session_res);
            $ses_data = $session_row["ses_value"];
            return $ses_data;
        } else {
            return '';
        }
    }

    /* Write new data to database */
    function _write($ses_id, $data) {
        $session_sql = "UPDATE " . $this->ses_table
                     . " SET ses_time='" . time()
                     . "', ses_value='$data' WHERE ses_id='$ses_id'";
        $session_res = @mysql_query ($session_sql,$this->link);
        if (!$session_res) {
            return FALSE;
        }
        if (@mysql_affected_rows ()) {
            return TRUE;
        }

        $session_sql = "INSERT INTO " . $this->ses_table
                     . " (ses_id, ses_time, ses_start, ses_value)"
                     . " VALUES ('$ses_id', '" . time()
                     . "', '" . time() . "', '$data')";
        $session_res = @mysql_query($session_sql,$this->link);
        if (!$session_res) {
            return FALSE;
        }         else {
            return TRUE;
        }
    }

    /* Destroy session record in database */
    function _destroy($ses_id) {
        $session_sql = "DELETE FROM " . $this->ses_table
                     . " WHERE ses_id = '$ses_id'";
        $session_res = @mysql_query ($session_sql,$this->link);
        if (!$session_res) {
            return FALSE;
        }         else {
            return TRUE;
        }
    }

    /* Garbage collection, deletes old sessions */
    function _gc($life) {
        $ses_life = strtotime("-5 minutes");

        $session_sql = "DELETE FROM " . $this->ses_table
                     . " WHERE ses_time < $ses_life";
        $session_res = @mysql_query ($session_sql,$this->link);


        if (!$session_res) {
            return FALSE;
        }         else {
            return TRUE;
        }
    }
}


$ses_class = new sessions;

/* Change the save_handler to use the class functions */
session_set_save_handler (array(&$ses_class, '_open'),
                          array(&$ses_class, '_close'),
                          array(&$ses_class, '_read'),
                          array(&$ses_class, '_write'),
                          array(&$ses_class, '_destroy'),
                          array(&$ses_class, '_gc'));

/* Start the session */
session_start();
?>
