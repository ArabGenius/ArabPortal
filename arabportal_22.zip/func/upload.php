<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|                                           |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 22/10/2006 Time: 10:00 PM  |
+===========================================+
*/
        
class RaFiaUpload
{
    var $uploads        = array();
    var $max_size       = '100';
    var $min_size       = '1';
    var $end_file       = '';
    var $allwtypes      = '';
    var $upload_error   = array();

    function getend()
    {
        return end (explode (".",$this->uploads["name"]));
    }

    function checkend($allwtypes)
    {
        global $apt;
        $this->allwtypes = explode(",",$allwtypes);
        if (in_array (strtolower($this->getend()), $this->allwtypes))
        return true;
        else
        return false;
    }


    function resizedimage($filename)
    {
        global $imagewidth;

        switch(strtolower($this->getend()))
        {
            case "gif":
            if (function_exists (ImageCreateFromGIF))
            $src_img  = @ImageCreateFromGIF( $filename );
            break;
            case "jpg":
            if (function_exists (imagecreatefromjpeg))
            $src_img  = @ImageCreateFromJPEG( $filename );
            break;
            case "png":
            if (function_exists (ImageCreateFromPNG))
            $src_img  = @ImageCreateFromPNG( $filename );
            break;
            default:
            if (function_exists (imagecreatefromjpeg))
            $src_img  = @ImageCreateFromJPEG( $filename );
            break;
        }
        
        $new_w = $imagewidth;
        $factor = imagesx($src_img)/$imagewidth;
        $new_h = imagesy($src_img)/$factor;
        $dst_img = ImageCreatetruecolor($new_w,$new_h);
        imagecopyresized($dst_img,$src_img,0,0,0,0,$new_w,$new_h,imagesx($src_img),imagesy($src_img));

        switch(strtolower($this->getend()))
        {
            case "gif":
            if (function_exists (imagegif))
            {
                imagegif($dst_img, $filename, $imagewidth);
            }
            break;
            case "jpg":
            if (function_exists (imagejpeg))
            {
                imagejpeg($dst_img, $filename, $imagewidth);
            }
            break;
            case "png":
            if (function_exists (imagepng))
            {
                imagepng($dst_img, $filename, $imagewidth);
            }
            break;
            default:
            imagejpeg($dst_img, $filename, $imagewidth);
        }
        return $filename;
    }

    function insertfile()
    {
       global $apt,$id;
       $upcat      = $this->cat;
       $upcatid    = $apt->post['cat_id'];
       $uppostid   = $id;
       $upuserid   = $apt->cookie['cid'];
       $uptypes    = $this->uploads["type"];
       $upname     = $this->uploads["name"];
       $upsize     = $this->uploads["size"];
       $upend      = $this->getend();
       $imagealign = $apt->post['imagealign'];

       $apt->query ("insert into rafia_upload (upcatid,
                                                 uppostid,
                                                 upuserid,
                                                 uptypes,
                                                 upname,
                                                 upsize,
                                                 upstat,
                                                 upcat,
                                                 upend,imagealign)
                                                 values
                                                ('$upcatid',
                                                 '$uppostid',
                                                 '$upuserid',
                                                 '$uptypes',
                                                 '$upname',
                                                 '$upsize',
                                                 '1',
                                                 '$upcat',
                                                 '$upend',
                                                 '$imagealign')");
    }

    function updatefile()
    {
       global $apt;
       $upcat      = $this->cat;
       $upcatid    = $apt->post['cat_id'];
       $uppostid   = $apt->get['id'];
       $uptypes    = $this->uploads["type"];
       $upname     = $this->uploads["name"];
       $upsize     = $this->uploads["size"];
       $upend      = $this->getend();
       $uploadfile = $apt->post['uploadfile'];
       $apt->query ("update  rafia_upload set upcatid='$upcatid',
                                                uppostid='$uppostid',
                                                uptypes='$uptypes',
                                                upname='$upname',
                                                upsize='$upsize',
                                                upend='$upend'
                                                where upid='$uploadfile'");

    }


    function uploadfile($k=0)
    {
      global $apt,$id,$commentid;

///////////////// By ArabGenius ////////////////
if(empty($commentid))
{
    $commentid =  $_GET[commentid];
}
if(empty($commentid))
{
    $commentid =  $_POST[commentid];
}
//-------------
if(empty($id))
{
    $id =  $_GET[id];
}
if(empty($id))
{
    $id =  $_POST[id];
}
////////////////////////////////////////////////

    if(!empty($commentid))
    {
        $id =  $commentid;
    }

    $tmp_name =  $this->uploads["tmp_name"];
    $filename =  $apt->upload_path."/".$id.".".$this->cat;
//=============== for image ============
    global $imagesame;
     
    if( $imagesame != 0)
    {
        $this->resizedimage($tmp_name);

    }
//=============== ========= ============

if(@is_uploaded_file($tmp_name)){
    if(@move_uploaded_file($tmp_name, $filename))
    {
        if($k==0)
        {
            $this->insertfile();
        }
        else
        {
            $this->updatefile();
        }
    }
    else
    {
       return false;
    }
}else{
return false;
}

    return true;
}

}
/////////////////// end  RaFiaUpload class //////////////

?>